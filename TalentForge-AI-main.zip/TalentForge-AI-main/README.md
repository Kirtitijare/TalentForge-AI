# TalentForge AI

AI-Powered Career Guidance Platform — converted from C# ASP.NET MVC to a modern Python/React stack.

## Tech Stack

| Layer         | Technology                        |
|---------------|-----------------------------------|
| Frontend      | React.js 18 + Vite + Tailwind CSS |
| Backend       | Flask 3 (Python)                  |
| Main Database | PostgreSQL 16                     |
| Vector Search | pgvector                          |
| AI/NLP        | spaCy (en_core_web_sm)            |
| ML            | scikit-learn (TF-IDF, cosine sim) |
| LLM           | Groq API (llama-3.1-8b-instant)   |
| Charts        | Recharts                          |
| Graph UI      | React Flow                        |
| Deployment    | AWS (EC2 + RDS + S3 + CloudFront) |

---

## Project Structure

```
talentforge/
├── backend/          # Flask API
│   ├── app/
│   │   ├── models/   # SQLAlchemy models
│   │   ├── routes/   # Flask Blueprints (1 per feature)
│   │   ├── services/ # AI, NLP, ML, email, PDF services
│   │   └── utils/    # Auth helpers
│   ├── Dockerfile
│   ├── requirements.txt
│   └── run.py
├── frontend/         # React app
│   ├── src/
│   │   ├── api/      # Axios API clients
│   │   ├── components/
│   │   ├── pages/    # All page components
│   │   └── store/    # Zustand auth store
│   ├── Dockerfile
│   └── package.json
└── docker-compose.yml
```

---

## Quick Start (Local Dev)

### Prerequisites
- Python 3.11+
- Node.js 20+
- PostgreSQL 16 with pgvector extension
- Groq API key (free at console.groq.com)

### 1. Clone & configure

```bash
cd backend
cp .env.example .env
# Edit .env — set GROQ_API_KEY, DATABASE_URL, MAIL_* credentials
```

### 2. Backend setup

```bash
cd backend
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # Mac/Linux

pip install -r requirements.txt
python -m spacy download en_core_web_sm

# Create DB and run app (auto-creates tables + seeds market trends)
python run.py
```

### 3. Frontend setup

```bash
cd frontend
npm install
npm run dev
```

App runs at: http://localhost:5173  
API runs at: http://localhost:5000

### 4. Docker Compose (all-in-one)

```bash
# From talentforge/ root
docker-compose up --build
```

---

## API Endpoints

| Method | Route                          | Description                        |
|--------|--------------------------------|------------------------------------|
| POST   | /api/auth/register             | Register new user                  |
| POST   | /api/auth/verify-otp           | Verify email OTP                   |
| POST   | /api/auth/login                | Login → JWT tokens                 |
| POST   | /api/auth/refresh              | Refresh access token               |
| POST   | /api/auth/forgot-password      | Send password reset OTP            |
| POST   | /api/auth/reset-password       | Reset password with OTP            |
| GET    | /api/auth/me                   | Get current user                   |
| POST   | /api/career/recommend          | AI career recommendation           |
| GET    | /api/career/recommendations    | List user's recommendations        |
| POST   | /api/resume/analyze            | Upload + analyze PDF resume        |
| GET    | /api/skill-gap/                | Auto skill gap analysis            |
| POST   | /api/skill-gap/analyze         | Skill gap for specific career      |
| POST   | /api/learning-path/generate    | 6-month path + certs + hybrid rec  |
| GET    | /api/market-trends/            | All market trends                  |
| GET    | /api/market-trends/skills      | Top demanded skills                |
| POST   | /api/chat/send                 | Chat with AI mentor                |
| GET    | /api/chat/history              | Get chat history                   |
| GET    | /api/collaborative/            | Collaborative filtering recs       |
| GET    | /api/report/download           | Download PDF career report         |
| GET    | /api/profile/                  | Get profile                        |
| PUT    | /api/profile/                  | Update profile                     |
| GET    | /api/admin/dashboard           | Admin stats (admin only)           |
| GET    | /api/admin/users               | List all users (admin only)        |
| DELETE | /api/admin/users/:id           | Delete user (admin only)           |
| PATCH  | /api/admin/users/:id/promote   | Promote to admin                   |

---

## AWS Deployment

```
React (S3 + CloudFront)  →  Flask (EC2 + Gunicorn + Nginx)  →  PostgreSQL (RDS)
                                        ↓
                              S3 (resume uploads)
                              SES (OTP emails)
                              Secrets Manager (API keys)
```

### Steps
1. **RDS** — Create PostgreSQL 16 instance, enable pgvector extension
2. **EC2** — t3.medium, install Docker, run backend container
3. **S3** — Create bucket for resume uploads, configure CORS
4. **CloudFront + S3** — Deploy `npm run build` output
5. **SES** — Verify sender domain, update `MAIL_*` env vars
6. **Secrets Manager** — Store `GROQ_API_KEY`, `JWT_SECRET_KEY`, DB credentials

---

## Environment Variables

See `backend/.env.example` for all required variables.

Key ones:
- `DATABASE_URL` — PostgreSQL connection string
- `GROQ_API_KEY` — From console.groq.com (free)
- `JWT_SECRET_KEY` — Random 64-char string
- `MAIL_*` — Gmail SMTP or AWS SES credentials
