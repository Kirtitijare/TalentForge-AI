from app import create_app
from app.extensions import db
from app.services.market_trend_service import seed_market_trends

app = create_app()

with app.app_context():
    db.create_all()
    try:
        db.session.execute(db.text("ALTER TABLE users ADD COLUMN IF NOT EXISTS resume_data TEXT;"))
        db.session.execute(db.text("ALTER TABLE users ADD COLUMN IF NOT EXISTS experience_years INTEGER DEFAULT 0 NOT NULL;"))
        db.session.execute(db.text("ALTER TABLE users ADD COLUMN IF NOT EXISTS goals TEXT;"))
        db.session.execute(db.text("ALTER TABLE users ADD COLUMN IF NOT EXISTS parsed_resume_json JSON;"))
        
        db.session.execute(db.text("ALTER TABLE career_recommendations ADD COLUMN IF NOT EXISTS extra_data TEXT;"))
        db.session.execute(db.text("ALTER TABLE career_recommendations ADD COLUMN IF NOT EXISTS content_score DOUBLE PRECISION;"))
        db.session.execute(db.text("ALTER TABLE career_recommendations ADD COLUMN IF NOT EXISTS cf_score DOUBLE PRECISION;"))
        db.session.execute(db.text("ALTER TABLE career_recommendations ADD COLUMN IF NOT EXISTS final_score DOUBLE PRECISION;"))
        db.session.execute(db.text("ALTER TABLE career_recommendations ADD COLUMN IF NOT EXISTS career_role_id VARCHAR(100);"))
        
        db.session.execute(db.text("ALTER TABLE market_trends ADD COLUMN IF NOT EXISTS slug VARCHAR(255) UNIQUE;"))
        db.session.execute(db.text("ALTER TABLE market_trends ADD COLUMN IF NOT EXISTS required_skills TEXT[] DEFAULT '{}';"))
        
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print("Could not alter tables:", e)
    seed_market_trends()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
