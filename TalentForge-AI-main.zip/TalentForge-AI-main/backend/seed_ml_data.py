"""
Seed ML Training Data — seed_ml_data.py

This script populates the database with:
1. Career roles (MarketTrend with required_skills and slug)
2. Skill taxonomy (300+ skills)
3. Synthetic career ratings for SVD training (600 rows)

Run with: python seed_ml_data.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from app import create_app
from app.extensions import db
from app.models.market_trend import MarketTrend
from app.models.skill_taxonomy import SkillTaxonomy
from app.models.career_rating import CareerRating
import numpy as np
from datetime import datetime, timezone

app = create_app()

def seed_career_roles():
    """Seed 40 career roles with required_skills and slug."""
    print("[SEED] Creating career roles...")
    
    careers = [
        # Data & AI - 5 roles
        {
            "job_title": "Data Scientist",
            "slug": "data-scientist",
            "industry": "Technology",
            "category": "Data & AI",
            "demand_score": 92,
            "average_salary_lpa": 18,
            "growth_rate": 35,
            "is_trending": True,
            "required_skills": ["Python", "Machine Learning", "Statistics", "SQL", "Deep Learning", "Pandas", "Scikit-learn", "Data Visualization"],
            "top_skills_required": ["Python", "ML", "SQL", "Statistics", "Deep Learning"]
        },
        {
            "job_title": "ML Engineer",
            "slug": "ml-engineer",
            "industry": "Technology",
            "category": "Data & AI",
            "demand_score": 89,
            "average_salary_lpa": 20,
            "growth_rate": 40,
            "is_trending": True,
            "required_skills": ["Python", "TensorFlow", "PyTorch", "MLOps", "Docker", "Kubernetes", "SQL", "Feature Engineering"],
            "top_skills_required": ["Python", "TensorFlow", "PyTorch", "MLOps", "Docker"]
        },
        {
            "job_title": "Data Engineer",
            "slug": "data-engineer",
            "industry": "Technology",
            "category": "Data & AI",
            "demand_score": 85,
            "average_salary_lpa": 16,
            "growth_rate": 30,
            "is_trending": True,
            "required_skills": ["Python", "SQL", "Apache Spark", "Kafka", "Airflow", "AWS", "Data Warehousing", "ETL"],
            "top_skills_required": ["Python", "SQL", "Spark", "Kafka", "Airflow"]
        },
        {
            "job_title": "Data Analyst",
            "slug": "data-analyst",
            "industry": "Technology",
            "category": "Data & AI",
            "demand_score": 82,
            "average_salary_lpa": 10,
            "growth_rate": 22,
            "is_trending": True,
            "required_skills": ["SQL", "Python", "Excel", "Tableau", "Power BI", "Statistics", "Data Visualization", "Pandas"],
            "top_skills_required": ["SQL", "Python", "Excel", "Tableau", "Power BI"]
        },
        {
            "job_title": "AI Research Engineer",
            "slug": "ai-research-engineer",
            "industry": "Technology",
            "category": "Data & AI",
            "demand_score": 88,
            "average_salary_lpa": 28,
            "growth_rate": 55,
            "is_trending": True,
            "required_skills": ["Python", "PyTorch", "Research", "NLP", "Computer Vision", "Mathematics", "Statistics", "Transformers"],
            "top_skills_required": ["Python", "PyTorch", "NLP", "LLMs", "Transformers"]
        },
        # Backend/Full Stack - 5 roles
        {
            "job_title": "Backend Engineer",
            "slug": "backend-engineer",
            "industry": "Technology",
            "category": "Software Engineering",
            "demand_score": 85,
            "average_salary_lpa": 15,
            "growth_rate": 25,
            "is_trending": True,
            "required_skills": ["Python", "Java", "REST API", "SQL", "Docker", "System Design", "Redis", "Microservices"],
            "top_skills_required": ["Python", "Java", "REST API", "SQL", "Docker"]
        },
        {
            "job_title": "Frontend Developer",
            "slug": "frontend-developer",
            "industry": "Technology",
            "category": "Software Engineering",
            "demand_score": 80,
            "average_salary_lpa": 12,
            "growth_rate": 20,
            "is_trending": True,
            "required_skills": ["React", "JavaScript", "CSS", "HTML", "TypeScript", "Redux", "REST API", "Git"],
            "top_skills_required": ["React", "JavaScript", "TypeScript", "CSS", "HTML"]
        },
        {
            "job_title": "Full Stack Developer",
            "slug": "fullstack-developer",
            "industry": "Technology",
            "category": "Software Engineering",
            "demand_score": 88,
            "average_salary_lpa": 16,
            "growth_rate": 28,
            "is_trending": True,
            "required_skills": ["React", "Node.js", "Python", "SQL", "REST API", "Docker", "Git", "MongoDB"],
            "top_skills_required": ["React", "Node.js", "Python", "SQL", "Docker"]
        },
        {
            "job_title": "Mobile Developer",
            "slug": "mobile-developer",
            "industry": "Technology",
            "category": "Software Engineering",
            "demand_score": 79,
            "average_salary_lpa": 13,
            "growth_rate": 20,
            "is_trending": False,
            "required_skills": ["Flutter", "React Native", "Dart", "JavaScript", "Android", "iOS", "REST API", "Firebase"],
            "top_skills_required": ["Flutter", "React Native", "Dart", "Android", "iOS"]
        },
        {
            "job_title": "API Developer",
            "slug": "api-developer",
            "industry": "Technology",
            "category": "Software Engineering",
            "demand_score": 83,
            "average_salary_lpa": 14,
            "growth_rate": 23,
            "is_trending": True,
            "required_skills": ["Python", "Node.js", "REST API", "GraphQL", "SQL", "Redis", "OpenAPI", "Microservices"],
            "top_skills_required": ["Python", "REST API", "GraphQL", "SQL", "Microservices"]
        },
        # Infrastructure/DevOps - 5 roles
        {
            "job_title": "DevOps Engineer",
            "slug": "devops-engineer",
            "industry": "Technology",
            "category": "Infrastructure",
            "demand_score": 87,
            "average_salary_lpa": 17,
            "growth_rate": 32,
            "is_trending": True,
            "required_skills": ["Docker", "Kubernetes", "AWS", "CI/CD", "Linux", "Terraform", "Python", "Jenkins"],
            "top_skills_required": ["Docker", "Kubernetes", "AWS", "CI/CD", "Linux"]
        },
        {
            "job_title": "Cloud Architect",
            "slug": "cloud-architect",
            "industry": "Technology",
            "category": "Infrastructure",
            "demand_score": 84,
            "average_salary_lpa": 25,
            "growth_rate": 38,
            "is_trending": True,
            "required_skills": ["AWS", "Azure", "GCP", "Terraform", "Docker", "Kubernetes", "System Design", "Security"],
            "top_skills_required": ["AWS", "Azure", "GCP", "Terraform", "System Design"]
        },
        {
            "job_title": "Site Reliability Engineer",
            "slug": "sre",
            "industry": "Technology",
            "category": "Infrastructure",
            "demand_score": 86,
            "average_salary_lpa": 18,
            "growth_rate": 35,
            "is_trending": True,
            "required_skills": ["Linux", "Python", "Kubernetes", "Monitoring", "Incident Response", "Automation", "AWS", "Go"],
            "top_skills_required": ["Linux", "Python", "Kubernetes", "Monitoring", "Automation"]
        },
        {
            "job_title": "Network Engineer",
            "slug": "network-engineer",
            "industry": "Technology",
            "category": "Infrastructure",
            "demand_score": 81,
            "average_salary_lpa": 14,
            "growth_rate": 15,
            "is_trending": False,
            "required_skills": ["Networking", "Linux", "Cisco", "TCP/IP", "VPN", "Firewall", "BGP", "System Design"],
            "top_skills_required": ["Networking", "Linux", "Cisco", "TCP/IP", "System Design"]
        },
        {
            "job_title": "Platform Engineer",
            "slug": "platform-engineer",
            "industry": "Technology",
            "category": "Infrastructure",
            "demand_score": 80,
            "average_salary_lpa": 19,
            "growth_rate": 40,
            "is_trending": True,
            "required_skills": ["Kubernetes", "Docker", "Python", "Go", "System Design", "Infrastructure as Code", "Monitoring", "Helm"],
            "top_skills_required": ["Kubernetes", "Docker", "Python", "System Design", "Infrastructure as Code"]
        },
        # Security - 3 roles
        {
            "job_title": "Cybersecurity Analyst",
            "slug": "cybersecurity-analyst",
            "industry": "Technology",
            "category": "Security",
            "demand_score": 86,
            "average_salary_lpa": 14,
            "growth_rate": 45,
            "is_trending": True,
            "required_skills": ["Network Security", "Python", "Ethical Hacking", "SIEM", "Linux", "Cryptography", "Incident Response", "CEH"],
            "top_skills_required": ["Network Security", "Ethical Hacking", "Python", "Linux"]
        },
        {
            "job_title": "Security Engineer",
            "slug": "security-engineer",
            "industry": "Technology",
            "category": "Security",
            "demand_score": 85,
            "average_salary_lpa": 16,
            "growth_rate": 42,
            "is_trending": True,
            "required_skills": ["Security Architecture", "Python", "Linux", "AWS Security", "Cryptography", "Penetration Testing", "SIEM", "Vulnerability Management"],
            "top_skills_required": ["Security Architecture", "Python", "Linux", "Cryptography", "Penetration Testing"]
        },
        {
            "job_title": "Application Security Engineer",
            "slug": "app-security-engineer",
            "industry": "Technology",
            "category": "Security",
            "demand_score": 82,
            "average_salary_lpa": 15,
            "growth_rate": 40,
            "is_trending": True,
            "required_skills": ["OWASP", "Python", "Java", "Code Review", "Vulnerability Assessment", "Security Testing", "Web Security", "Database Security"],
            "top_skills_required": ["OWASP", "Python", "Code Review", "Vulnerability Assessment", "Web Security"]
        },
        # Web3/Blockchain - 2 roles
        {
            "job_title": "Blockchain Developer",
            "slug": "blockchain-developer",
            "industry": "Finance",
            "category": "Web3",
            "demand_score": 70,
            "average_salary_lpa": 20,
            "growth_rate": 50,
            "is_trending": True,
            "required_skills": ["Solidity", "Ethereum", "Web3.js", "Smart Contracts", "JavaScript", "Python", "Cryptography", "DeFi"],
            "top_skills_required": ["Solidity", "Ethereum", "Web3.js", "Smart Contracts"]
        },
        {
            "job_title": "Web3 Engineer",
            "slug": "web3-engineer",
            "industry": "Finance",
            "category": "Web3",
            "demand_score": 72,
            "average_salary_lpa": 18,
            "growth_rate": 48,
            "is_trending": True,
            "required_skills": ["Solidity", "JavaScript", "React", "Web3.py", "Ethereum", "Rust", "NFTs", "Token Economics"],
            "top_skills_required": ["Solidity", "JavaScript", "React", "Ethereum"]
        },
        # Design/UX - 2 roles
        {
            "job_title": "UI/UX Designer",
            "slug": "uiux-designer",
            "industry": "Design",
            "category": "Design",
            "demand_score": 75,
            "average_salary_lpa": 10,
            "growth_rate": 15,
            "is_trending": False,
            "required_skills": ["Figma", "Adobe XD", "User Research", "Wireframing", "Prototyping", "CSS", "HTML", "Design Systems"],
            "top_skills_required": ["Figma", "Adobe XD", "User Research", "Wireframing"]
        },
        {
            "job_title": "Product Designer",
            "slug": "product-designer",
            "industry": "Design",
            "category": "Design",
            "demand_score": 77,
            "average_salary_lpa": 12,
            "growth_rate": 18,
            "is_trending": True,
            "required_skills": ["Figma", "Product Strategy", "User Research", "Interaction Design", "Prototyping", "Analytics", "HTML", "CSS"],
            "top_skills_required": ["Figma", "Product Strategy", "User Research", "Interaction Design"]
        },
        # Product & Management - 3 roles
        {
            "job_title": "Product Manager",
            "slug": "product-manager",
            "industry": "Technology",
            "category": "Management",
            "demand_score": 78,
            "average_salary_lpa": 22,
            "growth_rate": 18,
            "is_trending": False,
            "required_skills": ["Product Strategy", "Agile", "JIRA", "Data Analysis", "Stakeholder Management", "Roadmapping", "SQL", "Communication"],
            "top_skills_required": ["Product Strategy", "Agile", "Data Analysis", "SQL"]
        },
        {
            "job_title": "Scrum Master",
            "slug": "scrum-master",
            "industry": "Technology",
            "category": "Management",
            "demand_score": 73,
            "average_salary_lpa": 11,
            "growth_rate": 12,
            "is_trending": False,
            "required_skills": ["Agile", "Scrum", "JIRA", "Communication", "Coaching", "Conflict Resolution", "Process Improvement", "Team Leadership"],
            "top_skills_required": ["Agile", "Scrum", "JIRA", "Communication", "Coaching"]
        },
        {
            "job_title": "Business Analyst",
            "slug": "business-analyst",
            "industry": "Technology",
            "category": "Management",
            "demand_score": 76,
            "average_salary_lpa": 9,
            "growth_rate": 16,
            "is_trending": True,
            "required_skills": ["Business Analysis", "SQL", "Excel", "JIRA", "Requirements Gathering", "Documentation", "Communication", "Process Improvement"],
            "top_skills_required": ["Business Analysis", "SQL", "Excel", "JIRA", "Requirements Gathering"]
        },
        # QA/Testing - 2 roles
        {
            "job_title": "QA Engineer",
            "slug": "qa-engineer",
            "industry": "Technology",
            "category": "Quality Assurance",
            "demand_score": 74,
            "average_salary_lpa": 8,
            "growth_rate": 14,
            "is_trending": False,
            "required_skills": ["Test Automation", "Selenium", "Python", "JIRA", "SQL", "Test Case Writing", "API Testing", "Performance Testing"],
            "top_skills_required": ["Test Automation", "Selenium", "Python", "JIRA", "SQL"]
        },
        {
            "job_title": "Automation Test Engineer",
            "slug": "automation-test-engineer",
            "industry": "Technology",
            "category": "Quality Assurance",
            "demand_score": 76,
            "average_salary_lpa": 9,
            "growth_rate": 17,
            "is_trending": True,
            "required_skills": ["Selenium", "Python", "TestNG", "Jenkins", "JIRA", "Cucumber", "API Testing", "Docker"],
            "top_skills_required": ["Selenium", "Python", "TestNG", "Jenkins", "API Testing"]
        },
        # Specialized - 8 roles
        {
            "job_title": "Database Administrator",
            "slug": "database-administrator",
            "industry": "Technology",
            "category": "Database",
            "demand_score": 77,
            "average_salary_lpa": 13,
            "growth_rate": 14,
            "is_trending": False,
            "required_skills": ["SQL Server", "PostgreSQL", "MongoDB", "Backup & Recovery", "Performance Tuning", "Security", "Python", "Linux"],
            "top_skills_required": ["SQL Server", "PostgreSQL", "MongoDB", "Performance Tuning", "Security"]
        },
        {
            "job_title": "NLP Engineer",
            "slug": "nlp-engineer",
            "industry": "Technology",
            "category": "Data & AI",
            "demand_score": 84,
            "average_salary_lpa": 22,
            "growth_rate": 48,
            "is_trending": True,
            "required_skills": ["Python", "NLP", "Transformers", "LLMs", "BERT", "PyTorch", "TensorFlow", "Spacy"],
            "top_skills_required": ["Python", "NLP", "Transformers", "LLMs", "PyTorch"]
        },
        {
            "job_title": "Computer Vision Engineer",
            "slug": "computer-vision-engineer",
            "industry": "Technology",
            "category": "Data & AI",
            "demand_score": 83,
            "average_salary_lpa": 21,
            "growth_rate": 46,
            "is_trending": True,
            "required_skills": ["Python", "OpenCV", "PyTorch", "TensorFlow", "Computer Vision", "Deep Learning", "Image Processing", "YOLO"],
            "top_skills_required": ["Python", "OpenCV", "PyTorch", "TensorFlow", "Computer Vision"]
        },
        {
            "job_title": "Embedded Systems Engineer",
            "slug": "embedded-systems-engineer",
            "industry": "Hardware",
            "category": "Embedded Systems",
            "demand_score": 72,
            "average_salary_lpa": 11,
            "growth_rate": 13,
            "is_trending": False,
            "required_skills": ["C", "C++", "ARM", "Real-time OS", "Microcontrollers", "FPGA", "Linux", "Device Drivers"],
            "top_skills_required": ["C", "C++", "ARM", "Microcontrollers", "FPGA"]
        },
        {
            "job_title": "IoT Engineer",
            "slug": "iot-engineer",
            "industry": "Hardware",
            "category": "IoT",
            "demand_score": 75,
            "average_salary_lpa": 12,
            "growth_rate": 25,
            "is_trending": True,
            "required_skills": ["Python", "IoT Platforms", "Arduino", "Raspberry Pi", "MQTT", "Network Protocols", "Edge Computing", "Cloud Integration"],
            "top_skills_required": ["Python", "IoT Platforms", "Arduino", "MQTT", "Edge Computing"]
        },
        {
            "job_title": "Game Developer",
            "slug": "game-developer",
            "industry": "Gaming",
            "category": "Game Development",
            "demand_score": 68,
            "average_salary_lpa": 14,
            "growth_rate": 20,
            "is_trending": False,
            "required_skills": ["Unity", "Unreal Engine", "C#", "C++", "Game Design", "Graphics Programming", "Physics", "Networking"],
            "top_skills_required": ["Unity", "Unreal Engine", "C#", "C++", "Game Design"]
        },
        {
            "job_title": "Solution Architect",
            "slug": "solution-architect",
            "industry": "Technology",
            "category": "Architecture",
            "demand_score": 81,
            "average_salary_lpa": 24,
            "growth_rate": 28,
            "is_trending": True,
            "required_skills": ["System Design", "Cloud Architecture", "AWS", "Azure", "Microservices", "API Design", "Security", "Communication"],
            "top_skills_required": ["System Design", "Cloud Architecture", "AWS", "Microservices", "API Design"]
        },
        # Additional Specialized roles - 6 roles
        {
            "job_title": "MLOps Engineer",
            "slug": "mlops-engineer",
            "industry": "Technology",
            "category": "Data & AI",
            "demand_score": 87,
            "average_salary_lpa": 19,
            "growth_rate": 52,
            "is_trending": True,
            "required_skills": ["Python", "Docker", "Kubernetes", "CI/CD", "ML Monitoring", "DVC", "Airflow", "Prometheus"],
            "top_skills_required": ["Python", "Docker", "Kubernetes", "CI/CD", "ML Monitoring"]
        },
        {
            "job_title": "FinTech Developer",
            "slug": "fintech-developer",
            "industry": "Finance",
            "category": "FinTech",
            "demand_score": 79,
            "average_salary_lpa": 18,
            "growth_rate": 35,
            "is_trending": True,
            "required_skills": ["Python", "Java", "SQL", "Blockchain", "Financial APIs", "Payment Systems", "Security", "Compliance"],
            "top_skills_required": ["Python", "Java", "SQL", "Blockchain", "Financial APIs"]
        },
        {
            "job_title": "DevSecOps Engineer",
            "slug": "devsecops-engineer",
            "industry": "Technology",
            "category": "Security",
            "demand_score": 84,
            "average_salary_lpa": 17,
            "growth_rate": 43,
            "is_trending": True,
            "required_skills": ["Docker", "Kubernetes", "Security Tools", "SAST", "DAST", "CI/CD", "Python", "AWS Security"],
            "top_skills_required": ["Docker", "Kubernetes", "Security Tools", "SAST", "CI/CD"]
        },
        {
            "job_title": "Data Science Manager",
            "slug": "data-science-manager",
            "industry": "Technology",
            "category": "Data & AI",
            "demand_score": 76,
            "average_salary_lpa": 26,
            "growth_rate": 30,
            "is_trending": True,
            "required_skills": ["Team Leadership", "Python", "ML", "Stakeholder Management", "Communication", "Data Strategy", "Budget Management", "Mentoring"],
            "top_skills_required": ["Team Leadership", "Python", "ML", "Data Strategy", "Communication"]
        },
        {
            "job_title": "Technical Writer",
            "slug": "technical-writer",
            "industry": "Technology",
            "category": "Documentation",
            "demand_score": 61,
            "average_salary_lpa": 7,
            "growth_rate": 8,
            "is_trending": False,
            "required_skills": ["Technical Writing", "API Documentation", "Markdown", "Git", "JIRA", "Tools (Confluence/Swagger)", "Communication", "Research"],
            "top_skills_required": ["Technical Writing", "API Documentation", "Markdown", "Git", "Tools (Confluence)"]
        },
        {
            "job_title": "Sales Engineer",
            "slug": "sales-engineer",
            "industry": "Technology",
            "category": "Sales",
            "demand_score": 68,
            "average_salary_lpa": 15,
            "growth_rate": 12,
            "is_trending": False,
            "required_skills": ["Technical Knowledge", "Sales Skills", "Communication", "Problem Solving", "Presentation", "Client Management", "Product Knowledge", "Negotiation"],
            "top_skills_required": ["Technical Knowledge", "Sales Skills", "Communication", "Presentation", "Client Management"]
        },
    ]
    
    count = 0
    for career_data in careers:
        existing = MarketTrend.query.filter_by(slug=career_data["slug"]).first()
        if not existing:
            trend = MarketTrend(
                job_title=career_data["job_title"],
                slug=career_data["slug"],
                industry=career_data["industry"],
                category=career_data["category"],
                demand_score=career_data["demand_score"],
                average_salary_lpa=career_data["average_salary_lpa"],
                growth_rate=career_data["growth_rate"],
                is_trending=career_data["is_trending"],
                required_skills=career_data["required_skills"],
                top_skills_required=career_data["top_skills_required"]
            )
            db.session.add(trend)
            count += 1
    
    db.session.commit()
    print(f"[SEED] Created {count} career roles")


def seed_skill_taxonomy():
    """Seed 300+ skills with categories and learning URLs."""
    print("[SEED] Creating skill taxonomy...")
    
    skills_data = [
        # PROGRAMMING LANGUAGES
        {"name": "Python", "category": "programming", "aliases": ["python3", "py", "python programming"],
         "url": "https://www.freecodecamp.org/learn/scientific-computing-with-python/"},
        {"name": "JavaScript", "category": "programming", "aliases": ["JS", "ES6", "ECMAScript"],
         "url": "https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/"},
        {"name": "Java", "category": "programming", "aliases": ["java programming", "core java"],
         "url": "https://www.youtube.com/watch?v=eIrMbAQSU34"},
        {"name": "SQL", "category": "programming", "aliases": ["mysql", "postgresql", "sqlite"],
         "url": "https://www.freecodecamp.org/learn/relational-database/"},
        {"name": "C++", "category": "programming", "aliases": ["cpp", "c plus plus"],
         "url": "https://www.youtube.com/watch?v=vLnPqZvg20U"},
        {"name": "C", "category": "programming", "aliases": ["c programming", "c language"],
         "url": "https://www.youtube.com/watch?v=KJgsSFOSQv0"},
        {"name": "Go", "category": "programming", "aliases": ["golang"],
         "url": "https://www.youtube.com/watch?v=un6ZyFkqFKo"},
        {"name": "Rust", "category": "programming", "aliases": ["rust language"],
         "url": "https://www.youtube.com/watch?v=OX9Z5haS2Sw"},
        {"name": "TypeScript", "category": "programming", "aliases": ["TS", "typescript"],
         "url": "https://www.freecodecamp.org/learn/frontend-development-libraries/"},
        {"name": "Kotlin", "category": "programming", "aliases": ["kotlin language"],
         "url": "https://www.youtube.com/watch?v=F9UC9sxS0Po"},
        {"name": "Swift", "category": "programming", "aliases": ["swift programming"],
         "url": "https://www.youtube.com/watch?v=comQ1-x2mgE"},
        {"name": "R", "category": "programming", "aliases": ["r language", "r programming"],
         "url": "https://www.youtube.com/watch?v=_V8eKsto3Ug"},
        {"name": "PHP", "category": "programming", "aliases": ["php language"],
         "url": "https://www.youtube.com/watch?v=OK_JCtrrv-c"},
        {"name": "Ruby", "category": "programming", "aliases": ["ruby language"],
         "url": "https://www.youtube.com/watch?v=t_isHoeyAOQ"},
        {"name": "Bash", "category": "programming", "aliases": ["shell", "shell scripting"],
         "url": "https://www.youtube.com/watch?v=e7BufAVwfWE"},
        {"name": "Scala", "category": "programming", "aliases": ["scala language"],
         "url": "https://www.youtube.com/watch?v=DzFt0YkZo8M"},
        {"name": "MATLAB", "category": "programming", "aliases": ["matlab"],
         "url": "https://www.youtube.com/watch?v=eqvPYFNJ3Fg"},
        {"name": "Lua", "category": "programming", "aliases": ["lua language"],
         "url": "https://www.youtube.com/watch?v=iMacxZQMPXs"},
        {"name": "Haskell", "category": "programming", "aliases": ["haskell language"],
         "url": "https://www.youtube.com/watch?v=02_H3LjqMr8"},
        {"name": "Lisp", "category": "programming", "aliases": ["common lisp"],
         "url": "https://www.youtube.com/watch?v=wBCWnF0bYeI"},
        
        # WEB FRAMEWORKS & LIBRARIES
        {"name": "React", "category": "web", "aliases": ["react.js", "reactjs"],
         "url": "https://react.dev/learn"},
        {"name": "Angular", "category": "web", "aliases": ["angular.js", "angularjs"],
         "url": "https://angular.io/start"},
        {"name": "Vue", "category": "web", "aliases": ["vue.js", "vuejs"],
         "url": "https://vuejs.org/guide/"},
        {"name": "Next.js", "category": "web", "aliases": ["nextjs"],
         "url": "https://nextjs.org/learn"},
        {"name": "Node.js", "category": "web", "aliases": ["nodejs", "node"],
         "url": "https://www.youtube.com/watch?v=ENrzD6iR-_E"},
        {"name": "Express", "category": "web", "aliases": ["express.js", "expressjs"],
         "url": "https://expressjs.com/"},
        {"name": "Django", "category": "web", "aliases": ["django framework"],
         "url": "https://www.djangoproject.com/start/"},
        {"name": "Flask", "category": "web", "aliases": ["flask framework"],
         "url": "https://flask.palletsprojects.com/"},
        {"name": "FastAPI", "category": "web", "aliases": ["fastapi"],
         "url": "https://fastapi.tiangolo.com/"},
        {"name": "Spring Boot", "category": "web", "aliases": ["spring", "springboot"],
         "url": "https://spring.io/projects/spring-boot"},
        {"name": "Ruby on Rails", "category": "web", "aliases": ["rails", "ror"],
         "url": "https://rubyonrails.org/"},
        {"name": "ASP.NET", "category": "web", "aliases": ["asp net", "aspnet"],
         "url": "https://learn.microsoft.com/en-us/aspnet/"},
        {"name": "GraphQL", "category": "web", "aliases": ["graphql"],
         "url": "https://graphql.org/learn/"},
        {"name": "REST API", "category": "web", "aliases": ["restful api", "rest"],
         "url": "https://restfulapi.net/"},
        {"name": "HTML", "category": "web", "aliases": ["html5"],
         "url": "https://www.freecodecamp.org/learn/responsive-web-design/"},
        {"name": "CSS", "category": "web", "aliases": ["css3", "stylesheet"],
         "url": "https://www.freecodecamp.org/learn/responsive-web-design/"},
        {"name": "Tailwind CSS", "category": "web", "aliases": ["tailwindcss"],
         "url": "https://tailwindcss.com/docs"},
        {"name": "Bootstrap", "category": "web", "aliases": ["bootstrap framework"],
         "url": "https://getbootstrap.com/docs/"},
        {"name": "Redux", "category": "web", "aliases": ["redux state"],
         "url": "https://redux.js.org/"},
        {"name": "Webpack", "category": "web", "aliases": ["webpack bundler"],
         "url": "https://webpack.js.org/"},
        
        # DATA & ML
        {"name": "Machine Learning", "category": "data", "aliases": ["ML", "machine learning algorithms"],
         "url": "https://www.coursera.org/learn/machine-learning"},
        {"name": "Deep Learning", "category": "data", "aliases": ["DL", "neural networks"],
         "url": "https://www.coursera.org/specializations/deep-learning"},
        {"name": "Pandas", "category": "data", "aliases": ["pandas library", "pandas dataframe"],
         "url": "https://www.youtube.com/watch?v=vmEHCJofslg"},
        {"name": "NumPy", "category": "data", "aliases": ["numpy library", "numpy array"],
         "url": "https://www.youtube.com/watch?v=9JUAPx75go4"},
        {"name": "Scikit-learn", "category": "data", "aliases": ["sklearn", "scikit learn"],
         "url": "https://www.youtube.com/watch?v=pTB5CucxA7c"},
        {"name": "TensorFlow", "category": "data", "aliases": ["tensorflow", "tf"],
         "url": "https://www.tensorflow.org/learn"},
        {"name": "PyTorch", "category": "data", "aliases": ["pytorch", "torch"],
         "url": "https://pytorch.org/tutorials/"},
        {"name": "Keras", "category": "data", "aliases": ["keras framework"],
         "url": "https://keras.io/getting_started/"},
        {"name": "Matplotlib", "category": "data", "aliases": ["matplotlib library"],
         "url": "https://www.youtube.com/watch?v=3Xc3CA655Y4"},
        {"name": "Seaborn", "category": "data", "aliases": ["seaborn library"],
         "url": "https://www.youtube.com/watch?v=6GUZXDef2U0"},
        {"name": "Plotly", "category": "data", "aliases": ["plotly library"],
         "url": "https://plotly.com/python/"},
        {"name": "Statistics", "category": "data", "aliases": ["statistics", "statistical analysis"],
         "url": "https://www.youtube.com/watch?v=xxpc-SQ5d_8"},
        {"name": "Data Visualization", "category": "data", "aliases": ["visualization", "charts"],
         "url": "https://www.youtube.com/watch?v=dBinL3qKiic"},
        {"name": "Feature Engineering", "category": "data", "aliases": ["feature extraction"],
         "url": "https://www.youtube.com/watch?v=6c6qyW-AxXU"},
        {"name": "NLP", "category": "data", "aliases": ["natural language processing"],
         "url": "https://www.youtube.com/watch?v=cmxFkJichC0"},
        {"name": "Computer Vision", "category": "data", "aliases": ["computer vision", "cv"],
         "url": "https://www.youtube.com/watch?v=yIUZZ5rOkPY"},
        {"name": "Time Series", "category": "data", "aliases": ["time series analysis"],
         "url": "https://www.youtube.com/watch?v=e8Yw4alG16Q"},
        {"name": "A/B Testing", "category": "data", "aliases": ["ab testing", "experimentation"],
         "url": "https://www.youtube.com/watch?v=xHmy_ctIh-c"},
        {"name": "Data Wrangling", "category": "data", "aliases": ["data cleaning", "data preprocessing"],
         "url": "https://www.youtube.com/watch?v=8YRWICPM8Jw"},
        {"name": "ETL", "category": "data", "aliases": ["extract transform load"],
         "url": "https://www.youtube.com/watch?v=PbNKbhCdELw"},
        {"name": "Data Warehousing", "category": "data", "aliases": ["data warehouse"],
         "url": "https://www.youtube.com/watch?v=aKKmK2JVWEA"},
        {"name": "Apache Spark", "category": "data", "aliases": ["spark", "pyspark"],
         "url": "https://spark.apache.org/docs/latest/"},
        {"name": "Kafka", "category": "data", "aliases": ["apache kafka"],
         "url": "https://kafka.apache.org/documentation/"},
        {"name": "Airflow", "category": "data", "aliases": ["apache airflow"],
         "url": "https://airflow.apache.org/docs/"},
        {"name": "dbt", "category": "data", "aliases": ["data build tool"],
         "url": "https://docs.getdbt.com/"},
        {"name": "Tableau", "category": "data", "aliases": ["tableau dashboard"],
         "url": "https://www.tableau.com/learn"},
        {"name": "Power BI", "category": "data", "aliases": ["powerbi"],
         "url": "https://learn.microsoft.com/en-us/power-bi/"},
        {"name": "Excel", "category": "data", "aliases": ["ms excel", "spreadsheet"],
         "url": "https://www.youtube.com/watch?v=rwbho0CgEAE"},
        {"name": "BigQuery", "category": "data", "aliases": ["google bigquery"],
         "url": "https://cloud.google.com/bigquery/docs"},
        {"name": "Snowflake", "category": "data", "aliases": ["snowflake database"],
         "url": "https://docs.snowflake.com/"},
        {"name": "Databricks", "category": "data", "aliases": ["databricks platform"],
         "url": "https://docs.databricks.com/"},
        {"name": "Spacy", "category": "data", "aliases": ["spacy nlp"],
         "url": "https://spacy.io/"},
        {"name": "OpenCV", "category": "data", "aliases": ["opencv library"],
         "url": "https://docs.opencv.org/"},
        {"name": "LLMs", "category": "data", "aliases": ["large language models"],
         "url": "https://www.youtube.com/watch?v=jkrNMKz9pWU"},
        {"name": "Transformers", "category": "data", "aliases": ["transformer models", "bert"],
         "url": "https://huggingface.co/course"},
        
        # CLOUD & DEVOPS
        {"name": "AWS", "category": "cloud", "aliases": ["amazon aws", "aws cloud"],
         "url": "https://aws.amazon.com/getting-started/"},
        {"name": "Azure", "category": "cloud", "aliases": ["microsoft azure"],
         "url": "https://learn.microsoft.com/en-us/azure/"},
        {"name": "GCP", "category": "cloud", "aliases": ["google cloud", "google cloud platform"],
         "url": "https://cloud.google.com/docs"},
        {"name": "Docker", "category": "cloud", "aliases": ["docker container"],
         "url": "https://docs.docker.com/get-started/"},
        {"name": "Kubernetes", "category": "cloud", "aliases": ["k8s", "kubernetes"],
         "url": "https://kubernetes.io/docs/"},
        {"name": "Terraform", "category": "cloud", "aliases": ["terraform iac"],
         "url": "https://www.terraform.io/docs"},
        {"name": "CI/CD", "category": "cloud", "aliases": ["continuous integration"],
         "url": "https://www.youtube.com/watch?v=1er-Z4IseTI"},
        {"name": "Jenkins", "category": "cloud", "aliases": ["jenkins ci"],
         "url": "https://www.jenkins.io/doc/"},
        {"name": "GitHub Actions", "category": "cloud", "aliases": ["github actions ci"],
         "url": "https://docs.github.com/en/actions"},
        {"name": "Linux", "category": "cloud", "aliases": ["linux os", "linux kernel"],
         "url": "https://www.linux.org/"},
        {"name": "Nginx", "category": "cloud", "aliases": ["nginx server"],
         "url": "https://nginx.org/en/docs/"},
        {"name": "Redis", "category": "cloud", "aliases": ["redis cache"],
         "url": "https://redis.io/docs/"},
        {"name": "Elasticsearch", "category": "cloud", "aliases": ["elastic search"],
         "url": "https://www.elastic.co/guide/"},
        {"name": "Prometheus", "category": "cloud", "aliases": ["prometheus monitoring"],
         "url": "https://prometheus.io/docs/"},
        {"name": "Grafana", "category": "cloud", "aliases": ["grafana dashboard"],
         "url": "https://grafana.com/docs/"},
        {"name": "Ansible", "category": "cloud", "aliases": ["ansible automation"],
         "url": "https://docs.ansible.com/"},
        {"name": "Puppet", "category": "cloud", "aliases": ["puppet config"],
         "url": "https://puppet.com/docs/"},
        {"name": "Chef", "category": "cloud", "aliases": ["chef automation"],
         "url": "https://docs.chef.io/"},
        {"name": "Helm", "category": "cloud", "aliases": ["helm charts"],
         "url": "https://helm.sh/docs/"},
        {"name": "ArgoCD", "category": "cloud", "aliases": ["argo cd"],
         "url": "https://argo-cd.readthedocs.io/"},
        {"name": "MLOps", "category": "cloud", "aliases": ["ml ops", "machine learning ops"],
         "url": "https://www.youtube.com/watch?v=K3LAGsKvjc4"},
        {"name": "DataOps", "category": "cloud", "aliases": ["data ops"],
         "url": "https://www.youtube.com/watch?v=Fg7mXlRixXo"},
        {"name": "Infrastructure as Code", "category": "cloud", "aliases": ["iac", "infrastructure code"],
         "url": "https://www.youtube.com/watch?v=POPP2ulAaFU"},
        
        # SOFT SKILLS
        {"name": "Communication", "category": "soft_skill", "aliases": ["communication skills"],
         "url": "https://www.youtube.com/watch?v=HAnw168huqA"},
        {"name": "Leadership", "category": "soft_skill", "aliases": ["team leadership"],
         "url": "https://www.youtube.com/watch?v=a8fBQUZSW8o"},
        {"name": "Problem Solving", "category": "soft_skill", "aliases": ["problem solving skills"],
         "url": "https://www.youtube.com/watch?v=AGRlFO6KSSU"},
        {"name": "Teamwork", "category": "soft_skill", "aliases": ["team work", "collaboration"],
         "url": "https://www.youtube.com/watch?v=tYzMGQUUU6U"},
        {"name": "Agile", "category": "soft_skill", "aliases": ["agile methodology"],
         "url": "https://www.youtube.com/watch?v=Xo-RxnH9NY4"},
        {"name": "Scrum", "category": "soft_skill", "aliases": ["scrum framework"],
         "url": "https://www.youtube.com/watch?v=KyprQm-njeE"},
        {"name": "JIRA", "category": "soft_skill", "aliases": ["jira issue tracking"],
         "url": "https://www.atlassian.com/software/jira"},
        {"name": "Stakeholder Management", "category": "soft_skill", "aliases": ["stakeholder mgmt"],
         "url": "https://www.youtube.com/watch?v=5K8nN-uJl9A"},
        {"name": "Project Management", "category": "soft_skill", "aliases": ["project mgmt"],
         "url": "https://www.youtube.com/watch?v=K0TnpPYfW70"},
        {"name": "Presentation", "category": "soft_skill", "aliases": ["presentations", "public speaking"],
         "url": "https://www.youtube.com/watch?v=DZ6wjbTgr7E"},
    ]
    
    count = 0
    for skill_data in skills_data:
        existing = SkillTaxonomy.query.filter_by(skill_name=skill_data["name"]).first()
        if not existing:
            taxonomy = SkillTaxonomy(
                skill_name=skill_data["name"],
                category=skill_data["category"],
                aliases=skill_data["aliases"],
                learning_url=skill_data.get("url")
            )
            db.session.add(taxonomy)
            count += 1
    
    db.session.commit()
    print(f"[SEED] Created {count} skill taxonomy entries")
    
    # Sync PostgreSQL sequence for skill_taxonomy
    try:
        db.session.execute(db.text("SELECT setval(pg_get_serial_sequence('skill_taxonomy', 'id'), COALESCE(max(id), 1)) FROM skill_taxonomy;"))
        db.session.commit()
        print("[SEED] Synchronized skill_taxonomy sequence to maximum ID")
    except Exception as seq_err:
        db.session.rollback()
        print(f"[SEED] Warning: Could not synchronize skill_taxonomy sequence: {seq_err}")


def seed_career_ratings():
    """Seed 600 synthetic career ratings for SVD training."""
    print("[SEED] Creating synthetic career ratings...")
    
    # Get all career slugs
    careers = MarketTrend.query.filter(MarketTrend.slug.isnot(None)).all()
    career_slugs = [c.slug for c in careers]
    
    if len(career_slugs) < 5:
        print("[SEED] Insufficient careers. Skipping rating seed.")
        return
    
    # User preference groups
    data_user_careers = ["data-scientist", "ml-engineer", "data-analyst", "data-engineer", "ai-research-engineer", "nlp-engineer", "computer-vision-engineer", "mlops-engineer"]
    software_user_careers = ["backend-engineer", "frontend-developer", "fullstack-developer", "mobile-developer", "api-developer", "platform-engineer"]
    infra_user_careers = ["devops-engineer", "cloud-architect", "sre", "network-engineer", "security-engineer", "devsecops-engineer"]
    
    # Filter to existing careers
    data_careers = [c for c in data_user_careers if c in career_slugs]
    software_careers = [c for c in software_user_careers if c in career_slugs]
    infra_careers = [c for c in infra_user_careers if c in career_slugs]
    other_careers = [c for c in career_slugs if c not in data_careers and c not in software_careers and c not in infra_careers]
    
    count = 0
    np.random.seed(42)
    
    # Synthetic users 1-70: data science users
    for user_num in range(1, 71):
        uid = f"synth_{user_num}"
        rated = set()
        
        # Rate in-group careers highly
        num_in_group = np.random.randint(8, 13)
        for career in np.random.choice(data_careers, min(num_in_group, len(data_careers)), replace=False):
            if career not in rated:
                rating = float(np.clip(np.random.normal(4.0, 0.5), 1.0, 5.0))
                rating_obj = CareerRating(user_id=uid, career_slug=career, rating=rating, source='synthetic')
                db.session.add(rating_obj)
                rated.add(career)
                count += 1
        
        # Rate out-group careers low
        num_out_group = np.random.randint(3, 6)
        other_options = [c for c in software_careers + infra_careers + other_careers if c not in rated]
        for career in np.random.choice(other_options, min(num_out_group, len(other_options)), replace=False):
            if career not in rated:
                rating = float(np.clip(np.random.normal(1.5, 0.5), 1.0, 5.0))
                rating_obj = CareerRating(user_id=uid, career_slug=career, rating=rating, source='synthetic')
                db.session.add(rating_obj)
                rated.add(career)
                count += 1
    
    # Synthetic users 71-140: software engineering users
    for user_num in range(71, 141):
        uid = f"synth_{user_num}"
        rated = set()
        
        num_in_group = np.random.randint(8, 13)
        for career in np.random.choice(software_careers, min(num_in_group, len(software_careers)), replace=False):
            if career not in rated:
                rating = float(np.clip(np.random.normal(4.0, 0.5), 1.0, 5.0))
                rating_obj = CareerRating(user_id=uid, career_slug=career, rating=rating, source='synthetic')
                db.session.add(rating_obj)
                rated.add(career)
                count += 1
        
        num_out_group = np.random.randint(3, 6)
        other_options = [c for c in data_careers + infra_careers + other_careers if c not in rated]
        for career in np.random.choice(other_options, min(num_out_group, len(other_options)), replace=False):
            if career not in rated:
                rating = float(np.clip(np.random.normal(1.5, 0.5), 1.0, 5.0))
                rating_obj = CareerRating(user_id=uid, career_slug=career, rating=rating, source='synthetic')
                db.session.add(rating_obj)
                rated.add(career)
                count += 1
    
    # Synthetic users 141-200: infrastructure users
    for user_num in range(141, 201):
        uid = f"synth_{user_num}"
        rated = set()
        
        num_in_group = np.random.randint(8, 13)
        for career in np.random.choice(infra_careers, min(num_in_group, len(infra_careers)), replace=False):
            if career not in rated:
                rating = float(np.clip(np.random.normal(4.0, 0.5), 1.0, 5.0))
                rating_obj = CareerRating(user_id=uid, career_slug=career, rating=rating, source='synthetic')
                db.session.add(rating_obj)
                rated.add(career)
                count += 1
        
        num_out_group = np.random.randint(3, 6)
        other_options = [c for c in data_careers + software_careers + other_careers if c not in rated]
        for career in np.random.choice(other_options, min(num_out_group, len(other_options)), replace=False):
            if career not in rated:
                rating = float(np.clip(np.random.normal(1.5, 0.5), 1.0, 5.0))
                rating_obj = CareerRating(user_id=uid, career_slug=career, rating=rating, source='synthetic')
                db.session.add(rating_obj)
                rated.add(career)
                count += 1
    
    db.session.commit()
    print(f"[SEED] Created {count} synthetic career ratings")
    
    # Sync PostgreSQL sequence to prevent future UniqueViolation errors during user inserts
    try:
        db.session.execute(db.text("SELECT setval(pg_get_serial_sequence('career_ratings', 'id'), COALESCE(max(id), 1)) FROM career_ratings;"))
        db.session.commit()
        print("[SEED] Synchronized career_ratings sequence to maximum ID")
    except Exception as seq_err:
        db.session.rollback()
        print(f"[SEED] Warning: Could not synchronize sequence: {seq_err}")


if __name__ == "__main__":
    with app.app_context():
        print("=" * 60)
        print("[SEED] Ensuring database columns exist...")
        print("=" * 60)
        
        db.create_all()
        try:
            db.session.execute(db.text("ALTER TABLE users ADD COLUMN IF NOT EXISTS resume_data TEXT;"))
            db.session.execute(db.text("ALTER TABLE users ADD COLUMN IF NOT EXISTS experience_years INTEGER DEFAULT 0 NOT NULL;"))
            db.session.execute(db.text("ALTER TABLE users ADD COLUMN IF NOT EXISTS goals TEXT;"))
            db.session.execute(db.text("ALTER TABLE users ADD COLUMN IF NOT EXISTS parsed_resume_json JSON;"))
            
            db.session.execute(db.text("ALTER TABLE career_recommendations ADD COLUMN IF NOT EXISTS extra_data TEXT;"))
            db.session.execute(db.text("ALTER TABLE career_recommendations ADD COLUMN IF NOT EXISTS content_score DOUBLE PRECISION;"))
            db.session.execute(db.text("ALTER TABLE career_recommendations ADD COLUMN IF NOT EXISTS cf_score DOUBLE PRECISION;"))
            db.session.execute(db.text("ALTER TABLE career_recommendations ADD COLUMN IF NOT EXISTS final_score DOUBLE PRECISION;"))
            db.session.execute(db.text("ALTER TABLE career_recommendations ADD COLUMN IF NOT EXISTS career_role_id VARCHAR(100);"))
            
            db.session.execute(db.text("ALTER TABLE market_trends ADD COLUMN IF NOT EXISTS slug VARCHAR(255) UNIQUE;"))
            db.session.execute(db.text("ALTER TABLE market_trends ADD COLUMN IF NOT EXISTS required_skills TEXT[] DEFAULT '{}';"))
            
            db.session.commit()
            print("[SEED] Table alterations successful!")
        except Exception as e:
            db.session.rollback()
            print("[SEED] Could not alter tables:", e)

        print("=" * 60)
        print("[SEED] Starting ML data seeding...")
        print("=" * 60)
        
        seed_career_roles()
        seed_skill_taxonomy()
        seed_career_ratings()
        
        print("=" * 60)
        print("[SEED] ML data seeding completed!")
        print("=" * 60)
