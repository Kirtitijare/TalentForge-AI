-- Run this once against your PostgreSQL database before starting the app
-- psql -U postgres -d talentforge -f init_db.sql

-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Add vector column to users table after SQLAlchemy creates it
-- (SQLAlchemy creates the table without the vector type; this adds it)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'users' AND column_name = 'skill_embedding'
    ) THEN
        ALTER TABLE users ADD COLUMN skill_embedding vector(384);
    ELSE
        -- If it was created as TEXT by SQLAlchemy, convert it
        ALTER TABLE users ALTER COLUMN skill_embedding TYPE vector(384)
        USING skill_embedding::vector;
    END IF;
END $$;

-- Index for fast nearest-neighbor search on skill embeddings
CREATE INDEX IF NOT EXISTS users_skill_embedding_idx
    ON users USING ivfflat (skill_embedding vector_cosine_ops)
    WITH (lists = 100);

-- Index for common queries
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email) WHERE is_deleted = FALSE;
CREATE INDEX IF NOT EXISTS idx_recs_user_id ON career_recommendations(user_id) WHERE is_deleted = FALSE;
CREATE INDEX IF NOT EXISTS idx_otp_email ON otp_verifications(email);
CREATE INDEX IF NOT EXISTS idx_chat_user_id ON chat_sessions(user_id);
