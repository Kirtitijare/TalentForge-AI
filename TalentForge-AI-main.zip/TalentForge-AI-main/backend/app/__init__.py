from flask import Flask
from flask_cors import CORS
from .extensions import db, migrate, jwt, mail
from .config import config_by_name
import os


def create_app(config_name: str = None) -> Flask:
    app = Flask(__name__)

    # Load config
    env = config_name or os.getenv("FLASK_ENV", "development")
    app.config.from_object(config_by_name[env])

    # Extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    mail.init_app(app)
    CORS(app, resources={r"/api/*": {"origins": app.config["FRONTEND_URL"]}},
         supports_credentials=True)

    # Register blueprints
    from .routes.auth import auth_bp
    from .routes.career import career_bp
    from .routes.resume import resume_bp
    from .routes.skill_gap import skill_gap_bp
    from .routes.learning_path import learning_path_bp
    from .routes.market_trends import market_trends_bp
    from .routes.chat import chat_bp
    from .routes.collaborative import collaborative_bp
    from .routes.report import report_bp
    from .routes.profile import profile_bp
    from .routes.admin import admin_bp
    from .routes.career_trajectory import career_trajectory_bp
    from .routes.skill_synergy import skill_synergy_bp

    app.register_blueprint(auth_bp,           url_prefix="/api/auth")
    app.register_blueprint(career_bp,         url_prefix="/api/career")
    app.register_blueprint(resume_bp,         url_prefix="/api/resume")
    app.register_blueprint(skill_gap_bp,      url_prefix="/api/skill-gap")
    app.register_blueprint(learning_path_bp,  url_prefix="/api/learning-path")
    app.register_blueprint(market_trends_bp,  url_prefix="/api/market-trends")
    app.register_blueprint(chat_bp,           url_prefix="/api/chat")
    app.register_blueprint(collaborative_bp,  url_prefix="/api/collaborative")
    app.register_blueprint(report_bp,         url_prefix="/api/report")
    app.register_blueprint(profile_bp,        url_prefix="/api/profile")
    app.register_blueprint(admin_bp,          url_prefix="/api/admin")
    app.register_blueprint(career_trajectory_bp, url_prefix="/api/career-trajectory")
    app.register_blueprint(skill_synergy_bp,  url_prefix="/api/skill-synergy")


    # Health check
    @app.get("/api/health")
    def health():
        return {"status": "ok", "env": env}

    return app
