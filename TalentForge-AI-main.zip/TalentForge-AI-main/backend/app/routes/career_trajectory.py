"""
Career Trajectory routes — /api/career-trajectory/*
Monte Carlo career path simulation.
"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..models.user import User
from ..services.career_trajectory_service import (
    simulate_career_trajectory,
    get_career_progression_graph,
)
from ..utils.auth import success, error

career_trajectory_bp = Blueprint("career_trajectory", __name__)


@career_trajectory_bp.post("/simulate")
@jwt_required()
def simulate():
    """
    Body: { targetCareer? }
    Simulate career trajectories from user's current skills.
    Returns multiple possible career paths with salary projections.
    """
    data = request.get_json(silent=True) or {}
    target_career = (data.get("targetCareer") or "").strip() or None

    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    skills = user.skills or []
    if not skills:
        return error(
            "Please add skills to your profile first. "
            "Go to Profile page or upload your resume.",
            400,
        )

    try:
        result = simulate_career_trajectory(
            user_skills=skills,
            target_career=target_career,
            num_paths=4,
            horizon_years=10,
        )
        return success(result, "Career trajectory simulated")
    except Exception as exc:
        return error(f"Simulation failed: {exc}", 500)


@career_trajectory_bp.get("/graph")
def get_graph():
    """Return the full career progression graph for visualization."""
    graph = get_career_progression_graph()
    return success({
        "graph": graph,
        "careers": list(graph.keys()),
    })
