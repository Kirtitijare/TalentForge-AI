"""
Resume routes — /api/resume/*
Mirrors C# ResumeController.
Handles PDF upload, text extraction (pdfplumber), spaCy skill extraction,
Groq analysis, and structured parsing.
"""
import os
import uuid
from flask import Blueprint, request, send_file, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..extensions import db
from ..models.user import User
from ..services import ai_service, nlp_service
from ..utils.auth import success, error

resume_bp = Blueprint("resume", __name__)

ALLOWED_EXTENSIONS = {"pdf"}


def _allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@resume_bp.post("/analyze")
@jwt_required()
def analyze_resume():
    """
    Multipart upload: field name = 'resume' (PDF).
    Returns { analysis, parsed, fileName }.
    """
    if "resume" not in request.files:
        return error("No resume file provided", 400)

    file = request.files["resume"]
    if not file or not file.filename:
        return error("Empty file", 400)
    if not _allowed_file(file.filename):
        return error("Only PDF files are accepted", 400)

    # Save file locally (or upload to S3 in production)
    upload_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], "resumes")
    os.makedirs(upload_dir, exist_ok=True)

    safe_name = f"{uuid.uuid4().hex}_{os.path.basename(file.filename)}"
    file_path = os.path.join(upload_dir, safe_name)
    file.save(file_path)

    # Extract text
    resume_text = nlp_service.extract_text_from_pdf(file_path)
    if not resume_text.strip():
        return error("Could not extract text from the PDF. Ensure it is a text-based PDF.", 422)

    # Run spaCy local skill extraction + Groq analysis + Groq structured parse in parallel
    # (Python threads for I/O-bound Groq calls)
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=2) as executor:
        analysis_future = executor.submit(ai_service.analyze_resume, resume_text)
        parsed_future = executor.submit(ai_service.parse_resume_structured, resume_text)

    analysis = analysis_future.result()
    parsed = parsed_future.result()

    # Merge spaCy-extracted skills with Groq-parsed skills
    spacy_skills = nlp_service.extract_skills_with_spacy(resume_text)
    all_skills = list({s.lower() for s in (parsed.get("skills", []) + spacy_skills)})
    parsed["skills"] = all_skills

    # Auto-update user profile skills and save parsed resume to database
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if user:
        if all_skills:
            existing = {s.lower() for s in (user.skills or [])}
            merged = list(user.skills or []) + [s for s in all_skills if s.lower() not in existing]
            user.skills = merged
        
        import json
        user.resume_data = json.dumps({
            "analysis": analysis,
            "parsed": parsed,
            "fileName": safe_name,
        })
        db.session.commit()

    return success({
        "analysis": analysis,
        "parsed": parsed,
        "fileName": safe_name,
    })


@resume_bp.get("/preview/<filename>")
@jwt_required()
def preview_resume(filename: str):
    """Serve an uploaded PDF for inline browser preview."""
    # Sanitise — only allow the file name, no path traversal
    safe_name = os.path.basename(filename)
    file_path = os.path.join(current_app.config["UPLOAD_FOLDER"], "resumes", safe_name)

    if not os.path.exists(file_path):
        return error("File not found", 404)

    return send_file(file_path, mimetype="application/pdf")
