"""
Auth routes — /api/auth/*
Mirrors C# AccountController (register, verify-otp, login, logout,
forgot-password, reset-password) + JWT refresh.
"""
import re
from datetime import datetime, timezone, timedelta
from flask import Blueprint, request
from flask_jwt_extended import (
    create_access_token, create_refresh_token,
    jwt_required, get_jwt_identity, get_jwt
)
from ..extensions import db
from ..models.user import User
from ..models.otp import OTPVerification
from ..services.email_service import send_otp_email
from ..utils.auth import hash_password, verify_password, generate_otp, success, error

auth_bp = Blueprint("auth", __name__)

PASSWORD_REGEX = re.compile(
    r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
)


@auth_bp.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    full_name = (data.get("fullName") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    # Validation
    if not full_name or not email or not password:
        return error("fullName, email, and password are required", 400)
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        return error("Invalid email address", 400)
    if not PASSWORD_REGEX.match(password):
        return error(
            "Password must be at least 8 characters and include uppercase, "
            "lowercase, digit, and special character (@$!%*?&)", 400
        )

    if User.query.filter_by(email=email, is_deleted=False).first():
        return error("Email already registered", 409)

    user = User(
        full_name=full_name,
        email=email,
        password_hash=hash_password(password),
    )
    db.session.add(user)
    db.session.flush()  # get user.id before commit

    otp_code = generate_otp()
    otp = OTPVerification(
        email=email,
        code=otp_code,
        expiry_time=datetime.now(timezone.utc) + timedelta(minutes=10),
        type="registration",
    )
    db.session.add(otp)
    db.session.commit()

    send_otp_email(email, otp_code, "registration")

    return success({"email": email}, "Registration successful. Check your email for the OTP.", 201)


@auth_bp.post("/verify-otp")
def verify_otp():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    code = (data.get("code") or "").strip()

    if not email or not code:
        return error("email and code are required", 400)

    otp = OTPVerification.query.filter_by(
        email=email, code=code, type="registration", is_used=False
    ).order_by(OTPVerification.created_at.desc()).first()

    if not otp or not otp.is_valid():
        return error("Invalid or expired OTP", 400)

    otp.is_used = True
    user = User.query.filter_by(email=email, is_deleted=False).first()
    if user:
        user.is_email_verified = True
    db.session.commit()

    return success(message="Email verified successfully. You can now log in.")


@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not email or not password:
        return error("email and password are required", 400)

    user = User.query.filter_by(email=email, is_deleted=False).first()
    if not user or not verify_password(password, user.password_hash):
        return error("Invalid email or password", 401)

    if not user.is_email_verified:
        return error("Please verify your email before logging in", 403)

    additional_claims = {"role": user.role, "fullName": user.full_name}
    access_token = create_access_token(
        identity=str(user.id), additional_claims=additional_claims
    )
    refresh_token = create_refresh_token(identity=str(user.id))

    return success({
        "accessToken": access_token,
        "refreshToken": refresh_token,
        "user": user.to_dict(),
    }, "Login successful")


@auth_bp.post("/refresh")
@jwt_required(refresh=True)
def refresh():
    identity = get_jwt_identity()
    user = User.query.get(identity)
    if not user or user.is_deleted:
        return error("User not found", 404)

    additional_claims = {"role": user.role, "fullName": user.full_name}
    access_token = create_access_token(
        identity=str(user.id), additional_claims=additional_claims
    )
    return success({"accessToken": access_token})


@auth_bp.post("/forgot-password")
def forgot_password():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()

    if not email:
        return error("email is required", 400)

    # Always return success to avoid user enumeration
    user = User.query.filter_by(email=email, is_deleted=False).first()
    if user:
        otp_code = generate_otp()
        otp = OTPVerification(
            email=email,
            code=otp_code,
            expiry_time=datetime.now(timezone.utc) + timedelta(minutes=15),
            type="password_reset",
        )
        db.session.add(otp)
        db.session.commit()
        send_otp_email(email, otp_code, "password_reset")

    return success(message="If that email exists, a reset code has been sent.")


@auth_bp.post("/reset-password")
def reset_password():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    code = (data.get("code") or "").strip()
    new_password = data.get("newPassword") or ""

    if not email or not code or not new_password:
        return error("email, code, and newPassword are required", 400)
    if not PASSWORD_REGEX.match(new_password):
        return error("Password does not meet complexity requirements", 400)

    otp = OTPVerification.query.filter_by(
        email=email, code=code, type="password_reset", is_used=False
    ).order_by(OTPVerification.created_at.desc()).first()

    if not otp or not otp.is_valid():
        return error("Invalid or expired reset code", 400)

    user = User.query.filter_by(email=email, is_deleted=False).first()
    if not user:
        return error("User not found", 404)

    user.password_hash = hash_password(new_password)
    user.is_email_verified = True
    otp.is_used = True
    db.session.commit()

    return success(message="Password reset successfully. You can now log in.")


@auth_bp.get("/me")
@jwt_required()
def me():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)
    return success(user.to_dict())
