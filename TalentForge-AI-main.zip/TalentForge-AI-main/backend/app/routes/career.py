"""
Career routes — /api/career/*
Enhanced with SVD hybrid ML recommendation engine & live feedback retraining loops.
"""
from datetime import datetime, timezone
import json
import re
from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..extensions import db
from ..models.user import User
from ..models.recommendation import CareerRecommendation
from ..models.career_rating import CareerRating
from ..services import ai_service
from ..services.ml_hybrid_service import hybrid_recommend, train_svd_model
from ..utils.auth import success, error

career_bp = Blueprint("career", __name__)


@career_bp.post("/recommend")
@jwt_required()
def get_recommendation():
    """
    Body: { interests, skills, academicBackground }
    Uses SVD hybrid ML scoring (content + collaborative + market) & online feedback.
    """
    data = request.get_json(silent=True) or {}
    interests = data.get("interests", "")
    skills_raw = data.get("skills", "")
    background = data.get("academicBackground", "")

    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    # Update user profile
    if skills_raw:
        if isinstance(skills_raw, list):
            new_skills = [s.strip() for s in skills_raw if s.strip()]
        else:
            new_skills = [s.strip() for s in skills_raw.split(",") if s.strip()]
        
        existing = set(s.lower() for s in (user.skills or []))
        merged = list(user.skills or []) + [s for s in new_skills if s.lower() not in existing]
        user.skills = merged

    if interests:
        if isinstance(interests, list):
            user.interests = [i.strip() for i in interests if i.strip()]
        else:
            user.interests = [i.strip() for i in interests.split(",") if i.strip()]

    if background:
        user.education = background

    db.session.commit()

    # Get hybrid recommendations (top 5)
    recommendations_list = hybrid_recommend(user_id=user.id, top_n=5)

    if not recommendations_list:
        return error("No recommended career paths could be generated. Ensure career roles are seeded.", 400)

    # Soft-delete all previous active recommendations to keep the dashboard clean & fresh
    CareerRecommendation.query.filter_by(user_id=user.id, is_deleted=False).update({"is_deleted": True})
    db.session.commit()

    # Let's get AI analysis for the top recommendation role to make it super premium
    top_career = recommendations_list[0]
    user_input = f"Interests: {user.interests}, Skills: {user.skills}, Background: {user.education}, Target Top Career: {top_career['job_title']}"
    try:
        ai_response = ai_service.get_career_recommendation(user_input)
        if ai_response:
            # Clean markdown bold/stars from title/lines
            ai_response = re.sub(r'\*\*+([^*]+)\*\*+', r'\1', ai_response)
            ai_response = re.sub(r'(?m)^[*_#\s]+([A-Za-z0-9])', r'\1', ai_response)
    except Exception as e:
        print(f"[API] AI description generation failed: {e}")
        ai_response = f"Highly matching role based on your skills and interests. Focus on acquiring: {', '.join(top_career['missing_skills'])}."

    saved_recs = []
    for i, item in enumerate(recommendations_list):
        desc = ai_response if i == 0 else f"A tailored fit based on your background and skills. Build your expertise in {', '.join(item['missing_skills'][:3])} to bridge your gap."
        
        # Prepare score breakdown
        c_score = item["content_score"]
        cf_score = item["cf_score"]
        f_score = item["final_score"]
        demand_pct = item["demand_score"] / 100.0 if item["demand_score"] else 0.5
        
        extra_dict = {
            "scoreBreakdown": {
                "content": round(c_score, 4),
                "collaborative": round(cf_score, 4),
                "market": round(demand_pct, 4)
            },
            "confidence": int(f_score * 100),
            "matchedSkills": [s for s in item["required_skills"] if s not in item["missing_skills"]],
            "missingSkills": item["missing_skills"],
            "learning_resources": item["learning_resources"],
            "avg_salary": item["avg_salary"],
            "demand_score": item["demand_score"],
            "growth_rate": item["growth_rate"],
            "industry": item["industry"]
        }

        # Check if the user has already rated this career
        existing_rating = CareerRating.query.filter_by(
            user_id=str(user.id),
            career_slug=item["career_slug"]
        ).first()
        extra_dict["userRating"] = existing_rating.rating if existing_rating else None

        slug = item.get("career_slug")
        if not slug and item.get("job_title"):
            slug = re.sub(r'[^a-z0-9]+', '-', item["job_title"].strip().lower()).strip('-')

        rec = CareerRecommendation(
            user_id=user.id,
            career_title=re.sub(r'^[\s*_#]+|[\s*_#]+$', '', item["job_title"]),
            career_role_id=slug,
            description=desc,
            match_percentage=item["match_percentage"],
            recommended_skills=item["required_skills"],
            roadmap_steps=[
                f"Master core competencies: {', '.join(item['missing_skills'][:2])}",
                "Review 6-Month interactive curriculum",
                "Earn verified credentials"
            ],
            ai_model_used="Unified Hybrid SVD + NumPy NCF + Llama-3.1",
            content_score=c_score,
            cf_score=cf_score,
            final_score=f_score,
            extra_data=json.dumps(extra_dict)
        )
        db.session.add(rec)
        saved_recs.append(rec)

    db.session.commit()

    return success([r.to_dict() for r in saved_recs], "Career recommendations generated successfully", 201)


@career_bp.get("/recommendations")
@jwt_required()
def list_recommendations():
    """Return all active recommendations for the current user."""
    user_id = get_jwt_identity()
    recs = CareerRecommendation.query.filter_by(
        user_id=user_id, is_deleted=False
    ).order_by(CareerRecommendation.final_score.desc()).all()
    
    results = []
    for r in recs:
        d = r.to_dict()
        existing_rating = CareerRating.query.filter_by(
            user_id=str(user_id),
            career_slug=r.career_role_id
        ).first()
        d["userRating"] = existing_rating.rating if existing_rating else None
        results.append(d)
        
    return success(results)


@career_bp.post("/feedback")
@jwt_required()
def submit_feedback():
    """
    Body: { careerSlug, careerTitle, rating }
    Saves/updates User's explicit rating for a career and triggers live SVD retraining.
    """
    data = request.get_json(silent=True) or {}
    career_slug = data.get("careerSlug")
    career_title = data.get("careerTitle")
    rating_val = data.get("rating")

    if not career_slug and career_title:
        career_slug = re.sub(r'[^a-z0-9]+', '-', career_title.strip().lower()).strip('-')

    if not career_slug or rating_val is None:
        return error("Please provide careerSlug and rating", 400)

    try:
        rating_val = float(rating_val)
        if not (1.0 <= rating_val <= 5.0):
            return error("Rating must be between 1.0 and 5.0", 400)
    except ValueError:
        return error("Invalid rating value", 400)

    user_id = get_jwt_identity()

    # Find or create rating
    rating_obj = CareerRating.query.filter_by(
        user_id=str(user_id),
        career_slug=career_slug
    ).first()

    if rating_obj:
        rating_obj.rating = rating_val
        rating_obj.created_at = datetime.now(timezone.utc)
    else:
        rating_obj = CareerRating(
            user_id=str(user_id),
            career_slug=career_slug,
            rating=rating_val,
            source="user"
        )
        db.session.add(rating_obj)

    db.session.commit()

    # Trigger live incremental SVD retraining!
    train_svd_model()

    return success(rating_obj.to_dict(), "Rating submitted and SVD model retrained successfully", 200)


@career_bp.delete("/recommendations/<rec_id>")
@jwt_required()
def delete_recommendation(rec_id):
    user_id = get_jwt_identity()
    rec = CareerRecommendation.query.filter_by(
        id=rec_id, user_id=user_id, is_deleted=False
    ).first()
    if not rec:
        return error("Recommendation not found", 404)
    rec.is_deleted = True
    db.session.commit()
    return success(message="Recommendation deleted")

