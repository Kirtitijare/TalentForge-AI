"""
Admin routes — /api/admin/*
All routes require admin role.
"""
import io
import re
from datetime import datetime, timedelta, timezone
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from ..extensions import db
from ..models.user import User
from ..models.recommendation import CareerRecommendation
from ..models.market_trend import MarketTrend
from ..models.skill_taxonomy import SkillTaxonomy
from ..models.career_rating import CareerRating
from ..utils.auth import admin_required, success, error
from ..services import ml_hybrid_service

admin_bp = Blueprint("admin", __name__)


def slugify(text: str) -> str:
    """Lowercase, hyphenated, alphanumeric only."""
    s = re.sub(r'[^a-z0-9]+', '-', text.lower().strip())
    return s.strip('-')


# --- Platform Dashboard ---
@admin_bp.get("/dashboard")
@admin_required
def dashboard():
    """Stats: total users, verified, admins, recs, avg match, common skills, counts, SVD, registrations."""
    total_users = User.query.filter_by(is_deleted=False).count()
    verified_users = User.query.filter_by(is_deleted=False, is_email_verified=True).count()
    admin_users = User.query.filter_by(is_deleted=False, role="admin").count()

    recs = CareerRecommendation.query.filter_by(is_deleted=False).all()
    total_recs = len(recs)
    avg_match = round(sum(r.match_percentage for r in recs) / total_recs, 1) if recs else 0

    from collections import Counter
    career_counter = Counter(r.career_title for r in recs)
    top_careers = [
        {"career": career, "count": count}
        for career, count in career_counter.most_common(5)
    ]

    total_ratings = CareerRating.query.count()
    career_roles_count = MarketTrend.query.count()
    skills_count = SkillTaxonomy.query.count()

    # Top skills across all registered users
    all_users = User.query.filter_by(is_deleted=False).all()
    skill_counter = Counter()
    for u in all_users:
        if u.skills:
            for s in u.skills:
                skill_counter[s] += 1
    top_skills = [
        {"skill": skill, "count": count}
        for skill, count in skill_counter.most_common(10)
    ]

    # SVD model last trained
    svd_trained_at = ml_hybrid_service._svd_trained_at
    svd_trained_at_str = svd_trained_at.isoformat() if svd_trained_at else None

    # Registrations in the last 7 days
    today = datetime.now(timezone.utc).date()
    day_counts = {}
    for i in range(7):
        day = today - timedelta(days=i)
        day_counts[day] = 0

    seven_days_ago = datetime.now(timezone.utc) - timedelta(days=7)
    recent_users = User.query.filter(
        User.is_deleted == False,
        User.created_at >= seven_days_ago
    ).all()

    for ru in recent_users:
        if ru.created_at:
            ru_date = ru.created_at.date()
            if ru_date in day_counts:
                day_counts[ru_date] += 1

    sorted_days = sorted(day_counts.keys())
    registrations_last_7_days = [
        {"date": day.strftime("%b %d"), "count": day_counts[day]}
        for day in sorted_days
    ]

    return success({
        "totalUsers": total_users,
        "verifiedUsers": verified_users,
        "adminCount": admin_users,
        "totalRecommendations": total_recs,
        "avgMatchScore": avg_match,
        "topCareers": top_careers,
        "totalRatings": total_ratings,
        "careerRolesCount": career_roles_count,
        "skillsCount": skills_count,
        "topSkills": top_skills,
        "svdLastTrained": svd_trained_at_str,
        "recentRegistrationsCount": len(recent_users),
        "registrationsTimeline": registrations_last_7_days
    })


# --- User Management ---
@admin_bp.get("/users")
@admin_required
def list_users():
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("perPage", 20, type=int)
    search = request.args.get("search", "").strip()
    role_filter = request.args.get("role", "").strip()
    verified_filter = request.args.get("verified", "").strip()

    query = User.query.filter_by(is_deleted=False)
    if search:
        query = query.filter(
            db.or_(
                User.full_name.ilike(f"%{search}%"),
                User.email.ilike(f"%{search}%"),
            )
        )
    if role_filter:
        query = query.filter(User.role == role_filter)
    if verified_filter:
        is_verified = verified_filter.lower() == "true"
        query = query.filter(User.is_email_verified == is_verified)

    paginated = query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return success({
        "users": [u.to_dict() for u in paginated.items],
        "total": paginated.total,
        "page": page,
        "pages": paginated.pages,
    })


@admin_bp.get("/users/<user_id>/profile")
@admin_required
def get_user_profile(user_id: str):
    """View user detailed profile including experience, goals, recommendations, and ratings. Suppresses passwords."""
    user = User.query.filter_by(id=user_id, is_deleted=False).first()
    if not user:
        return error("User not found", 404)

    recs = CareerRecommendation.query.filter_by(user_id=user_id, is_deleted=False).all()
    ratings = CareerRating.query.filter_by(user_id=user_id).all()

    data = user.to_dict()
    data.update({
        "experienceYears": user.experience_years,
        "goals": user.goals,
        "parsedResumeJson": user.parsed_resume_json,
        "recommendations": [r.to_dict() for r in recs],
        "ratings": [rt.to_dict() for rt in ratings]
    })
    return success(data)


@admin_bp.delete("/users/<user_id>")
@admin_required
def delete_user(user_id: str):
    user = User.query.filter_by(id=user_id, is_deleted=False).first()
    if not user:
        return error("User not found", 404)
    user.is_deleted = True
    db.session.commit()
    return success(message=f"User {user.full_name} deleted")


@admin_bp.patch("/users/<user_id>/promote")
@admin_required
def promote_to_admin(user_id: str):
    user = User.query.filter_by(id=user_id, is_deleted=False).first()
    if not user:
        return error("User not found", 404)
    user.role = "admin"
    db.session.commit()
    return success({"user": user.to_dict()}, f"{user.full_name} promoted to admin")


@admin_bp.patch("/users/<user_id>/demote")
@admin_required
def demote_from_admin(user_id: str):
    user = User.query.filter_by(id=user_id, is_deleted=False).first()
    if not user:
        return error("User not found", 404)
    user.role = "user"
    db.session.commit()
    return success({"user": user.to_dict()}, f"{user.full_name} demoted to user")


# --- Career Roles Manager (market_trends) ---
@admin_bp.get("/careers")
@admin_required
def list_careers():
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("perPage", 15, type=int)
    search = request.args.get("search", "").strip()

    query = MarketTrend.query
    if search:
        query = query.filter(
            db.or_(
                MarketTrend.job_title.ilike(f"%{search}%"),
                MarketTrend.category.ilike(f"%{search}%"),
                MarketTrend.industry.ilike(f"%{search}%")
            )
        )

    paginated = query.order_by(MarketTrend.job_title.asc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return success({
        "careers": [c.to_dict() for c in paginated.items],
        "total": paginated.total,
        "page": page,
        "pages": paginated.pages
    })


@admin_bp.post("/careers")
@admin_required
def create_career():
    data = request.json
    job_title = data.get("jobTitle", "").strip()
    if not job_title:
        return error("Job title is required", 400)

    slug = slugify(job_title)
    # Ensure unique slug
    base_slug = slug
    counter = 2
    while MarketTrend.query.filter_by(slug=slug).first():
        slug = f"{base_slug}-{counter}"
        counter += 1

    def parse_skills(s):
        if isinstance(s, list):
            return s
        if isinstance(s, str):
            return [x.strip() for x in s.split(",") if x.strip()]
        return []

    req_skills = parse_skills(data.get("requiredSkills"))
    top_skills = parse_skills(data.get("topSkillsRequired"))

    new_career = MarketTrend(
        job_title=job_title,
        slug=slug,
        category=data.get("category", "").strip(),
        industry=data.get("industry", "").strip(),
        demand_score=int(data.get("demandScore", 50)),
        average_salary_lpa=float(data.get("averageSalaryLPA", 0.0)),
        growth_rate=float(data.get("growthRate", 0.0)),
        is_trending=bool(data.get("isTrending", False)),
        required_skills=req_skills,
        top_skills_required=top_skills
    )

    db.session.add(new_career)
    db.session.commit()
    return success(new_career.to_dict(), "Career role created successfully")


@admin_bp.put("/careers/<career_id>")
@admin_required
def update_career(career_id: str):
    career = MarketTrend.query.get(career_id)
    if not career:
        return error("Career role not found", 404)

    data = request.json

    def parse_skills(s):
        if isinstance(s, list):
            return s
        if isinstance(s, str):
            return [x.strip() for x in s.split(",") if x.strip()]
        return []

    new_req_skills = parse_skills(data.get("requiredSkills"))
    new_top_skills = parse_skills(data.get("topSkillsRequired"))

    # Check for recommendation invalidation
    skills_changed = set(career.required_skills or []) != set(new_req_skills)

    career.job_title = data.get("jobTitle", career.job_title).strip()
    career.category = data.get("category", career.category).strip()
    career.industry = data.get("industry", career.industry).strip()
    career.demand_score = int(data.get("demandScore", career.demand_score))
    career.average_salary_lpa = float(data.get("averageSalaryLPA", career.average_salary_lpa))
    career.growth_rate = float(data.get("growthRate", career.growth_rate))
    career.is_trending = bool(data.get("isTrending", career.is_trending))
    career.required_skills = new_req_skills
    career.top_skills_required = new_top_skills

    # Invalidate recommendations if skills changed
    invalidated_count = 0
    if skills_changed and career.slug:
        recs_to_invalidate = CareerRecommendation.query.filter(
            CareerRecommendation.is_deleted == False,
            db.or_(
                CareerRecommendation.career_role_id == career.slug,
                CareerRecommendation.career_title == career.job_title
            )
        ).all()
        for r in recs_to_invalidate:
            r.is_deleted = True
            invalidated_count += 1

    db.session.commit()

    msg = "Career role updated successfully."
    if invalidated_count > 0:
        msg += f" {invalidated_count} stale recommendations invalidated."

    return success(career.to_dict(), msg)


@admin_bp.delete("/careers/<career_id>")
@admin_required
def delete_career(career_id: str):
    career = MarketTrend.query.get(career_id)
    if not career:
        return error("Career role not found", 404)

    # Invalidate all recommendations for this career slug/title
    if career.slug:
        CareerRecommendation.query.filter(
            CareerRecommendation.career_role_id == career.slug
        ).update({CareerRecommendation.is_deleted: True}, synchronize_session=False)

    db.session.delete(career)
    db.session.commit()
    return success(message=f"Career role {career.job_title} deleted and related recommendations invalidated")


@admin_bp.post("/retrain")
@admin_required
def retrain_svd():
    """Manual SVD model retraining trigger."""
    ml_hybrid_service.train_svd_model()
    trained_at = ml_hybrid_service._svd_trained_at
    trained_at_str = trained_at.isoformat() if trained_at else None
    return success({"trainedAt": trained_at_str}, "SVD Collaborative Filtering model retrained successfully")


# --- Skill Taxonomy Manager ---
@admin_bp.get("/skills")
@admin_required
def list_skills():
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("perPage", 20, type=int)
    search = request.args.get("search", "").strip()
    category = request.args.get("category", "").strip()

    query = SkillTaxonomy.query
    if search:
        query = query.filter(
            db.or_(
                SkillTaxonomy.skill_name.ilike(f"%{search}%"),
                SkillTaxonomy.aliases.any(search)
            )
        )
    if category:
        query = query.filter(SkillTaxonomy.category == category)

    paginated = query.order_by(SkillTaxonomy.skill_name.asc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return success({
        "skills": [s.to_dict() for s in paginated.items],
        "total": paginated.total,
        "page": page,
        "pages": paginated.pages
    })


@admin_bp.post("/skills")
@admin_required
def create_skill():
    data = request.json
    name = data.get("skillName", "").strip()
    if not name:
        return error("Skill name is required", 400)

    # Prevent duplicate names
    if SkillTaxonomy.query.filter_by(skill_name=name).first():
        return error(f"Skill '{name}' already exists in taxonomy", 400)

    def parse_aliases(al):
        if isinstance(al, list):
            return al
        if isinstance(al, str):
            return [x.strip() for x in al.split(",") if x.strip()]
        return []

    new_skill = SkillTaxonomy(
        skill_name=name,
        category=data.get("category", "").strip(),
        aliases=parse_aliases(data.get("aliases")),
        learning_url=data.get("learningUrl", "").strip()
    )

    db.session.add(new_skill)
    db.session.commit()
    return success(new_skill.to_dict(), "Skill added successfully to taxonomy")


@admin_bp.put("/skills/<int:skill_id>")
@admin_required
def update_skill(skill_id: int):
    skill = SkillTaxonomy.query.get(skill_id)
    if not skill:
        return error("Skill not found in taxonomy", 404)

    data = request.json
    name = data.get("skillName", "").strip()
    if not name:
        return error("Skill name is required", 400)

    # Prevent duplicate names if name changed
    existing = SkillTaxonomy.query.filter_by(skill_name=name).first()
    if existing and existing.id != skill_id:
        return error(f"Another skill '{name}' already exists in taxonomy", 400)

    def parse_aliases(al):
        if isinstance(al, list):
            return al
        if isinstance(al, str):
            return [x.strip() for x in al.split(",") if x.strip()]
        return []

    skill.skill_name = name
    skill.category = data.get("category", skill.category).strip()
    skill.aliases = parse_aliases(data.get("aliases"))
    skill.learning_url = data.get("learningUrl", "").strip()

    db.session.commit()
    return success(skill.to_dict(), "Skill updated successfully")


@admin_bp.delete("/skills/<int:skill_id>")
@admin_required
def delete_skill(skill_id: int):
    skill = SkillTaxonomy.query.get(skill_id)
    if not skill:
        return error("Skill not found in taxonomy", 404)

    db.session.delete(skill)
    db.session.commit()
    return success(message=f"Skill {skill.skill_name} removed from taxonomy")


@admin_bp.post("/skills/bulk")
@admin_required
def bulk_import_skills():
    """Bulk import skills from JSON array or raw CSV text."""
    data = request.json
    fmt = data.get("format", "json")
    raw_content = data.get("data")

    imported_count = 0
    errors = []

    if fmt == "json":
        import json
        try:
            if isinstance(raw_content, str):
                skills_list = json.loads(raw_content)
            else:
                skills_list = raw_content if isinstance(raw_content, list) else data.get("skills", [])
        except Exception as e:
            return error(f"Invalid JSON data: {e}", 400)

        for item in skills_list:
            name = (item.get("skillName") or item.get("skill_name") or "").strip()
            if not name:
                continue

            existing = SkillTaxonomy.query.filter_by(skill_name=name).first()
            if existing:
                continue

            aliases_raw = item.get("aliases", [])
            if isinstance(aliases_raw, str):
                aliases = [a.strip() for a in aliases_raw.split(",") if a.strip()]
            else:
                aliases = aliases_raw

            new_s = SkillTaxonomy(
                skill_name=name,
                category=item.get("category", "").strip(),
                aliases=aliases,
                learning_url=item.get("learningUrl") or item.get("learning_url") or ""
            )
            db.session.add(new_s)
            imported_count += 1

    elif fmt == "csv":
        import csv
        try:
            f = io.StringIO(raw_content.strip())
            reader = csv.DictReader(f)
            for row in reader:
                # normalize keys
                row_lower = {k.lower().replace("_", "").replace(" ", ""): v for k, v in row.items()}
                name = row_lower.get("skillname") or row_lower.get("name") or ""
                name = name.strip()
                if not name:
                    continue

                existing = SkillTaxonomy.query.filter_by(skill_name=name).first()
                if existing:
                    continue

                category = row_lower.get("category", "").strip()
                aliases_str = row_lower.get("aliases", "")
                aliases = [a.strip() for a in aliases_str.split(",") if a.strip()]
                learning_url = row_lower.get("learningurl") or row_lower.get("url") or ""

                new_s = SkillTaxonomy(
                    skill_name=name,
                    category=category,
                    aliases=aliases,
                    learning_url=learning_url.strip()
                )
                db.session.add(new_s)
                imported_count += 1
        except Exception as e:
            return error(f"Invalid CSV format or parsing error: {e}", 400)
    else:
        return error("Unsupported bulk format. Must be 'json' or 'csv'.", 400)

    db.session.commit()
    return success({"importedCount": imported_count}, f"Successfully imported {imported_count} skills into taxonomy.")


# --- Recommendations & Ratings Monitor ---
@admin_bp.get("/recommendations")
@admin_required
def list_recommendations():
    """List recommendations with filtering and details."""
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("perPage", 20, type=int)
    career_filter = request.args.get("career", "").strip()

    query = CareerRecommendation.query.filter_by(is_deleted=False)
    if career_filter:
        query = query.filter(CareerRecommendation.career_title.ilike(f"%{career_filter}%"))

    paginated = query.order_by(CareerRecommendation.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    recs_list = []
    for r in paginated.items:
        item = r.to_dict()
        u = User.query.filter_by(id=r.user_id).first()
        item["userEmail"] = u.email if u else "Deleted User"
        item["userFullName"] = u.full_name if u else "Deleted User"
        recs_list.append(item)

    return success({
        "recommendations": recs_list,
        "total": paginated.total,
        "page": page,
        "pages": paginated.pages
    })


@admin_bp.get("/ratings")
@admin_required
def list_ratings():
    """Paginated list of all career ratings with user profiles."""
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("perPage", 20, type=int)

    paginated = CareerRating.query.order_by(CareerRating.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    ratings_list = []
    for r in paginated.items:
        item = r.to_dict()
        u = User.query.filter_by(id=r.user_id).first()
        item["userEmail"] = u.email if u else "Deleted User"
        item["userFullName"] = u.full_name if u else "Deleted User"
        ratings_list.append(item)

    return success({
        "ratings": ratings_list,
        "total": paginated.total,
        "page": page,
        "pages": paginated.pages
    })


@admin_bp.get("/monitor-stats")
@admin_required
def monitor_stats():
    """Average ratings per career slug and synthetic vs real ratio."""
    from sqlalchemy import func

    # Avg rating per career slug
    avg_ratings = db.session.query(
        CareerRating.career_slug,
        func.avg(CareerRating.rating).label("avg_rating"),
        func.count(CareerRating.id).label("count")
    ).group_by(CareerRating.career_slug).order_by(func.avg(CareerRating.rating).desc()).all()

    trends = MarketTrend.query.all()
    slug_to_title = {t.slug: t.job_title for t in trends if t.slug}

    distribution = []
    for row in avg_ratings:
        distribution.append({
            "careerSlug": row.career_slug,
            "careerTitle": slug_to_title.get(row.career_slug, row.career_slug),
            "averageRating": round(float(row.avg_rating), 2),
            "count": int(row.count)
        })

    total_ratings = CareerRating.query.count()
    synthetic_count = CareerRating.query.filter_by(source="synthetic").count()
    real_count = total_ratings - synthetic_count

    synthetic_ratio = round((synthetic_count / total_ratings * 100), 1) if total_ratings else 0
    real_ratio = round((real_count / total_ratings * 100), 1) if total_ratings else 0

    return success({
        "distribution": distribution,
        "totalRatings": total_ratings,
        "syntheticCount": synthetic_count,
        "realCount": real_count,
        "syntheticPercentage": synthetic_ratio,
        "realPercentage": real_ratio
    })
