"""
Report routes — /api/report/*
Mirrors C# ReportController.
Generates and streams a PDF career report using ReportLab.
"""
from flask import Blueprint, Response
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..models.user import User
from ..models.recommendation import CareerRecommendation
from ..services.pdf_service import generate_career_report
from ..utils.auth import error

report_bp = Blueprint("report", __name__)


@report_bp.get("/download")
@jwt_required()
def download_report():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    recs = CareerRecommendation.query.filter_by(
        user_id=user_id, is_deleted=False
    ).order_by(CareerRecommendation.created_at.desc()).limit(5).all()

    try:
        pdf_bytes = generate_career_report(
            user.to_dict(),
            [r.to_dict() for r in recs],
        )
    except Exception as exc:
        return error(f"Failed to generate report: {exc}", 500)

    filename = f"talentforge_report_{user.full_name.replace(' ', '_')}.pdf"
    return Response(
        pdf_bytes,
        mimetype="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(pdf_bytes)),
        },
    )
