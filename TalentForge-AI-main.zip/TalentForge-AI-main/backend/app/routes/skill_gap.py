"""
Skill Gap routes — /api/skill-gap/*
Mirrors C# SkillGapController.
"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..models.user import User
from ..models.recommendation import CareerRecommendation
from ..services.ml_service import analyze_skill_gap, CAREER_SKILL_MAP
from ..utils.auth import success, error

skill_gap_bp = Blueprint("skill_gap", __name__)


@skill_gap_bp.get("/")
@jwt_required()
def get_skill_gap():
    """
    Auto-analyze gap vs user's first recommendation (or Data Scientist default).
    """
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    # Default target: first recommendation or Data Scientist
    first_rec = CareerRecommendation.query.filter_by(
        user_id=user_id, is_deleted=False
    ).order_by(CareerRecommendation.created_at.asc()).first()

    target = first_rec.career_title if first_rec else "Data Scientist"
    report = analyze_skill_gap(user.skills or [], target)

    return success({
        "report": report,
        "availableCareers": list(CAREER_SKILL_MAP.keys()),
    })


@skill_gap_bp.post("/analyze")
@jwt_required()
def analyze():
    """
    Body: { targetCareer }
    Returns skill gap report for the specified career.
    """
    data = request.get_json(silent=True) or {}
    target_career = (data.get("targetCareer") or "").strip()

    if not target_career:
        return error("targetCareer is required", 400)

    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    report = analyze_skill_gap(user.skills or [], target_career)
    return success({"report": report})


@skill_gap_bp.get("/careers")
def list_careers():
    """Return the list of supported career targets."""
    return success({"careers": list(CAREER_SKILL_MAP.keys())})
