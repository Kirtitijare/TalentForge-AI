"""
Profile routes — /api/profile/*
Mirrors C# ProfileController.
"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..extensions import db
from ..models.user import User
from ..utils.auth import success, error

profile_bp = Blueprint("profile", __name__)


@profile_bp.get("/")
@jwt_required()
def get_profile():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)
    return success(user.to_dict())


@profile_bp.put("/")
@jwt_required()
def update_profile():
    """
    Body: { bio, education, skills, interests, location, phoneNumber }
    """
    data = request.get_json(silent=True) or {}
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    if "bio" in data:
        user.bio = data["bio"]
    if "education" in data:
        user.education = data["education"]
    if "skills" in data:
        skills = data["skills"]
        if isinstance(skills, str):
            skills = [s.strip() for s in skills.split(",") if s.strip()]
        user.skills = skills
    if "interests" in data:
        interests = data["interests"]
        if isinstance(interests, str):
            interests = [i.strip() for i in interests.split(",") if i.strip()]
        user.interests = interests
    if "location" in data:
        user.location = data["location"]
    if "phoneNumber" in data:
        user.phone_number = data["phoneNumber"]
    if "fullName" in data and data["fullName"].strip():
        user.full_name = data["fullName"].strip()

    db.session.commit()
    return success(user.to_dict(), "Profile updated successfully")


@profile_bp.post("/skills/add")
@jwt_required()
def add_skills():
    """Body: { skills: [str] } — merge new skills into profile."""
    data = request.get_json(silent=True) or {}
    new_skills = data.get("skills", [])
    if isinstance(new_skills, str):
        new_skills = [s.strip() for s in new_skills.split(",") if s.strip()]

    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    existing = {s.lower() for s in (user.skills or [])}
    merged = list(user.skills or []) + [s for s in new_skills if s.lower() not in existing]
    user.skills = merged
    db.session.commit()

    return success({"skills": user.skills}, "Skills updated")
