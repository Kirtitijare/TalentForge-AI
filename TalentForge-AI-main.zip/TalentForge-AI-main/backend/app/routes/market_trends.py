"""
Market Trends routes — /api/market-trends/*
Mirrors C# MarketTrendsController + MarketTrendsApiController.
"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from ..services.market_trend_service import (
    get_all_trends,
    get_top_skills,
    get_trends_by_industry,
    get_skill_demand_scores,
)
from ..utils.auth import success, error

market_trends_bp = Blueprint("market_trends", __name__)


@market_trends_bp.get("/")
@jwt_required()
def list_trends():
    trends = get_all_trends()
    return success({"trends": trends, "count": len(trends)})


@market_trends_bp.get("/skills")
@jwt_required()
def top_skills():
    limit = request.args.get("limit", 12, type=int)
    skills = get_top_skills(limit)
    return success({"skills": skills})


@market_trends_bp.get("/skills/demand")
@jwt_required()
def skill_demand():
    scores = get_skill_demand_scores()
    return success({"skills": scores})



@market_trends_bp.get("/industry/<industry>")
@jwt_required()
def by_industry(industry: str):
    trends = get_trends_by_industry(industry)
    return success({"trends": trends, "industry": industry})


@market_trends_bp.get("/public")
def public_trends():
    """Public endpoint — no auth required (for landing page)."""
    trends = get_all_trends()
    # Return only non-sensitive fields
    public = [
        {
            "jobTitle": t["jobTitle"],
            "demandScore": t["demandScore"],
            "growthRate": t["growthRate"],
            "isTrending": t["isTrending"],
            "category": t["category"],
        }
        for t in trends
    ]
    return success({"trends": public, "count": len(public)})
