"""
Collaborative Filtering routes — /api/collaborative/*
Mirrors C# CollaborativeController.
"""
from flask import Blueprint
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..models.user import User
from ..models.recommendation import CareerRecommendation
from ..services.ml_service import find_similar_users
from ..utils.auth import success, error

collaborative_bp = Blueprint("collaborative", __name__)


@collaborative_bp.get("/")
@jwt_required()
def get_collaborative_recommendations():
    """
    Cosine-similarity collaborative filtering.
    Returns careers chosen by users with similar skill profiles.
    """
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    # Build peer data
    all_peers = User.query.filter(
        User.id != user.id,
        User.is_deleted == False,
    ).all()

    peer_data = []
    for peer in all_peers:
        if not peer.skills:
            continue
        peer_recs = CareerRecommendation.query.filter_by(
            user_id=peer.id, is_deleted=False
        ).all()
        peer_data.append({
            "id": str(peer.id),
            "skills": peer.skills or [],
            "recommendations": [r.career_title for r in peer_recs],
        })

    results = find_similar_users(user.skills or [], peer_data)

    return success({
        "recommendations": results,
        "userSkills": user.skills or [],
        "peerCount": len(peer_data),
    })
