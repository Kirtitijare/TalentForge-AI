"""
Chat routes — /api/chat/*
Mirrors C# ChatController.
Chat history stored in PostgreSQL chat_sessions (replaces server-side session).
"""
from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..extensions import db
from ..models.chat_session import ChatSession
from ..models.user import User
from ..services.ai_service import chat_with_mentor_rag
from ..services.rag_service import get_chat_context
from ..utils.auth import success, error

chat_bp = Blueprint("chat", __name__)


@chat_bp.get("/history")
@jwt_required()
def get_history():
    user_id = get_jwt_identity()
    session = ChatSession.query.filter_by(user_id=user_id).first()
    messages = session.messages if session else []
    return success({"messages": messages})


@chat_bp.post("/send")
@jwt_required()
def send_message():
    """
    Body: { message }
    Returns: { response, messages }
    """
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()

    if not message:
        return error("message is required", 400)

    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    # Load or create chat session
    session = ChatSession.query.filter_by(user_id=user_id).first()
    if not session:
        session = ChatSession(user_id=user_id, messages=[])
        db.session.add(session)

    history = list(session.messages or [])

    # Fetch RAG context and user profile
    skills = user.skills or []
    interests = user.interests or []
    education = user.education or ""
    
    rag_context = get_chat_context(
        message=message,
        user_skills=skills,
        user_interests=interests,
        user_education=education,
    )

    # Call Groq RAG-augmented mentor
    ai_response = chat_with_mentor_rag(
        message=message,
        history=history,
        rag_context=rag_context,
        user_skills=skills,
        user_interests=interests,
        user_education=education,
    )

    # Append both turns
    history.append({"role": "user", "content": message})
    history.append({"role": "assistant", "content": ai_response})

    # Keep last 40 messages (20 exchanges) to avoid unbounded growth
    session.messages = history[-40:]
    db.session.commit()

    return success({
        "response": ai_response,
        "messages": session.messages,
    })



@chat_bp.delete("/clear")
@jwt_required()
def clear_history():
    user_id = get_jwt_identity()
    session = ChatSession.query.filter_by(user_id=user_id).first()
    if session:
        session.messages = []
        db.session.commit()
    return success(message="Chat history cleared")
