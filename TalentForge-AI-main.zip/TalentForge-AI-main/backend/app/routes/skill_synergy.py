"""
Skill Synergy routes — /api/skill-synergy/*
Analyzes which skill combinations are most market-valuable.
"""
from flask import Blueprint
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..models.user import User
from ..services.skill_synergy_service import (
    analyze_skill_synergies,
    get_top_skill_combinations,
)
from ..utils.auth import success, error

skill_synergy_bp = Blueprint("skill_synergy", __name__)


@skill_synergy_bp.get("/")
@jwt_required()
def get_synergies():
    """
    Analyze skill synergies for the current user's skill set.
    Returns synergy scores, top pairs, and learning recommendations.
    """
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    skills = user.skills or []
    if len(skills) < 2:
        return error(
            "You need at least 2 skills on your profile for synergy analysis. "
            "Go to Profile page or upload your resume.",
            400,
        )

    result = analyze_skill_synergies(skills)
    return success(result, "Skill synergies analyzed")


@skill_synergy_bp.get("/top")
def get_top_combos():
    """
    Get the top skill combinations across all careers.
    No auth required — useful for landing page / general info.
    """
    combos = get_top_skill_combinations(top_n=15)
    return success({
        "combinations": combos,
        "totalCareersAnalyzed": 10,
    })
