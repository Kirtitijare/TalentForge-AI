"""
Learning Path routes — /api/learning-path/*
Mirrors C# LearningPathController.
Runs content-based rec + learning path + certifications + hybrid rec in parallel.
"""
from concurrent.futures import ThreadPoolExecutor
from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..models.user import User
from ..models.recommendation import CareerRecommendation
from ..services import ai_service
from ..services.ml_service import find_similar_users, CAREER_SKILL_MAP
from ..utils.auth import success, error

learning_path_bp = Blueprint("learning_path", __name__)

CAREER_LIST = list(CAREER_SKILL_MAP.keys())


@learning_path_bp.get("/careers")
def list_careers():
    return success({"careers": CAREER_LIST})


@learning_path_bp.post("/generate")
@jwt_required()
def generate():
    """
    Body: { targetCareer, durationMonths }
    Returns { contentBased, learningPath, certifications, hybridRec, userSkills }.
    """
    data = request.get_json(silent=True) or {}
    target_career = (data.get("targetCareer") or "").strip()
    duration_months = data.get("durationMonths")
    try:
        duration_months = int(duration_months) if duration_months else 6
    except (ValueError, TypeError):
        duration_months = 6

    if not target_career:
        return error("targetCareer is required", 400)

    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user or user.is_deleted:
        return error("User not found", 404)

    skills = user.skills or []

    # Build peer data for collaborative filtering
    from ..models.user import User as UserModel
    from ..models.recommendation import CareerRecommendation as RecModel
    all_users = UserModel.query.filter(
        UserModel.id != user.id,
        UserModel.is_deleted == False,
    ).all()

    peer_data = []
    for peer in all_users:
        if not peer.skills:
            continue
        peer_recs = RecModel.query.filter_by(user_id=peer.id, is_deleted=False).all()
        peer_data.append({
            "id": str(peer.id),
            "skills": peer.skills or [],
            "recommendations": [r.career_title for r in peer_recs],
        })

    cf_results = find_similar_users(skills, peer_data)
    cf_careers = [r["careerTitle"] for r in cf_results]

    user_input = f"Skills: {', '.join(skills)}, Target: {target_career}"

    # Run all 4 AI calls in parallel
    with ThreadPoolExecutor(max_workers=4) as executor:
        content_f = executor.submit(ai_service.get_content_based_recommendation, target_career, skills)
        path_f = executor.submit(ai_service.get_learning_path, target_career, skills, duration_months)
        cert_f = executor.submit(ai_service.get_recommended_certifications, target_career)
        hybrid_f = executor.submit(ai_service.get_hybrid_recommendation, user_input, cf_careers)

    return success({
        "targetCareer": target_career,
        "durationMonths": duration_months,
        "contentBased": content_f.result(),
        "learningPath": path_f.result(),
        "certifications": cert_f.result(),
        "hybridRec": hybrid_f.result(),
        "collaborativeResults": cf_results,
        "userSkills": skills,
    })

