import uuid
from datetime import datetime, timezone
from ..extensions import db
from sqlalchemy.dialects.postgresql import UUID, JSONB


class ChatSession(db.Model):
    __tablename__ = "chat_sessions"

    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey("users.id"), nullable=False, unique=True)
    # List of {"role": "user"|"assistant", "content": "..."}
    messages = db.Column(JSONB, default=list, server_default="[]")
    updated_at = db.Column(
        db.DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "userId": str(self.user_id),
            "messages": self.messages or [],
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self):
        return f"<ChatSession user={self.user_id}>"
