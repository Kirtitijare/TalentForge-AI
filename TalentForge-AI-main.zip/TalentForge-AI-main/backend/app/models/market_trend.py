import uuid
from ..extensions import db
from sqlalchemy.dialects.postgresql import UUID, ARRAY, TEXT


class MarketTrend(db.Model):
    __tablename__ = "market_trends"

    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_title = db.Column(db.String(255), nullable=False)
    slug = db.Column(db.String(255), unique=True, index=True, nullable=True)
    category = db.Column(db.String(100), nullable=True)
    demand_score = db.Column(db.Integer, default=0)       # 0-100
    average_salary_lpa = db.Column(db.Float, default=0.0) # Lakhs Per Annum
    growth_rate = db.Column(db.Float, default=0.0)        # % YoY
    top_skills_required = db.Column(ARRAY(TEXT), default=list, server_default="{}")
    required_skills = db.Column(ARRAY(TEXT), default=list, server_default="{}")
    industry = db.Column(db.String(100), nullable=True)
    is_trending = db.Column(db.Boolean, default=False)

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "jobTitle": self.job_title,
            "slug": self.slug,
            "category": self.category,
            "demandScore": self.demand_score,
            "averageSalaryLPA": self.average_salary_lpa,
            "growthRate": self.growth_rate,
            "topSkillsRequired": self.top_skills_required or [],
            "requiredSkills": self.required_skills or [],
            "industry": self.industry,
            "isTrending": self.is_trending,
        }

    def __repr__(self):
        return f"<MarketTrend {self.job_title}>"
