import uuid
from datetime import datetime, timezone
from ..extensions import db
from sqlalchemy.dialects.postgresql import UUID


class OTPVerification(db.Model):
    __tablename__ = "otp_verifications"

    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = db.Column(db.String(255), nullable=False, index=True)
    code = db.Column(db.String(6), nullable=False)
    expiry_time = db.Column(db.DateTime(timezone=True), nullable=False)
    is_used = db.Column(db.Boolean, default=False, nullable=False)
    # 'registration' | 'password_reset'
    type = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    def is_valid(self) -> bool:
        """Returns True if OTP is not used and not expired."""
        return not self.is_used and self.expiry_time > datetime.now(timezone.utc)

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "email": self.email,
            "isUsed": self.is_used,
            "expiryTime": self.expiry_time.isoformat(),
            "type": self.type,
        }

    def __repr__(self):
        return f"<OTP {self.email} [{self.type}]>"
