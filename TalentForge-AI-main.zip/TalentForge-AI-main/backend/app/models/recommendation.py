import uuid
from datetime import datetime, timezone
from ..extensions import db
from sqlalchemy.dialects.postgresql import UUID, ARRAY, TEXT


class CareerRecommendation(db.Model):
    __tablename__ = "career_recommendations"

    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey("users.id"), nullable=False, index=True)
    career_title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    match_percentage = db.Column(db.Float, default=0.0)
    recommended_skills = db.Column(ARRAY(TEXT), default=list, server_default="{}")
    potential_colleges = db.Column(ARRAY(TEXT), default=list, server_default="{}")
    roadmap_steps = db.Column(ARRAY(TEXT), default=list, server_default="{}")
    ai_model_used = db.Column(db.String(100), nullable=True)
    extra_data = db.Column(db.Text, nullable=True)

    # Hybrid recommendation scores
    content_score = db.Column(db.Float, nullable=True)  # TF-IDF engine score (0.0-1.0)
    cf_score = db.Column(db.Float, nullable=True)       # Collaborative filtering score (0.0-1.0)
    final_score = db.Column(db.Float, nullable=True)    # Blended final score (0.0-1.0)
    career_role_id = db.Column(db.String(100), nullable=True)  # Reference to market_trend.slug

    created_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    is_deleted = db.Column(db.Boolean, default=False, nullable=False)

    def to_dict(self) -> dict:
        import json
        extra = {}
        if self.extra_data:
            try:
                extra = json.loads(self.extra_data)
            except Exception:
                pass

        data = {
            "id": str(self.id),
            "userId": str(self.user_id),
            "careerTitle": self.career_title,
            "description": self.description,
            "matchPercentage": self.match_percentage,
            "recommendedSkills": self.recommended_skills or [],
            "potentialColleges": self.potential_colleges or [],
            "roadmapSteps": self.roadmap_steps or [],
            "aiModelUsed": self.ai_model_used,
            "contentScore": self.content_score,
            "cfScore": self.cf_score,
            "finalScore": self.final_score,
            "careerRoleId": self.career_role_id,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
        }
        data.update(extra)
        return data

    def __repr__(self):
        return f"<CareerRecommendation {self.career_title} for user {self.user_id}>"
