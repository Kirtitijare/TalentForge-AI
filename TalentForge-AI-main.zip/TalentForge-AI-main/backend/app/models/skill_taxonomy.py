from datetime import datetime, timezone
from ..extensions import db
from sqlalchemy.dialects.postgresql import ARRAY, TEXT

class SkillTaxonomy(db.Model):
    __tablename__ = "skill_taxonomy"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    skill_name = db.Column(db.String(255), unique=True, nullable=False, index=True)
    category = db.Column(db.String(100), nullable=True)
    aliases = db.Column(ARRAY(TEXT), default=list, server_default="{}")
    learning_url = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "skillName": self.skill_name,
            "category": self.category,
            "aliases": self.aliases or [],
            "learningUrl": self.learning_url,
            "createdAt": self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f"<SkillTaxonomy {self.skill_name}>"
