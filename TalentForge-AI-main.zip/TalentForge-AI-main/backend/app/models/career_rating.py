from datetime import datetime, timezone
from ..extensions import db

class CareerRating(db.Model):
    __tablename__ = "career_ratings"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.String(255), nullable=False, index=True)
    career_slug = db.Column(db.String(255), nullable=False, index=True)
    rating = db.Column(db.Float, nullable=False)
    source = db.Column(db.String(50), default="user", nullable=False) # 'user' or 'synthetic'
    created_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "userId": self.user_id,
            "careerSlug": self.career_slug,
            "rating": self.rating,
            "source": self.source,
            "createdAt": self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f"<CareerRating User {self.user_id} -> {self.career_slug}: {self.rating}>"
