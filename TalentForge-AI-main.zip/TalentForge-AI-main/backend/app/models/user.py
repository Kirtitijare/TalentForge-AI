import uuid
from datetime import datetime, timezone
from ..extensions import db
from sqlalchemy.dialects.postgresql import UUID, ARRAY, TEXT


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    full_name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    phone_number = db.Column(db.String(20), nullable=True)
    is_email_verified = db.Column(db.Boolean, default=False, nullable=False)
    role = db.Column(db.String(20), default="user", nullable=False)  # 'user' | 'admin'

    # Profile (flattened from C# embedded UserProfile)
    bio = db.Column(db.Text, nullable=True)
    education = db.Column(db.Text, nullable=True)
    skills = db.Column(ARRAY(TEXT), default=list, nullable=False, server_default="{}")
    interests = db.Column(ARRAY(TEXT), default=list, nullable=False, server_default="{}")
    location = db.Column(db.String(255), nullable=True)
    profile_picture_url = db.Column(db.Text, nullable=True)
    resume_data = db.Column(db.Text, nullable=True)

    # pgvector skill embedding — populated by ml_service when skills are updated
    # Stored as text here; actual vector type applied via migration
    skill_embedding = db.Column(db.Text, nullable=True)

    # Hybrid recommendation system fields
    experience_years = db.Column(db.Integer, default=0, nullable=False)
    goals = db.Column(db.Text, nullable=True)
    parsed_resume_json = db.Column(db.JSON, nullable=True)
      # Stores: {skills, experience_years, education, goals, inferred_interests}

    created_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(
        db.DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
    is_deleted = db.Column(db.Boolean, default=False, nullable=False)

    # Relationships
    recommendations = db.relationship(
        "CareerRecommendation", backref="user", lazy="dynamic",
        primaryjoin="and_(User.id==CareerRecommendation.user_id, CareerRecommendation.is_deleted==False)"
    )
    chat_session = db.relationship("ChatSession", backref="user", uselist=False)

    def to_dict(self, include_private: bool = False) -> dict:
        import json
        try:
            resume_parsed = json.loads(self.resume_data) if self.resume_data else None
        except Exception:
            resume_parsed = None

        data = {
            "id": str(self.id),
            "fullName": self.full_name,
            "email": self.email,
            "phoneNumber": self.phone_number,
            "isEmailVerified": self.is_email_verified,
            "role": self.role,
            "experienceYears": self.experience_years,
            "goals": self.goals,
            "profile": {
                "bio": self.bio,
                "education": self.education,
                "skills": self.skills or [],
                "interests": self.interests or [],
                "location": self.location,
                "profilePictureUrl": self.profile_picture_url,
            },
            "resumeData": resume_parsed,
            "createdAt": self.created_at.isoformat() if self.created_at else None,
            "updatedAt": self.updated_at.isoformat() if self.updated_at else None,
        }
        return data

    def __repr__(self):
        return f"<User {self.email}>"
