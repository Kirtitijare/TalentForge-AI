"""
AI Service — calls Groq REST API directly via httpx (no SDK dependency).
Enhanced with:
  - Retry logic with exponential backoff
  - RAG-augmented chat (career knowledge base retrieval)
  - Structured JSON output enforcement
  - Better prompt engineering for actionable outputs
"""
import os
import re
import json
import time
import logging
import httpx

logger = logging.getLogger(__name__)

GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL   = "llama-3.1-8b-instant"

# Career → required skills corpus (same as C# TF-IDF corpus)
CAREER_CORPUS: dict[str, list[str]] = {
    "Data Scientist": ["python", "machine learning", "sql", "statistics", "tensorflow",
                       "pandas", "numpy", "data visualization", "deep learning", "scikit-learn",
                       "r", "jupyter", "matplotlib", "seaborn", "feature engineering"],
    "ML Engineer": ["python", "tensorflow", "pytorch", "docker", "kubernetes", "mlops",
                    "rest api", "git", "linux", "cloud", "model deployment", "ci/cd",
                    "fastapi", "airflow", "spark"],
    "Full Stack Developer": ["javascript", "react", "node.js", "html", "css", "sql",
                             "rest api", "git", "docker", "typescript", "mongodb",
                             "express", "next.js", "graphql", "testing"],
    "Cloud Engineer": ["aws", "azure", "gcp", "docker", "kubernetes", "terraform",
                       "linux", "networking", "ci/cd", "python", "iam", "s3",
                       "ec2", "lambda", "cloudformation"],
    "DevOps Engineer": ["docker", "kubernetes", "ci/cd", "jenkins", "git", "linux",
                        "aws", "terraform", "ansible", "python", "monitoring",
                        "prometheus", "grafana", "helm", "bash"],
    "Cybersecurity Analyst": ["networking", "linux", "python", "ethical hacking", "siem",
                               "firewalls", "cryptography", "incident response", "compliance",
                               "risk assessment", "penetration testing", "wireshark",
                               "nmap", "splunk", "iso 27001"],
    "Backend Developer": ["python", "flask", "sql", "rest api", "docker", "git",
                          "postgresql", "redis", "microservices", "aws",
                          "sqlalchemy", "rabbitmq", "grpc", "swagger", "unit testing"],
    "Frontend Developer": ["javascript", "react", "html", "css", "typescript", "figma",
                           "bootstrap", "tailwind", "git", "accessibility",
                           "webpack", "jest", "storybook", "responsive design", "ux"],
    "Data Analyst": ["sql", "excel", "python", "tableau", "power bi", "statistics",
                     "data cleaning", "pandas", "communication", "storytelling",
                     "looker", "google analytics", "a/b testing", "pivot tables", "vlookup"],
    "AI Engineer": ["python", "deep learning", "llms", "tensorflow", "pytorch", "mlops",
                    "rest api", "docker", "cloud", "prompt engineering", "langchain",
                    "openai", "huggingface", "rag", "vector databases"],
}

_TOTAL_DOCS = len(CAREER_CORPUS)

# ── Retry Configuration ──────────────────────────────────────────────────────

MAX_RETRIES = 3
RETRY_BASE_DELAY = 1.0  # seconds
RETRY_BACKOFF_FACTOR = 2.0


def _call_groq(
    prompt: str,
    max_tokens: int = 2048,
    temperature: float = 0.7,
    messages: list[dict] | None = None,
) -> str:
    """
    Direct httpx call to Groq REST API with retry logic.
    Retries on transient errors (429, 500, 502, 503, 504) with exponential backoff.
    """
    api_key = os.getenv("GROQ_API_KEY", "")
    if not api_key:
        logger.error("GROQ_API_KEY is not set")
        return "AI configuration error: GROQ_API_KEY is missing."

    payload = {
        "model": GROQ_MODEL,
        "messages": messages if messages else [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    last_error = None
    for attempt in range(MAX_RETRIES):
        try:
            with httpx.Client(timeout=60.0) as client:
                response = client.post(
                    GROQ_API_URL,
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                )

            # Check for rate limiting or server errors (retryable)
            if response.status_code in (429, 500, 502, 503, 504):
                delay = RETRY_BASE_DELAY * (RETRY_BACKOFF_FACTOR ** attempt)
                logger.warning(
                    f"Groq API returned {response.status_code}, "
                    f"retrying in {delay:.1f}s (attempt {attempt + 1}/{MAX_RETRIES})"
                )
                time.sleep(delay)
                last_error = f"HTTP {response.status_code}"
                continue

            response.raise_for_status()
            data = response.json()
            return data["choices"][0]["message"]["content"] or ""

        except httpx.HTTPStatusError as exc:
            last_error = f"HTTP {exc.response.status_code}: {exc.response.text[:200]}"
            logger.error("Groq API HTTP error: %s", last_error)
            if exc.response.status_code < 500 and exc.response.status_code != 429:
                return f"AI service error ({exc.response.status_code}). Check your API key and quota."
        except httpx.TimeoutException:
            delay = RETRY_BASE_DELAY * (RETRY_BACKOFF_FACTOR ** attempt)
            logger.warning(f"Groq API timeout, retrying in {delay:.1f}s")
            time.sleep(delay)
            last_error = "Request timeout"
        except Exception as exc:
            last_error = str(exc)
            logger.error("Groq API error: %s", exc)
            break

    return f"AI service temporarily unavailable after {MAX_RETRIES} attempts. Last error: {last_error}"


# ── Public API ────────────────────────────────────────────────────────────────

def get_career_recommendation(user_input: str) -> str:
    prompt = f"""You are a Senior Career Counselor with expertise in technology careers. 
Based on the following profile, provide a detailed career analysis.

User Profile: {user_input}

Respond with the following sections (use these exact headers):

CAREER_TITLE: [Most suitable career title]

WHY_THIS_PATH:
[2-3 sentences explaining why this career path aligns with the user's profile]

MARKET_REALITY:
[Current demand, salary range, and growth projections for this career in 2026]

SKILL_GAP:
[Specific skills the user should develop, categorized as "Have" and "Need to Learn"]

6_MONTH_ROADMAP:
[Month-by-month plan with specific courses, projects, and milestones]

TOP_RESOURCES:
[5 specific resources with links/platform names — mix of free and paid]

Be specific, actionable, and realistic. Avoid generic advice."""
    return _call_groq(prompt, max_tokens=2500)


def get_career_recommendation_structured(user_input: str) -> dict:
    """
    Get career recommendation as structured JSON.
    Used by the hybrid scoring system.
    """
    prompt = f"""You are a career recommendation AI. Analyze this profile and respond ONLY with valid JSON.

User Profile: {user_input}

Respond with this exact JSON format:
{{
    "careerTitle": "most suitable career",
    "confidence": 0.85,
    "reasoning": "2-3 sentence explanation",
    "topAlternatives": ["career2", "career3"],
    "immediateActions": ["action1", "action2", "action3"],
    "timelineMonths": 6,
    "salaryRangeINR": {{"min": 800000, "max": 2500000}}
}}"""
    raw = _call_groq(prompt, max_tokens=1024, temperature=0.3)
    try:
        match = re.search(r"\{[\s\S]*\}", raw)
        return json.loads(match.group(0)) if match else {"careerTitle": "Custom Path", "reasoning": raw}
    except Exception:
        return {"careerTitle": "Custom Path", "reasoning": raw}


def analyze_resume(resume_text: str) -> str:
    prompt = f"""You are an expert resume reviewer and career advisor.
Analyze this resume thoroughly and provide:

1. **OVERALL ASSESSMENT** (2-3 sentences on resume strength)
2. **KEY STRENGTHS** (3-5 bullet points)
3. **AREAS FOR IMPROVEMENT** (3-5 specific, actionable suggestions)
4. **ATS OPTIMIZATION** (keywords and formatting tips for Applicant Tracking Systems)
5. **CAREER FIT ANALYSIS** (which roles this resume is best suited for)
6. **ACTION ITEMS** (top 3 things to fix immediately)

Resume text:
{resume_text[:3000]}"""
    return _call_groq(prompt, max_tokens=2048)


def chat_with_mentor(message: str, history: list[dict]) -> str:
    """
    Basic chat without RAG. Kept for backward compatibility.
    Use chat_with_mentor_rag() for enhanced responses.
    """
    messages = [
        {
            "role": "system",
            "content": (
                "You are an expert career mentor helping students and professionals "
                "navigate their career paths. Be encouraging, specific, and practical."
            ),
        }
    ]
    messages.extend(history[-20:])
    messages.append({"role": "user", "content": message})
    return _call_groq("", max_tokens=1024, temperature=0.7, messages=messages)


def chat_with_mentor_rag(
    message: str,
    history: list[dict],
    rag_context: str = "",
    user_skills: list[str] = None,
    user_interests: list[str] = None,
    user_education: str = None,
) -> str:
    """
    RAG-augmented career mentor chat.
    Uses retrieved career knowledge to ground responses in specific data.
    """
    # Build rich system prompt with RAG context
    system_parts = [
        "You are an expert AI career mentor on the TalentForge platform. "
        "You help students and professionals navigate their career paths with specific, "
        "actionable, data-driven advice.",
        "",
        "IMPORTANT RULES:",
        "- Base your answers on the CAREER KNOWLEDGE provided below when relevant",
        "- Include specific salary figures, certifications, and timelines when available",
        "- Be encouraging but realistic — don't overpromise",
        "- If the user asks about something not in the knowledge base, use your general knowledge",
        "- Reference the user's skills and interests when giving advice",
        "- Keep responses focused and well-structured (use bullet points, headers)",
    ]

    if rag_context:
        system_parts.append("")
        system_parts.append(rag_context)

    # Add user profile to system prompt
    if user_skills or user_interests or user_education:
        profile_parts = ["\n--- USER PROFILE ---"]
        if user_skills:
            profile_parts.append(f"Skills: {', '.join(user_skills[:15])}")
        if user_interests:
            profile_parts.append(f"Interests: {', '.join(user_interests[:5])}")
        if user_education:
            profile_parts.append(f"Education: {user_education}")
        profile_parts.append("--- END PROFILE ---")
        system_parts.extend(profile_parts)

    messages = [{"role": "system", "content": "\n".join(system_parts)}]
    messages.extend(history[-20:])
    messages.append({"role": "user", "content": message})

    return _call_groq("", max_tokens=1500, temperature=0.7, messages=messages)


def parse_resume_structured(resume_text: str) -> dict:
    """
    Returns a dict matching ParsedResumeDto:
    { skills, certifications, projects, experience, education, summary, rawText }
    """
    prompt = f"""You are an expert resume parser. Extract structured information from this resume text and respond ONLY with valid JSON in this exact format:
{{
  "skills": ["skill1", "skill2"],
  "certifications": ["cert1", "cert2"],
  "projects": ["project1", "project2"],
  "experience": [{{"company": "", "role": "", "duration": "", "description": ""}}],
  "education": [{{"institution": "", "degree": "", "year": "", "score": ""}}],
  "summary": "brief professional summary"
}}

Resume text:
{resume_text[:3000]}"""

    raw = _call_groq(prompt, max_tokens=2048, temperature=0.3)

    try:
        match = re.search(r"\{[\s\S]*\}", raw)
        json_str = match.group(0) if match else raw
        parsed = json.loads(json_str)
        return {
            "skills": parsed.get("skills", []),
            "certifications": parsed.get("certifications", []),
            "projects": parsed.get("projects", []),
            "experience": parsed.get("experience", []),
            "education": parsed.get("education", []),
            "summary": parsed.get("summary", ""),
            "rawText": resume_text,
        }
    except Exception as exc:
        logger.error("Failed to parse structured resume JSON: %s", exc)
        return {
            "skills": [], "certifications": [], "projects": [],
            "experience": [], "education": [],
            "summary": raw, "rawText": resume_text,
        }


def get_content_based_recommendation(career_title: str, user_skills: list[str]) -> str:
    """TF-IDF content-based recommendation — no API call."""
    user_set = {s.strip().lower() for s in user_skills}
    scores = []

    for career, required_skills in CAREER_CORPUS.items():
        matched = [s for s in required_skills if s in user_set]
        missing = [s for s in required_skills if s not in user_set]
        score = _compute_tfidf_score(user_skills, required_skills)
        scores.append((career, score, matched, missing))

    ranked = sorted(scores, key=lambda x: x[1], reverse=True)[:5]

    lines = ["## Content-Based Career Recommendations (TF-IDF)\n"]
    for career, score, matched, missing in ranked:
        pct = int(score * 100)
        lines.append(f"### {career} — {pct}% Match")
        lines.append(f"**Matched Skills:** {', '.join(matched[:5]) or 'None yet'}")
        lines.append(f"**Skills to Learn:** {', '.join(missing[:5]) or 'You have them all'}")
        lines.append("")

    return "\n".join(lines)


def get_hybrid_recommendation(user_input: str, collaborative_careers: list[str]) -> str:
    collab_ctx = (
        f"Peers with similar skills chose: {', '.join(collaborative_careers)}."
        if collaborative_careers else ""
    )
    prompt = f"""You are a hybrid career recommendation engine combining content-based and collaborative filtering.
{collab_ctx}
User profile: {user_input}

Provide a HYBRID RECOMMENDATION that weighs both the user's skills (content-based) and peer choices (collaborative).
Format: CAREER_TITLE, HYBRID_SCORE (0-100), REASONING (2 sentences), KEY_SKILLS_NEEDED.
Give top 3 careers."""
    return _call_groq(prompt)


def get_recommended_certifications(career_title: str) -> str:
    prompt = f"""List the top 5 most valuable certifications for a {career_title} in 2026.
For each certification provide:
- CERT_NAME
- PROVIDER (AWS/Google/Microsoft/Coursera etc.)
- DIFFICULTY (Beginner/Intermediate/Advanced)
- ESTIMATED_COST
- WHY_VALUABLE (1 sentence)
Format as a structured list."""
    return _call_groq(prompt)


def get_learning_path(career_title: str, current_skills: list[str], duration_months: int = 6) -> str:
    skills_str = ", ".join(current_skills) if current_skills else "no specific skills yet"
    prompt = f"""Create a highly actionable, structured {duration_months}-month study learning path for a student wanting to transition into a {career_title}.
Current skills of the student: {skills_str}

You MUST structure the response EXACTLY like this (do not miss any month):
MONTH_1: [Core topics, subtopics, and resources]
MONTH_2: [Core topics, subtopics, and resources]
...
MONTH_{duration_months}: [Core topics, subtopics, final projects ideas, and resources]

Provide specific course names from high-quality platforms (Coursera, Udemy, YouTube, edX, MIT OpenCourseWare) and include ACTUAL clickable markdown links. 
Create highly realistic search-based URLs so the student can click and start studying immediately, for example:
- Coursera Search: `[Andrew Ng Machine Learning on Coursera](https://www.coursera.org/search?query=machine+learning+andrew+ng)`
- Udemy Search: `[Python Bootcamps on Udemy](https://www.udemy.com/courses/search/?q=python+bootcamp)`
- YouTube Tutorials: `[Fast.ai Deep Learning Playlist](https://www.youtube.com/results?search_query=fast+ai+deep+learning)`
- edX/Generic: `[CS50 Introduction to Computer Science](https://www.edx.org/search?q=cs50)`

Each month's text should have:
1. "Key Topics to Master": bullet list of sub-concepts.
2. "Recommended Study Resources": bullet list of recommended course names with the corresponding clickable markdown URLs.
3. "Hands-on Milestone Project": a brief project idea to build that month.

Ensure all markdown links are correctly formatted and completely clickable!"""
    return _call_groq(prompt, max_tokens=3000)



# ── TF-IDF helper ─────────────────────────────────────────────────────────────

def _compute_tfidf_score(user_skills: list[str], career_skills: list[str]) -> float:
    import math
    user_set = {s.strip().lower() for s in user_skills}
    score = 0.0

    for skill in career_skills:
        skill_lower = skill.lower()
        if skill_lower not in user_set:
            continue
        tf = 1.0 / len(career_skills)
        docs_with_skill = sum(
            1 for skills in CAREER_CORPUS.values()
            if any(s.lower() == skill_lower for s in skills)
        )
        idf = math.log(_TOTAL_DOCS / (1 + docs_with_skill))
        score += tf * idf

    return min(1.0, max(0.0, score + 0.3))
