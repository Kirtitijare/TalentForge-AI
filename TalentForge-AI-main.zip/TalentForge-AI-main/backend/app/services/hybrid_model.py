"""
Hybrid Recommendation Engine — Custom Neural Collaborative Filtering (NCF)
Built from scratch with NumPy. No PyTorch/TensorFlow dependency.

Architecture:
  User skills → skill_embedding (48→32) → |
                                           |→ concat → Dense(64→32) → Dense(32→16) → Dense(16→1) → sigmoid → score
  Career skills → career_embedding (48→32) → |

Training: Mini-batch gradient descent on user-career interaction matrix.
Hybrid: final_score = w1*content + w2*ncf + w3*market_demand
"""
import logging
import numpy as np
from typing import Optional

logger = logging.getLogger(__name__)

# Import from ml_service to avoid duplication
from .ml_service import (
    SKILL_VOCABULARY,
    CAREER_CORPUS,
    CAREER_SKILL_MAP,
    build_skill_vector,
    compute_tfidf_career_matches,
)


# ── Neural Collaborative Filtering Model ─────────────────────────────────────

class NCFModel:
    """
    2-tower neural collaborative filtering model.
    User tower: skill vector → dense embedding
    Career tower: skill requirements → dense embedding
    Prediction: MLP(concat(user_emb, career_emb)) → affinity score
    """

    def __init__(self, input_dim: int = None, embed_dim: int = 32, seed: int = 42):
        self.input_dim = input_dim or len(SKILL_VOCABULARY)
        self.embed_dim = embed_dim
        self.rng = np.random.RandomState(seed)
        self._init_weights()
        self.trained = False

    def _init_weights(self):
        """Xavier/He initialization for all weight matrices."""
        d = self.input_dim
        e = self.embed_dim

        # User embedding: input_dim → embed_dim
        self.W_user = self.rng.randn(d, e) * np.sqrt(2.0 / d)
        self.b_user = np.zeros(e)

        # Career embedding: input_dim → embed_dim
        self.W_career = self.rng.randn(d, e) * np.sqrt(2.0 / d)
        self.b_career = np.zeros(e)

        # MLP layers: concat(user_emb, career_emb) → prediction
        # Layer 1: 2*embed_dim → 32
        h1 = 2 * e
        h2 = 32
        self.W1 = self.rng.randn(h1, h2) * np.sqrt(2.0 / h1)
        self.b1 = np.zeros(h2)

        # Layer 2: 32 → 16
        h3 = 16
        self.W2 = self.rng.randn(h2, h3) * np.sqrt(2.0 / h2)
        self.b2 = np.zeros(h3)

        # Output: 16 → 1
        self.W_out = self.rng.randn(h3, 1) * np.sqrt(2.0 / h3)
        self.b_out = np.zeros(1)

    @staticmethod
    def _relu(x):
        return np.maximum(0, x)

    @staticmethod
    def _relu_grad(x):
        return (x > 0).astype(float)

    @staticmethod
    def _sigmoid(x):
        x = np.clip(x, -500, 500)
        return 1.0 / (1.0 + np.exp(-x))

    def forward(self, user_vec: np.ndarray, career_vec: np.ndarray) -> tuple:
        """
        Forward pass. Returns (prediction, cache) where cache stores
        intermediate values for backpropagation.
        """
        # User embedding
        z_user = user_vec @ self.W_user + self.b_user
        a_user = self._relu(z_user)

        # Career embedding
        z_career = career_vec @ self.W_career + self.b_career
        a_career = self._relu(z_career)

        # Concatenate
        concat = np.concatenate([a_user, a_career], axis=-1)

        # MLP Layer 1
        z1 = concat @ self.W1 + self.b1
        a1 = self._relu(z1)

        # MLP Layer 2
        z2 = a1 @ self.W2 + self.b2
        a2 = self._relu(z2)

        # Output
        z_out = a2 @ self.W_out + self.b_out
        pred = self._sigmoid(z_out)

        cache = {
            "user_vec": user_vec, "career_vec": career_vec,
            "z_user": z_user, "a_user": a_user,
            "z_career": z_career, "a_career": a_career,
            "concat": concat,
            "z1": z1, "a1": a1,
            "z2": z2, "a2": a2,
            "z_out": z_out, "pred": pred,
        }
        return pred.flatten(), cache

    def backward(self, cache: dict, y_true: float, lr: float = 0.01):
        """
        Backpropagation with gradient descent update.
        Binary cross-entropy loss gradient.
        """
        pred = cache["pred"].flatten()
        y = np.atleast_1d(y_true)

        # dL/d(z_out) for BCE: pred - y
        d_out = (pred - y).reshape(1, 1)

        # Output layer gradients
        dW_out = cache["a2"].reshape(-1, 1) @ d_out.reshape(1, -1)
        db_out = d_out.flatten()
        d_a2 = (d_out @ self.W_out.T).flatten()

        # Layer 2
        d_z2 = d_a2 * self._relu_grad(cache["z2"].flatten())
        d_z2 = d_z2.reshape(1, -1)
        dW2 = cache["a1"].reshape(-1, 1) @ d_z2
        db2 = d_z2.flatten()
        d_a1 = (d_z2 @ self.W2.T).flatten()

        # Layer 1
        d_z1 = d_a1 * self._relu_grad(cache["z1"].flatten())
        d_z1 = d_z1.reshape(1, -1)
        dW1 = cache["concat"].reshape(-1, 1) @ d_z1
        db1 = d_z1.flatten()
        d_concat = (d_z1 @ self.W1.T).flatten()

        # Split gradients back to user and career embeddings
        d_a_user = d_concat[:self.embed_dim]
        d_a_career = d_concat[self.embed_dim:]

        # User embedding gradients
        d_z_user = d_a_user * self._relu_grad(cache["z_user"].flatten())
        d_z_user = d_z_user.reshape(1, -1)
        dW_user = cache["user_vec"].reshape(-1, 1) @ d_z_user
        db_user = d_z_user.flatten()

        # Career embedding gradients
        d_z_career = d_a_career * self._relu_grad(cache["z_career"].flatten())
        d_z_career = d_z_career.reshape(1, -1)
        dW_career = cache["career_vec"].reshape(-1, 1) @ d_z_career
        db_career = d_z_career.flatten()

        # Gradient descent update
        self.W_user -= lr * dW_user
        self.b_user -= lr * db_user
        self.W_career -= lr * dW_career
        self.b_career -= lr * db_career
        self.W1 -= lr * dW1
        self.b1 -= lr * db1
        self.W2 -= lr * dW2
        self.b2 -= lr * db2
        self.W_out -= lr * dW_out
        self.b_out -= lr * db_out

    def predict(self, user_skills: list[str], career_name: str) -> float:
        """Predict affinity score (0-1) for a user-career pair."""
        user_vec = build_skill_vector(user_skills).reshape(1, -1)
        career_skills = CAREER_CORPUS.get(career_name, CAREER_SKILL_MAP.get(career_name, []))
        career_vec = build_skill_vector(career_skills).reshape(1, -1)
        score, _ = self.forward(user_vec, career_vec)
        return float(score[0])

    def predict_all_careers(self, user_skills: list[str]) -> list[dict]:
        """Predict affinity for all known careers, sorted by score."""
        user_vec = build_skill_vector(user_skills).reshape(1, -1)
        results = []

        for career_name in CAREER_CORPUS:
            career_skills = CAREER_CORPUS[career_name]
            career_vec = build_skill_vector(career_skills).reshape(1, -1)
            score, _ = self.forward(user_vec, career_vec)
            results.append({
                "career": career_name,
                "ncfScore": round(float(score[0]), 4),
            })

        return sorted(results, key=lambda x: x["ncfScore"], reverse=True)


# ── Training ─────────────────────────────────────────────────────────────────

def train_ncf_model(
    model: NCFModel,
    interaction_data: list[dict],
    epochs: int = 100,
    lr: float = 0.005,
) -> dict:
    """
    Train the NCF model on user-career interaction data.

    interaction_data: list of {"user_skills": [...], "career": "...", "label": 0 or 1}
      - label=1 means user was recommended/chose this career
      - label=0 means negative sample (not recommended)

    Returns training stats.
    """
    if not interaction_data:
        logger.warning("No interaction data for NCF training, using synthetic data")
        interaction_data = _generate_synthetic_training_data()

    losses = []
    for epoch in range(epochs):
        epoch_loss = 0.0
        np.random.shuffle(interaction_data)

        for sample in interaction_data:
            user_vec = build_skill_vector(sample["user_skills"]).reshape(1, -1)
            career_skills = CAREER_CORPUS.get(
                sample["career"],
                CAREER_SKILL_MAP.get(sample["career"], [])
            )
            career_vec = build_skill_vector(career_skills).reshape(1, -1)

            pred, cache = model.forward(user_vec, career_vec)
            y = sample["label"]

            # BCE loss
            eps = 1e-7
            p = np.clip(pred[0], eps, 1 - eps)
            loss = -(y * np.log(p) + (1 - y) * np.log(1 - p))
            epoch_loss += loss

            model.backward(cache, y, lr=lr)

        avg_loss = epoch_loss / len(interaction_data)
        losses.append(avg_loss)

        if epoch % 20 == 0:
            logger.info(f"NCF Training epoch {epoch}/{epochs}, loss: {avg_loss:.4f}")

    model.trained = True
    return {
        "epochs": epochs,
        "final_loss": float(losses[-1]),
        "samples": len(interaction_data),
    }


def _generate_synthetic_training_data() -> list[dict]:
    """
    Generate realistic synthetic training data based on skill-career alignment.
    This creates positive samples (skills match career) and negative samples.
    """
    data = []

    # Define user skill profiles (synthetic users with realistic skill sets)
    user_profiles = [
        {"skills": ["python", "machine learning", "sql", "pandas", "numpy", "statistics"], "target": "Data Scientist"},
        {"skills": ["python", "tensorflow", "pytorch", "docker", "kubernetes", "linux"], "target": "ML Engineer"},
        {"skills": ["javascript", "react", "node.js", "html", "css", "sql", "git"], "target": "Full Stack Developer"},
        {"skills": ["aws", "docker", "kubernetes", "terraform", "linux", "python"], "target": "Cloud Engineer"},
        {"skills": ["docker", "kubernetes", "ci/cd", "jenkins", "git", "linux", "aws"], "target": "DevOps Engineer"},
        {"skills": ["networking", "linux", "python", "cybersecurity", "firewalls"], "target": "Cybersecurity Analyst"},
        {"skills": ["python", "flask", "sql", "rest api", "docker", "postgresql"], "target": "Backend Developer"},
        {"skills": ["javascript", "react", "html", "css", "typescript", "figma"], "target": "Frontend Developer"},
        {"skills": ["sql", "excel", "python", "tableau", "power bi", "statistics"], "target": "Data Analyst"},
        {"skills": ["python", "deep learning", "tensorflow", "pytorch", "docker"], "target": "AI Engineer"},
        # Additional profiles with mixed skills
        {"skills": ["python", "java", "sql", "git", "agile", "communication"], "target": "Backend Developer"},
        {"skills": ["react", "typescript", "node.js", "mongodb", "graphql", "docker"], "target": "Full Stack Developer"},
        {"skills": ["python", "scikit-learn", "pandas", "data analysis", "matplotlib"], "target": "Data Scientist"},
        {"skills": ["aws", "azure", "gcp", "networking", "ci/cd", "docker"], "target": "Cloud Engineer"},
        {"skills": ["python", "deep learning", "llms", "langchain", "rest api"], "target": "AI Engineer"},
        {"skills": ["linux", "networking", "python", "cybersecurity", "siem"], "target": "Cybersecurity Analyst"},
        {"skills": ["kubernetes", "docker", "terraform", "ansible", "prometheus"], "target": "DevOps Engineer"},
        {"skills": ["sql", "python", "tableau", "excel", "communication", "pandas"], "target": "Data Analyst"},
        {"skills": ["javascript", "react", "css", "html", "bootstrap", "git"], "target": "Frontend Developer"},
        {"skills": ["python", "tensorflow", "docker", "mlops", "kubernetes", "fastapi"], "target": "ML Engineer"},
    ]

    all_careers = list(CAREER_CORPUS.keys())

    for profile in user_profiles:
        # Positive sample: user's target career
        data.append({
            "user_skills": profile["skills"],
            "career": profile["target"],
            "label": 1.0,
        })

        # Semi-positive: related careers (partial skill match gives 0.6-0.8 label)
        user_set = set(s.lower() for s in profile["skills"])
        for career in all_careers:
            if career == profile["target"]:
                continue
            career_skills = set(s.lower() for s in CAREER_CORPUS[career])
            overlap = len(user_set & career_skills)
            if overlap >= 3:
                data.append({
                    "user_skills": profile["skills"],
                    "career": career,
                    "label": min(0.8, overlap * 0.15),
                })
            else:
                # Negative sample
                data.append({
                    "user_skills": profile["skills"],
                    "career": career,
                    "label": max(0.0, overlap * 0.05),
                })

    logger.info(f"Generated {len(data)} synthetic training samples for NCF")
    return data


# ── Hybrid Recommender ───────────────────────────────────────────────────────

class HybridRecommender:
    """
    Combines three signals:
    1. Content-based (TF-IDF cosine similarity)
    2. Collaborative (NCF model prediction)
    3. Market demand (from market_trend_service)

    Weights are configurable and can be tuned.
    """

    # Default weights
    CONTENT_WEIGHT = 0.40
    COLLABORATIVE_WEIGHT = 0.35
    MARKET_WEIGHT = 0.25

    def __init__(self):
        self.ncf_model = NCFModel()
        self._trained = False

    def ensure_trained(self, interaction_data: list[dict] | None = None):
        """Train the NCF model if not already trained."""
        if not self._trained:
            stats = train_ncf_model(self.ncf_model, interaction_data or [])
            self._trained = True
            logger.info(f"NCF model trained: {stats}")
            return stats
        return None

    def recommend(
        self,
        user_skills: list[str],
        market_scores: dict[str, float] | None = None,
        top_n: int = 5,
    ) -> list[dict]:
        """
        Generate hybrid recommendations.

        Returns list of:
        {
            career, hybridScore, contentScore, collaborativeScore,
            marketScore, confidence, matchedSkills, missingSkills,
            scoreBreakdown
        }
        """
        if not self._trained:
            self.ensure_trained()

        # 1. Content-based scores
        content_results = compute_tfidf_career_matches(user_skills)
        content_map = {r["career"]: r for r in content_results}

        # 2. NCF scores
        ncf_results = self.ncf_model.predict_all_careers(user_skills)
        ncf_map = {r["career"]: r["ncfScore"] for r in ncf_results}

        # 3. Market demand scores
        if market_scores is None:
            market_scores = _get_default_market_scores()

        # Combine
        all_careers = set(content_map.keys()) | set(ncf_map.keys())
        results = []

        for career in all_careers:
            content_data = content_map.get(career, {})
            content_score = content_data.get("score", 0.3)
            ncf_score = ncf_map.get(career, 0.3)
            market_score = market_scores.get(career, 0.5)

            # Weighted hybrid
            hybrid = (
                self.CONTENT_WEIGHT * content_score +
                self.COLLABORATIVE_WEIGHT * ncf_score +
                self.MARKET_WEIGHT * market_score
            )

            # Confidence: higher when all signals agree, lower on cold start
            scores = [content_score, ncf_score, market_score]
            agreement = 1.0 - np.std(scores)  # Higher when scores are similar
            data_confidence = min(1.0, len(user_skills) / 5)  # More skills = more confident
            confidence = round((agreement * 0.6 + data_confidence * 0.4) * 100, 1)

            results.append({
                "career": career,
                "hybridScore": round(hybrid, 4),
                "matchPercentage": round(hybrid * 100, 1),
                "contentScore": round(content_score, 4),
                "collaborativeScore": round(ncf_score, 4),
                "marketScore": round(market_score, 4),
                "confidence": confidence,
                "matchedSkills": content_data.get("matchedSkills", []),
                "missingSkills": content_data.get("missingSkills", []),
                "scoreBreakdown": {
                    "content": f"{round(content_score * 100, 1)}% (weight: {self.CONTENT_WEIGHT})",
                    "collaborative": f"{round(ncf_score * 100, 1)}% (weight: {self.COLLABORATIVE_WEIGHT})",
                    "market": f"{round(market_score * 100, 1)}% (weight: {self.MARKET_WEIGHT})",
                },
            })

        results.sort(key=lambda x: x["hybridScore"], reverse=True)
        return results[:top_n]


def _get_default_market_scores() -> dict[str, float]:
    """
    Default market demand scores normalized to 0-1.
    In production, these come from MarketTrend table.
    """
    return {
        "Data Scientist": 0.94,
        "ML Engineer": 0.97,
        "Full Stack Developer": 0.88,
        "Cloud Engineer": 0.92,
        "DevOps Engineer": 0.89,
        "Cybersecurity Analyst": 0.91,
        "Backend Developer": 0.85,
        "Frontend Developer": 0.80,
        "Data Analyst": 0.82,
        "AI Engineer": 0.97,
    }


# ── Module-level singleton ───────────────────────────────────────────────────

_recommender: Optional[HybridRecommender] = None


def get_hybrid_recommender() -> HybridRecommender:
    """Get or create the singleton hybrid recommender."""
    global _recommender
    if _recommender is None:
        _recommender = HybridRecommender()
        _recommender.ensure_trained()
    return _recommender


def get_hybrid_recommendations(
    user_skills: list[str],
    market_scores: dict[str, float] | None = None,
    top_n: int = 5,
) -> list[dict]:
    """Convenience function for route handlers."""
    recommender = get_hybrid_recommender()
    return recommender.recommend(user_skills, market_scores, top_n)
