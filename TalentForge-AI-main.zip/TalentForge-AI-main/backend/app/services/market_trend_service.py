"""
Market Trend Service — same static 2026 dataset as C# MarketTrendService.
Seeds the PostgreSQL market_trends table on first run.
"""
import logging
from ..models.market_trend import MarketTrend
from ..extensions import db

logger = logging.getLogger(__name__)

MARKET_TRENDS_DATA = [
    {"job_title": "AI/ML Engineer",           "category": "AI & Data",   "demand_score": 97, "average_salary_lpa": 28, "growth_rate": 42, "is_trending": True,  "industry": "Technology",   "top_skills_required": ["Python", "TensorFlow", "LLMs", "MLOps", "Cloud"]},
    {"job_title": "Data Scientist",            "category": "AI & Data",   "demand_score": 94, "average_salary_lpa": 22, "growth_rate": 36, "is_trending": True,  "industry": "Technology",   "top_skills_required": ["Python", "ML", "SQL", "Statistics", "Pandas"]},
    {"job_title": "Cloud Architect",           "category": "Cloud",       "demand_score": 92, "average_salary_lpa": 32, "growth_rate": 38, "is_trending": True,  "industry": "Technology",   "top_skills_required": ["AWS", "Azure", "Kubernetes", "Terraform", "Networking"]},
    {"job_title": "Cybersecurity Analyst",     "category": "Security",    "demand_score": 91, "average_salary_lpa": 24, "growth_rate": 35, "is_trending": True,  "industry": "Finance",      "top_skills_required": ["Networking", "SIEM", "Python", "Ethical Hacking", "Linux"]},
    {"job_title": "DevOps Engineer",           "category": "Cloud",       "demand_score": 89, "average_salary_lpa": 20, "growth_rate": 30, "is_trending": True,  "industry": "Technology",   "top_skills_required": ["Docker", "Kubernetes", "CI/CD", "Linux", "Python"]},
    {"job_title": "Data Engineer",             "category": "AI & Data",   "demand_score": 90, "average_salary_lpa": 21, "growth_rate": 33, "is_trending": True,  "industry": "Technology",   "top_skills_required": ["Python", "Spark", "Kafka", "SQL", "Airflow"]},
    {"job_title": "Full Stack Developer",      "category": "Web Dev",     "demand_score": 88, "average_salary_lpa": 18, "growth_rate": 25, "is_trending": False, "industry": "Technology",   "top_skills_required": ["React", "Node.js", "TypeScript", "SQL", "Docker"]},
    {"job_title": "Prompt Engineer",           "category": "AI & Data",   "demand_score": 85, "average_salary_lpa": 20, "growth_rate": 60, "is_trending": True,  "industry": "Technology",   "top_skills_required": ["LLMs", "Python", "NLP", "Communication", "API"]},
    {"job_title": "Product Manager",           "category": "Management",  "demand_score": 82, "average_salary_lpa": 25, "growth_rate": 20, "is_trending": False, "industry": "Technology",   "top_skills_required": ["Agile", "Roadmapping", "Communication", "Analytics", "Leadership"]},
    {"job_title": "UI/UX Designer",            "category": "Design",      "demand_score": 80, "average_salary_lpa": 14, "growth_rate": 18, "is_trending": False, "industry": "Technology",   "top_skills_required": ["Figma", "User Research", "Prototyping", "CSS", "Accessibility"]},
    {"job_title": "Blockchain Developer",      "category": "Web3",        "demand_score": 78, "average_salary_lpa": 26, "growth_rate": 28, "is_trending": False, "industry": "Finance",      "top_skills_required": ["Solidity", "Ethereum", "Web3.js", "Smart Contracts", "Cryptography"]},
    {"job_title": "Embedded Systems Engineer", "category": "Hardware",    "demand_score": 75, "average_salary_lpa": 16, "growth_rate": 15, "is_trending": False, "industry": "Manufacturing","top_skills_required": ["C", "C++", "RTOS", "Microcontrollers", "PCB Design"]},
]


def get_all_trends() -> list[dict]:
    trends = MarketTrend.query.order_by(MarketTrend.demand_score.desc()).all()
    return [t.to_dict() for t in trends]


def get_top_skills(limit: int = 12) -> list[str]:
    from collections import Counter
    trends = MarketTrend.query.all()
    all_skills = [skill for t in trends for skill in (t.top_skills_required or [])]
    counter = Counter(all_skills)
    return [skill for skill, _ in counter.most_common(limit)]


def get_trends_by_industry(industry: str) -> list[dict]:
    trends = MarketTrend.query.filter(
        db.func.lower(MarketTrend.industry) == industry.lower()
    ).all()
    return [t.to_dict() for t in trends]


def seed_market_trends() -> None:
    """Seed the market_trends table if empty."""
    if MarketTrend.query.count() == 0:
        for data in MARKET_TRENDS_DATA:
            trend = MarketTrend(**data)
            db.session.add(trend)
        db.session.commit()


def get_demand_scores_normalized() -> dict[str, float]:
    """
    Get demand scores for all careers normalized to 0.0 - 1.0.
    """
    try:
        trends = MarketTrend.query.all()
        if not trends:
            return _get_fallback_demand_scores()
        
        scores = {}
        for t in trends:
            scores[t.job_title] = float(t.demand_score) / 100.0
        
        normalized = {}
        for title, score in scores.items():
            if title == "AI/ML Engineer":
                normalized["ML Engineer"] = score
            elif title == "Cloud Architect":
                normalized["Cloud Engineer"] = score
            normalized[title] = score
        return normalized
    except Exception as exc:
        logger.error(f"Error normalizing demand scores: {exc}")
        return _get_fallback_demand_scores()


def _get_fallback_demand_scores() -> dict[str, float]:
    return {
        "Data Scientist": 0.94,
        "ML Engineer": 0.97,
        "Full Stack Developer": 0.88,
        "Cloud Engineer": 0.92,
        "DevOps Engineer": 0.89,
        "Cybersecurity Analyst": 0.91,
        "Backend Developer": 0.85,
        "Frontend Developer": 0.80,
        "Data Analyst": 0.82,
        "AI Engineer": 0.97,
    }


def get_skill_demand_scores() -> list[dict]:
    """
    Compute demand scores for individual skills based on job demand and occurrence.
    Returns sorted list of {"skill": str, "demandScore": int}.
    """
    try:
        trends = MarketTrend.query.all()
        if not trends:
            return _get_fallback_skill_scores()
        
        skill_weights = {}
        for t in trends:
            for skill in (t.top_skills_required or []):
                skill_clean = skill.strip().title()
                if skill_clean not in skill_weights:
                    skill_weights[skill_clean] = []
                skill_weights[skill_clean].append(t.demand_score)
                
        results = []
        for skill, scores in skill_weights.items():
            avg_score = int(sum(scores) / len(scores))
            results.append({"skill": skill, "demandScore": avg_score})
            
        return sorted(results, key=lambda x: x["demandScore"], reverse=True)
    except Exception as exc:
        logger.error(f"Error computing skill scores: {exc}")
        return _get_fallback_skill_scores()


def _get_fallback_skill_scores() -> list[dict]:
    return [
        {"skill": "Python", "demandScore": 95},
        {"skill": "Docker", "demandScore": 88},
        {"skill": "Kubernetes", "demandScore": 85},
        {"skill": "AWS", "demandScore": 92},
        {"skill": "React", "demandScore": 87},
        {"skill": "SQL", "demandScore": 84},
        {"skill": "TypeScript", "demandScore": 82},
        {"skill": "TensorFlow", "demandScore": 80},
    ]

