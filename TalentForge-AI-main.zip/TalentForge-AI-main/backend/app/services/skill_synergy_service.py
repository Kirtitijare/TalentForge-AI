"""
Skill Synergy Analysis Service.

Unique USP: Analyzes which skill *combinations* are most valuable in the market.
Most platforms rate individual skills. TalentForge shows synergy effects —
how much more valuable skills are together vs individually.

Example: "Python + Machine Learning + Cloud" together have a 3.2x synergy multiplier,
meaning that combination is 3.2x more in-demand than each skill individually.
"""
import logging
from collections import Counter, defaultdict
from itertools import combinations
from typing import Optional

logger = logging.getLogger(__name__)

# Import career and market data
from .ml_service import CAREER_CORPUS, CAREER_SKILL_MAP

# ── Skill Co-occurrence Matrix ───────────────────────────────────────────────

# Market demand weights for each career (normalized from MarketTrend data)
CAREER_DEMAND_WEIGHTS = {
    "Data Scientist": 0.94,
    "ML Engineer": 0.97,
    "Full Stack Developer": 0.88,
    "Cloud Engineer": 0.92,
    "DevOps Engineer": 0.89,
    "Cybersecurity Analyst": 0.91,
    "Backend Developer": 0.85,
    "Frontend Developer": 0.80,
    "Data Analyst": 0.82,
    "AI Engineer": 0.97,
}

# Skill category mapping for richer analysis
SKILL_CATEGORIES = {
    "python": "Programming",
    "java": "Programming",
    "javascript": "Programming",
    "typescript": "Programming",
    "c#": "Programming",
    "go": "Programming",
    "rust": "Programming",
    "r": "Programming",
    "react": "Frontend",
    "angular": "Frontend",
    "vue": "Frontend",
    "html": "Frontend",
    "css": "Frontend",
    "node.js": "Backend",
    "flask": "Backend",
    "django": "Backend",
    "fastapi": "Backend",
    "express": "Backend",
    "sql": "Data",
    "mongodb": "Data",
    "postgresql": "Data",
    "redis": "Data",
    "pandas": "Data",
    "numpy": "Data",
    "docker": "DevOps",
    "kubernetes": "DevOps",
    "ci/cd": "DevOps",
    "terraform": "DevOps",
    "ansible": "DevOps",
    "jenkins": "DevOps",
    "aws": "Cloud",
    "azure": "Cloud",
    "gcp": "Cloud",
    "machine learning": "AI/ML",
    "deep learning": "AI/ML",
    "tensorflow": "AI/ML",
    "pytorch": "AI/ML",
    "scikit-learn": "AI/ML",
    "llms": "AI/ML",
    "networking": "Infrastructure",
    "linux": "Infrastructure",
    "cybersecurity": "Security",
    "communication": "Soft Skills",
    "leadership": "Soft Skills",
    "teamwork": "Soft Skills",
    "agile": "Management",
    "scrum": "Management",
}


def analyze_skill_synergies(
    user_skills: list[str],
    top_n: int = 10,
) -> dict:
    """
    Analyze skill synergies for a user's skill set.

    Returns:
    {
        synergies: [
            {
                skills: ["Python", "ML", "Cloud"],
                synergyScore: 3.2,
                demandBoost: "+45%",
                relevantCareers: ["ML Engineer", "AI Engineer"],
                category: "AI/ML + Cloud",
                insight: "This combination is highly sought..."
            }
        ],
        topPairs: [{skill1, skill2, score}],
        skillCategories: {category: [skills]},
        overallSynergyScore: float,
        recommendations: [str],
    }
    """
    user_set = {s.strip().lower() for s in user_skills}

    # Compute co-occurrence weighted by career demand
    pair_scores = _compute_pair_synergies(user_set)
    triple_scores = _compute_triple_synergies(user_set)

    # Format results
    synergies = []

    # Add triple synergies (most impressive)
    for combo, score_data in sorted(
        triple_scores.items(), key=lambda x: x[1]["synergy"], reverse=True
    )[:top_n // 2]:
        skills = list(combo)
        categories = _get_combo_categories(skills)
        synergies.append({
            "skills": [s.title() for s in skills],
            "synergyScore": round(score_data["synergy"], 2),
            "demandBoost": f"+{int(score_data['demand_boost'] * 100)}%",
            "relevantCareers": score_data["careers"][:3],
            "category": " + ".join(sorted(set(categories))),
            "insight": _generate_synergy_insight(skills, score_data),
        })

    # Add pair synergies
    for combo, score_data in sorted(
        pair_scores.items(), key=lambda x: x[1]["synergy"], reverse=True
    )[:top_n // 2]:
        skills = list(combo)
        categories = _get_combo_categories(skills)
        synergies.append({
            "skills": [s.title() for s in skills],
            "synergyScore": round(score_data["synergy"], 2),
            "demandBoost": f"+{int(score_data['demand_boost'] * 100)}%",
            "relevantCareers": score_data["careers"][:3],
            "category": " + ".join(sorted(set(categories))),
            "insight": _generate_synergy_insight(skills, score_data),
        })

    # Sort all synergies by score
    synergies.sort(key=lambda x: x["synergyScore"], reverse=True)

    # Top pairs
    top_pairs = [
        {
            "skill1": list(combo)[0].title(),
            "skill2": list(combo)[1].title(),
            "score": round(data["synergy"], 2),
        }
        for combo, data in sorted(
            pair_scores.items(), key=lambda x: x[1]["synergy"], reverse=True
        )[:8]
    ]

    # Categorize user's skills
    skill_categories = defaultdict(list)
    for skill in user_set:
        cat = SKILL_CATEGORIES.get(skill, "Other")
        skill_categories[cat].append(skill.title())

    # Overall synergy score (average of all pair synergies)
    all_pair_synergies = [d["synergy"] for d in pair_scores.values()]
    overall_score = round(
        sum(all_pair_synergies) / len(all_pair_synergies) if all_pair_synergies else 1.0,
        2,
    )

    # Generate recommendations
    recommendations = _generate_recommendations(user_set, pair_scores, triple_scores)

    return {
        "synergies": synergies[:top_n],
        "topPairs": top_pairs,
        "skillCategories": dict(skill_categories),
        "overallSynergyScore": overall_score,
        "recommendations": recommendations,
        "userSkillCount": len(user_set),
    }


def get_top_skill_combinations(top_n: int = 15) -> list[dict]:
    """
    Get the top skill combinations across all careers, regardless of user skills.
    Useful for showing "trending skill combos" to all users.
    """
    all_skills_flat = set()
    for skills in CAREER_CORPUS.values():
        all_skills_flat.update(s.lower() for s in skills)

    pair_scores = _compute_pair_synergies(all_skills_flat)

    results = []
    for combo, data in sorted(
        pair_scores.items(), key=lambda x: x[1]["synergy"], reverse=True
    )[:top_n]:
        skills = list(combo)
        results.append({
            "skills": [s.title() for s in skills],
            "synergyScore": round(data["synergy"], 2),
            "demandBoost": f"+{int(data['demand_boost'] * 100)}%",
            "relevantCareers": data["careers"][:3],
        })

    return results


# ── Internal Computation ─────────────────────────────────────────────────────

def _compute_pair_synergies(user_skills: set[str]) -> dict:
    """
    Compute synergy scores for all pairs of user skills.

    Synergy = (co-occurrence weight) / (individual occurrence weight)
    A synergy > 1.0 means the combination is more valuable than expected.
    """
    pair_scores = {}

    # Only consider pairs where both skills are in the user's set
    skill_list = list(user_skills)
    if len(skill_list) < 2:
        return pair_scores

    for s1, s2 in combinations(skill_list, 2):
        co_occurrence_weight = 0.0
        individual_s1 = 0.0
        individual_s2 = 0.0
        relevant_careers = []

        for career, career_skills in CAREER_CORPUS.items():
            career_set = {s.lower() for s in career_skills}
            demand = CAREER_DEMAND_WEIGHTS.get(career, 0.5)

            has_s1 = s1 in career_set
            has_s2 = s2 in career_set

            if has_s1:
                individual_s1 += demand
            if has_s2:
                individual_s2 += demand
            if has_s1 and has_s2:
                co_occurrence_weight += demand
                relevant_careers.append(career)

        # Synergy: co-occurrence relative to individual occurrence
        expected = (individual_s1 * individual_s2) / max(
            sum(CAREER_DEMAND_WEIGHTS.values()), 0.01
        )
        synergy = co_occurrence_weight / max(expected, 0.01)

        # Demand boost: how much does this pair boost overall demand
        max_individual = max(individual_s1, individual_s2, 0.01)
        demand_boost = (co_occurrence_weight - max_individual) / max_individual

        if co_occurrence_weight > 0:
            pair_scores[frozenset([s1, s2])] = {
                "synergy": synergy,
                "demand_boost": max(0, demand_boost),
                "co_occurrence": co_occurrence_weight,
                "careers": relevant_careers,
            }

    return pair_scores


def _compute_triple_synergies(user_skills: set[str]) -> dict:
    """Compute synergy for triples of skills."""
    triple_scores = {}
    skill_list = list(user_skills)

    if len(skill_list) < 3:
        return triple_scores

    # Limit computation for performance (top combinations only)
    for s1, s2, s3 in combinations(skill_list[:15], 3):
        co_occurrence = 0.0
        relevant_careers = []

        for career, career_skills in CAREER_CORPUS.items():
            career_set = {s.lower() for s in career_skills}
            demand = CAREER_DEMAND_WEIGHTS.get(career, 0.5)

            if s1 in career_set and s2 in career_set and s3 in career_set:
                co_occurrence += demand
                relevant_careers.append(career)

        if co_occurrence > 0:
            # Synergy is higher for triples (rarer co-occurrence)
            avg_individual = sum(
                sum(
                    CAREER_DEMAND_WEIGHTS.get(c, 0.5)
                    for c, skills in CAREER_CORPUS.items()
                    if s.lower() in {sk.lower() for sk in skills}
                )
                for s in [s1, s2, s3]
            ) / 3

            synergy = (co_occurrence * 3) / max(avg_individual, 0.01)

            triple_scores[frozenset([s1, s2, s3])] = {
                "synergy": synergy,
                "demand_boost": min(1.5, co_occurrence / max(avg_individual, 0.01)),
                "co_occurrence": co_occurrence,
                "careers": relevant_careers,
            }

    return triple_scores


def _get_combo_categories(skills: list[str]) -> list[str]:
    """Get categories for a skill combination."""
    return [SKILL_CATEGORIES.get(s.lower(), "Other") for s in skills]


def _generate_synergy_insight(skills: list[str], score_data: dict) -> str:
    """Generate a human-readable insight for a skill synergy."""
    skill_names = " + ".join(s.title() for s in skills)
    careers = ", ".join(score_data["careers"][:2])
    score = score_data["synergy"]

    if score >= 3.0:
        return (
            f"{skill_names} is an exceptionally powerful combination. "
            f"Highly sought for {careers} roles. This combo puts you in the top tier."
        )
    elif score >= 2.0:
        return (
            f"{skill_names} creates strong synergy — these skills complement "
            f"each other well for {careers} positions."
        )
    elif score >= 1.5:
        return (
            f"{skill_names} is a solid combination with good market demand "
            f"in {careers}."
        )
    else:
        return (
            f"{skill_names} has moderate synergy. Consider deepening "
            f"expertise in these areas together."
        )


def _generate_recommendations(
    user_skills: set[str],
    pair_scores: dict,
    triple_scores: dict,
) -> list[str]:
    """Generate skill recommendations based on synergy analysis."""
    recommendations = []

    # Find skills that would create the highest synergy if added
    all_career_skills = set()
    for skills in CAREER_CORPUS.values():
        all_career_skills.update(s.lower() for s in skills)

    missing_skills = all_career_skills - user_skills
    skill_potential = {}

    for missing_skill in list(missing_skills)[:30]:  # Limit for performance
        potential_synergy = 0.0
        for user_skill in user_skills:
            for career, career_skills in CAREER_CORPUS.items():
                career_set = {s.lower() for s in career_skills}
                demand = CAREER_DEMAND_WEIGHTS.get(career, 0.5)
                if missing_skill in career_set and user_skill in career_set:
                    potential_synergy += demand

        if potential_synergy > 0:
            skill_potential[missing_skill] = potential_synergy

    # Top recommended skills to learn
    sorted_potential = sorted(skill_potential.items(), key=lambda x: x[1], reverse=True)
    if sorted_potential:
        top3 = [s.title() for s, _ in sorted_potential[:3]]
        recommendations.append(
            f"Learning {', '.join(top3)} would create the highest synergy "
            f"with your existing skills."
        )

    # Cross-category recommendation
    user_categories = set(SKILL_CATEGORIES.get(s, "Other") for s in user_skills)
    all_categories = set(SKILL_CATEGORIES.values())
    missing_categories = all_categories - user_categories - {"Other", "Soft Skills"}

    if missing_categories:
        cat = next(iter(missing_categories))
        cat_skills = [s.title() for s, c in SKILL_CATEGORIES.items() if c == cat][:3]
        if cat_skills:
            recommendations.append(
                f"You're missing skills in the '{cat}' category. "
                f"Adding {', '.join(cat_skills)} would broaden your profile."
            )

    # Synergy strength insight
    if pair_scores:
        avg_synergy = sum(d["synergy"] for d in pair_scores.values()) / len(pair_scores)
        if avg_synergy >= 2.0:
            recommendations.append(
                "Your skill set has excellent synergy! You have skills that are "
                "frequently required together across high-demand careers."
            )
        elif avg_synergy >= 1.5:
            recommendations.append(
                "Your skills show good synergy. Deepening expertise in your strongest "
                "skill combinations will maximize your market value."
            )
        else:
            recommendations.append(
                "Consider focusing on skills that are commonly paired together. "
                "Skill combinations are more valuable than isolated expertise."
            )

    return recommendations
