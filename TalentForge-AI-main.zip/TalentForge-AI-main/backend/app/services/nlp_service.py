"""
NLP Service — spaCy-based resume text extraction and skill detection.
Replaces PdfPig (C#) with pdfplumber, and adds spaCy NER for local skill extraction.
"""
import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)

# Master skill vocabulary (same as C# CollaborativeFilteringService.SkillVocabulary + extras)
SKILL_VOCABULARY = [
    "python", "java", "c#", "javascript", "typescript", "react", "angular", "vue",
    "node.js", "asp.net", "django", "flask", "fastapi", "sql", "mongodb", "postgresql",
    "mysql", "redis", "docker", "kubernetes", "aws", "azure", "gcp", "git",
    "machine learning", "deep learning", "tensorflow", "pytorch", "scikit-learn",
    "data analysis", "pandas", "numpy", "tableau", "power bi", "excel",
    "html", "css", "bootstrap", "tailwind", "figma", "ui/ux",
    "communication", "leadership", "teamwork", "problem solving", "agile", "scrum",
    "cybersecurity", "networking", "linux", "devops", "ci/cd", "rest api", "graphql",
    "spark", "kafka", "airflow", "mlops", "llms", "langchain", "huggingface",
    "terraform", "ansible", "jenkins", "prometheus", "grafana", "elasticsearch",
    "r", "matlab", "scala", "go", "rust", "swift", "kotlin", "php", "ruby",
    "next.js", "express", "spring boot", "laravel", "rails", "fastapi",
    "solidity", "web3", "blockchain", "smart contracts",
    "prompt engineering", "rag", "vector databases", "openai",
    "penetration testing", "ethical hacking", "siem", "wireshark",
    "microservices", "grpc", "rabbitmq", "celery",
    "seaborn", "matplotlib", "plotly", "d3.js", "recharts",
    "unit testing", "pytest", "jest", "selenium", "cypress",
]


def extract_text_from_pdf(file_path: str) -> str:
    """Extract plain text from a PDF file using pdfplumber."""
    try:
        import pdfplumber
        text_parts = []
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(page_text)
        return "\n".join(text_parts)
    except Exception as exc:
        logger.error("PDF extraction error for %s: %s", file_path, exc)
        return ""


def extract_text_from_pdf_bytes(file_bytes: bytes) -> str:
    """Extract text from PDF bytes (for S3 or in-memory uploads)."""
    import io
    try:
        import pdfplumber
        text_parts = []
        with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(page_text)
        return "\n".join(text_parts)
    except Exception as exc:
        logger.error("PDF bytes extraction error: %s", exc)
        return ""


def extract_skills_with_spacy(text: str) -> list[str]:
    """
    Use spaCy PhraseMatcher to find skills from the vocabulary in resume text.
    Falls back to simple substring matching if spaCy model is unavailable.
    """
    try:
        import spacy
        from spacy.matcher import PhraseMatcher

        nlp = _get_spacy_model()
        matcher = PhraseMatcher(nlp.vocab, attr="LOWER")
        patterns = [nlp.make_doc(skill.lower()) for skill in SKILL_VOCABULARY]
        matcher.add("SKILLS", patterns)

        doc = nlp(text.lower())
        matches = matcher(doc)
        found = {doc[start:end].text.lower() for _, start, end in matches}

        # Map back to proper-cased skill names
        skill_map = {s.lower(): s for s in SKILL_VOCABULARY}
        return [skill_map.get(s, s) for s in found]

    except Exception as exc:
        logger.warning("spaCy skill extraction failed, using fallback: %s", exc)
        return _extract_skills_fallback(text)


def _extract_skills_fallback(text: str) -> list[str]:
    """Simple case-insensitive substring matching as fallback."""
    text_lower = text.lower()
    found = []
    for skill in SKILL_VOCABULARY:
        # Use word boundary matching for short skills to avoid false positives
        pattern = r"\b" + re.escape(skill.lower()) + r"\b"
        if re.search(pattern, text_lower):
            found.append(skill)
    return found


def extract_emails(text: str) -> list[str]:
    pattern = r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
    return re.findall(pattern, text)


def extract_phone_numbers(text: str) -> list[str]:
    pattern = r"[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}"
    return re.findall(pattern, text)


def extract_section(text: str, section_name: str) -> str:
    """
    Attempt to extract a named section (e.g. 'EXPERIENCE', 'EDUCATION') from resume text.
    """
    pattern = rf"(?i){re.escape(section_name)}[:\s]*\n(.*?)(?=\n[A-Z]{{3,}}|\Z)"
    match = re.search(pattern, text, re.DOTALL)
    return match.group(1).strip() if match else ""


# ── spaCy model singleton ─────────────────────────────────────────────────────

_nlp_model = None


def _get_spacy_model():
    global _nlp_model
    if _nlp_model is None:
        import spacy
        try:
            _nlp_model = spacy.load("en_core_web_sm")
        except OSError:
            logger.warning("spaCy model 'en_core_web_sm' not found. Run: python -m spacy download en_core_web_sm")
            # Blank English model as fallback
            _nlp_model = spacy.blank("en")
    return _nlp_model
