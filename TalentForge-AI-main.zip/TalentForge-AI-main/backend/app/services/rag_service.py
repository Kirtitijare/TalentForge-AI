"""
RAG Service — Retrieval-Augmented Generation for Career Chatbot.

Architecture:
  1. Career Knowledge Base: comprehensive corpus of career information
  2. TF-IDF Vectorizer: lightweight document embeddings (no external API needed)
  3. Semantic Search: retrieve top-K relevant documents for any query
  4. Context Injection: augment Groq prompts with retrieved knowledge + user profile

This makes the chatbot dramatically more accurate and context-aware compared to
raw LLM prompts, because it grounds responses in specific career data.
"""
import logging
import numpy as np
from typing import Optional
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

logger = logging.getLogger(__name__)


# ── Career Knowledge Base ────────────────────────────────────────────────────
# Rich, structured documents covering careers, skills, salaries, certifications,
# industry trends, and career transition paths.

CAREER_KNOWLEDGE_BASE = [
    # ── Data Scientist ──
    {
        "id": "ds_overview",
        "career": "Data Scientist",
        "category": "overview",
        "content": (
            "Data Scientist: Analyzes complex datasets to extract actionable insights using statistics, "
            "machine learning, and data visualization. Works across industries including tech, finance, "
            "healthcare, and e-commerce. Average salary in India: ₹12-35 LPA depending on experience. "
            "Entry-level starts at ₹6-12 LPA. Senior roles (7+ years) can reach ₹40-60 LPA. "
            "Job growth rate: 36% YoY. Demand score: 94/100 in 2026."
        ),
    },
    {
        "id": "ds_skills",
        "career": "Data Scientist",
        "category": "skills",
        "content": (
            "Core skills for Data Scientist: Python (essential), R (optional), SQL (critical for data queries), "
            "Statistics & Probability (foundation), Machine Learning (scikit-learn, supervised/unsupervised), "
            "Deep Learning (TensorFlow/PyTorch for advanced roles), Data Visualization (Matplotlib, Seaborn, Plotly), "
            "Pandas & NumPy (daily tools), Feature Engineering, A/B Testing, Jupyter Notebooks. "
            "Soft skills: Communication (explaining results to non-technical stakeholders), "
            "Problem-solving, Business acumen, Storytelling with data."
        ),
    },
    {
        "id": "ds_certifications",
        "career": "Data Scientist",
        "category": "certifications",
        "content": (
            "Top certifications for Data Scientist: "
            "1. Google Professional Data Engineer ($200, intermediate) — validates data pipeline and ML skills. "
            "2. IBM Data Science Professional Certificate (Coursera, $39/mo) — comprehensive beginner program. "
            "3. AWS Certified Machine Learning Specialty ($300, advanced) — cloud ML deployment. "
            "4. Microsoft Certified: Azure Data Scientist Associate ($165) — Azure ML ecosystem. "
            "5. TensorFlow Developer Certificate ($100) — validates deep learning skills. "
            "6. Kaggle competitions — practical portfolio builder, free."
        ),
    },
    {
        "id": "ds_transition",
        "career": "Data Scientist",
        "category": "transition",
        "content": (
            "Career transitions to Data Scientist: "
            "From Software Developer: Learn statistics, ML algorithms, pandas; leverage existing Python skills. Timeline: 6-9 months. "
            "From Data Analyst: Deepen ML knowledge, learn Python/R, build predictive models. Timeline: 4-6 months. "
            "From Business Analyst: Learn programming (Python), statistics, ML fundamentals. Timeline: 9-12 months. "
            "From Fresh Graduate (CS/Math): Focus on ML projects, Kaggle, internships. Timeline: 6-12 months. "
            "Career progression: Junior DS → DS → Senior DS → Lead DS → Principal DS / Head of Data Science → VP/CDO."
        ),
    },

    # ── ML Engineer ──
    {
        "id": "mle_overview",
        "career": "ML Engineer",
        "category": "overview",
        "content": (
            "ML Engineer: Designs, builds, and deploys machine learning models at scale. Bridges the gap between "
            "data science research and production systems. Average salary: ₹15-40 LPA. Senior roles: ₹45-80 LPA. "
            "Demand score: 97/100 — highest in tech. Growth rate: 42% YoY. "
            "ML Engineers are in massive demand due to the AI boom. Companies like Google, Meta, Amazon, "
            "and Indian startups all actively hiring. Key differentiator from Data Scientist: "
            "ML Engineer focuses on model deployment, scalability, and production pipelines."
        ),
    },
    {
        "id": "mle_skills",
        "career": "ML Engineer",
        "category": "skills",
        "content": (
            "Core skills for ML Engineer: Python (expert level), TensorFlow/PyTorch (model building), "
            "Docker & Kubernetes (containerization, orchestration), MLOps (MLflow, Kubeflow, Airflow), "
            "Cloud (AWS SageMaker / GCP Vertex AI / Azure ML), REST APIs (FastAPI/Flask for serving), "
            "Git & CI/CD (version control, automated pipelines), Linux (command line proficiency), "
            "SQL & NoSQL databases, Model optimization (quantization, pruning, distillation), "
            "Monitoring (Prometheus, Grafana for model drift detection). "
            "Advanced: Distributed training, ONNX, TensorRT, model serving (TFServing, Triton)."
        ),
    },
    {
        "id": "mle_certifications",
        "career": "ML Engineer",
        "category": "certifications",
        "content": (
            "Top certifications for ML Engineer: "
            "1. AWS Certified Machine Learning Specialty ($300, advanced) — gold standard for cloud ML. "
            "2. Google Professional Machine Learning Engineer ($200) — GCP ML ecosystem. "
            "3. TensorFlow Developer Certificate ($100) — validates TF proficiency. "
            "4. Databricks Machine Learning Professional — big data ML. "
            "5. Deep Learning Specialization (Coursera, Andrew Ng) — foundational deep learning. "
            "6. MLOps Specialization (Coursera/Duke) — production ML systems."
        ),
    },

    # ── Full Stack Developer ──
    {
        "id": "fsd_overview",
        "career": "Full Stack Developer",
        "category": "overview",
        "content": (
            "Full Stack Developer: Builds complete web applications handling both frontend (user interface) "
            "and backend (server, database, APIs). Average salary: ₹8-25 LPA. Senior: ₹30-50 LPA. "
            "Demand score: 88/100. Growth rate: 25% YoY. "
            "One of the most versatile roles in tech. Startup-friendly — many startups prefer full-stack devs "
            "who can build entire products. Frameworks: MERN (MongoDB, Express, React, Node.js) and "
            "PERN (PostgreSQL, Express, React, Node.js) are most popular stacks."
        ),
    },
    {
        "id": "fsd_skills",
        "career": "Full Stack Developer",
        "category": "skills",
        "content": (
            "Core skills for Full Stack Developer: JavaScript/TypeScript (essential), React or Vue or Angular (frontend), "
            "Node.js with Express (backend), HTML5 & CSS3 (fundamentals), SQL (PostgreSQL/MySQL) and NoSQL (MongoDB), "
            "REST APIs and GraphQL, Git (version control), Docker (containerization), "
            "Authentication (JWT, OAuth2), Testing (Jest, Cypress), CI/CD pipelines, "
            "Cloud basics (AWS/Vercel/Railway for deployment). "
            "Optional advanced: Next.js (SSR), WebSockets, Redis, message queues."
        ),
    },

    # ── Cloud Engineer ──
    {
        "id": "ce_overview",
        "career": "Cloud Engineer",
        "category": "overview",
        "content": (
            "Cloud Engineer: Designs, implements, and manages cloud infrastructure. "
            "Works with AWS, Azure, or GCP to build scalable, reliable, and secure systems. "
            "Average salary: ₹12-35 LPA. Senior/Architect: ₹40-80 LPA. "
            "Demand score: 92/100. Growth rate: 38% YoY. "
            "Cloud spending is growing 20%+ annually. Every company is moving to cloud. "
            "Multi-cloud expertise (AWS + Azure) is especially valuable."
        ),
    },
    {
        "id": "ce_skills",
        "career": "Cloud Engineer",
        "category": "skills",
        "content": (
            "Core skills for Cloud Engineer: AWS (EC2, S3, RDS, Lambda, IAM, VPC, CloudFormation) or "
            "Azure (VMs, Blob Storage, AKS, Functions, AAD) or GCP (Compute Engine, Cloud Storage, GKE), "
            "Docker & Kubernetes (container orchestration), Terraform (Infrastructure as Code), "
            "Linux administration, Networking (TCP/IP, DNS, VPN, Load Balancers), "
            "CI/CD (Jenkins, GitHub Actions, CodePipeline), Python/Bash scripting, "
            "Security (IAM policies, encryption, compliance), Monitoring (CloudWatch, Datadog)."
        ),
    },

    # ── DevOps Engineer ──
    {
        "id": "devops_overview",
        "career": "DevOps Engineer",
        "category": "overview",
        "content": (
            "DevOps Engineer: Bridges development and operations, automating software delivery "
            "and infrastructure management. Average salary: ₹10-28 LPA. Senior: ₹30-50 LPA. "
            "Demand score: 89/100. Growth rate: 30% YoY. "
            "DevOps is now a standard practice — companies that don't have DevOps are falling behind. "
            "SRE (Site Reliability Engineering) is a related, equally high-demand role."
        ),
    },
    {
        "id": "devops_skills",
        "career": "DevOps Engineer",
        "category": "skills",
        "content": (
            "Core skills for DevOps Engineer: Docker (containerization), Kubernetes (orchestration), "
            "CI/CD (Jenkins, GitLab CI, GitHub Actions, ArgoCD), Linux (essential), "
            "Infrastructure as Code (Terraform, Ansible, Pulumi), Cloud (AWS/Azure/GCP), "
            "Monitoring (Prometheus, Grafana, ELK Stack), Git (advanced branching strategies), "
            "Scripting (Bash, Python), Networking fundamentals, "
            "Helm (Kubernetes package management), Service Mesh (Istio)."
        ),
    },

    # ── Cybersecurity Analyst ──
    {
        "id": "cyber_overview",
        "career": "Cybersecurity Analyst",
        "category": "overview",
        "content": (
            "Cybersecurity Analyst: Protects organizations from cyber threats by monitoring systems, "
            "investigating incidents, and implementing security measures. "
            "Average salary: ₹10-30 LPA. Senior/CISO: ₹40-80 LPA. "
            "Demand score: 91/100. Growth rate: 35% YoY. "
            "Cybersecurity is recession-proof — attacks increase during economic downturns. "
            "Major shortage of skilled professionals globally (3.5M unfilled positions)."
        ),
    },
    {
        "id": "cyber_skills",
        "career": "Cybersecurity Analyst",
        "category": "skills",
        "content": (
            "Core skills for Cybersecurity Analyst: Networking (TCP/IP, OSI model, firewalls, VPN), "
            "Linux (Kali Linux, command line), Python (scripting, automation), "
            "SIEM tools (Splunk, QRadar, Sentinel), Penetration Testing (Metasploit, Burp Suite), "
            "Vulnerability Assessment (Nessus, OpenVAS), Incident Response procedures, "
            "Cryptography (encryption, PKI, SSL/TLS), Compliance (ISO 27001, GDPR, SOC2), "
            "Network monitoring (Wireshark, tcpdump), Cloud security (AWS/Azure security services)."
        ),
    },
    {
        "id": "cyber_certifications",
        "career": "Cybersecurity Analyst",
        "category": "certifications",
        "content": (
            "Top certifications for Cybersecurity: "
            "1. CompTIA Security+ ($392) — entry-level, industry standard. "
            "2. CEH - Certified Ethical Hacker ($1,199) — penetration testing. "
            "3. CISSP ($749, advanced) — gold standard for security professionals. "
            "4. AWS Certified Security Specialty ($300) — cloud security. "
            "5. OSCP ($1,499) — hands-on penetration testing, highly respected. "
            "6. CompTIA CySA+ ($392) — SOC analyst focused."
        ),
    },

    # ── Backend Developer ──
    {
        "id": "be_overview",
        "career": "Backend Developer",
        "category": "overview",
        "content": (
            "Backend Developer: Builds server-side logic, APIs, databases, and system architecture. "
            "Average salary: ₹8-22 LPA. Senior: ₹25-45 LPA. "
            "Demand score: 85/100. Languages in demand: Python, Java, Go, Node.js. "
            "Frameworks: Django, Flask, FastAPI (Python), Spring Boot (Java), Express (Node.js). "
            "Backend devs with microservices and cloud experience command premium salaries."
        ),
    },

    # ── Frontend Developer ──
    {
        "id": "fe_overview",
        "career": "Frontend Developer",
        "category": "overview",
        "content": (
            "Frontend Developer: Creates user interfaces and user experiences for web applications. "
            "Average salary: ₹6-18 LPA. Senior: ₹20-40 LPA. "
            "Demand score: 80/100. React dominates the market (60%+ of frontend jobs). "
            "Next.js is becoming the default for React projects. TypeScript is now expected, not optional. "
            "Design skills (Figma) and accessibility knowledge are differentiators."
        ),
    },

    # ── Data Analyst ──
    {
        "id": "da_overview",
        "career": "Data Analyst",
        "category": "overview",
        "content": (
            "Data Analyst: Interprets data to help businesses make informed decisions. "
            "Average salary: ₹5-15 LPA. Senior: ₹18-30 LPA. "
            "Demand score: 82/100. Great entry point into data careers. "
            "Tools: SQL (most important), Excel (still widely used), Python (pandas), "
            "Tableau / Power BI (visualization), Google Analytics. "
            "Transition path: Data Analyst → Senior Analyst → Analytics Manager → Data Scientist."
        ),
    },

    # ── AI Engineer ──
    {
        "id": "aie_overview",
        "career": "AI Engineer",
        "category": "overview",
        "content": (
            "AI Engineer: Builds and deploys AI-powered applications. "
            "The hottest role in tech as of 2026. Average salary: ₹15-40 LPA. "
            "Senior: ₹50-100 LPA. Demand score: 97/100. Growth rate: 42% YoY. "
            "Key difference from ML Engineer: AI Engineers focus more on application-layer AI "
            "(LLMs, RAG, chatbots, agents) while ML Engineers focus on model training infrastructure. "
            "LLM expertise (OpenAI, Anthropic, Llama, Gemini) is the #1 skill."
        ),
    },
    {
        "id": "aie_skills",
        "career": "AI Engineer",
        "category": "skills",
        "content": (
            "Core skills for AI Engineer: Python (expert), LLM APIs (OpenAI, Anthropic, Groq), "
            "RAG (Retrieval-Augmented Generation) pipelines, Vector databases (Pinecone, Weaviate, pgvector), "
            "LangChain / LlamaIndex (orchestration), Prompt Engineering, "
            "Fine-tuning (LoRA, QLoRA), Deep Learning (Transformers architecture understanding), "
            "FastAPI/Flask (API serving), Docker, Cloud deployment (AWS/GCP), "
            "Evaluation frameworks (measuring AI quality), Guardrails (safety, reliability)."
        ),
    },

    # ── General Career Advice ──
    {
        "id": "general_transition",
        "career": "General",
        "category": "transition",
        "content": (
            "Career transition advice: "
            "1. Build projects, not just certifications — employers value demonstrable skills. "
            "2. Contribute to open source — shows real-world collaboration skills. "
            "3. Network on LinkedIn and attend tech meetups — 70% of jobs come through referrals. "
            "4. Start a technical blog or YouTube channel — establishes thought leadership. "
            "5. Don't try to learn everything — pick a specialization and go deep. "
            "6. Freelance or contract work can bridge the gap between careers. "
            "7. A portfolio project in your target role is worth more than 5 certificates."
        ),
    },
    {
        "id": "general_salary_negotiation",
        "career": "General",
        "category": "salary",
        "content": (
            "Salary negotiation for tech roles: "
            "1. Research market rates on levels.fyi, Glassdoor, and AmbitionBox. "
            "2. Factor in total compensation: base + bonus + stock + benefits. "
            "3. Having competing offers is the strongest negotiation tool. "
            "4. For freshers: focus on learning opportunity over salary for the first job. "
            "5. Remote roles at international companies often pay 2-3x Indian market rates. "
            "6. Contracting/freelancing through Toptal, Turing can pay $50-150/hr for experienced devs. "
            "7. Startup equity: risky but potentially very rewarding if company succeeds."
        ),
    },
    {
        "id": "general_interview",
        "career": "General",
        "category": "interview",
        "content": (
            "Interview preparation tips for tech roles: "
            "1. Data Structures & Algorithms — practice on LeetCode (Medium difficulty is usually enough). "
            "2. System Design — study from 'Designing Data-Intensive Applications' and system design primer. "
            "3. For ML roles: be ready to explain bias-variance tradeoff, regularization, and past project details. "
            "4. Behavioral questions — use STAR method (Situation, Task, Action, Result). "
            "5. Take-home projects: clean code, README, tests, and deployment matter. "
            "6. Mock interviews on Pramp.com or interviewing.io are invaluable. "
            "7. Know the company's tech stack and recent engineering blog posts."
        ),
    },
    {
        "id": "general_learning_resources",
        "career": "General",
        "category": "resources",
        "content": (
            "Best learning platforms and resources for tech careers in 2026: "
            "Free: freeCodeCamp, The Odin Project, CS50 (Harvard), fast.ai (ML), Khan Academy (Math). "
            "Paid: Coursera ($39-79/mo), Udemy (wait for sales, $10-15 courses), "
            "Pluralsight, educative.io (interactive), AlgoExpert (interview prep). "
            "YouTube channels: Fireship, Traversy Media, Sentdex, 3Blue1Brown (math), "
            "StatQuest (statistics), TechWorld with Nana (DevOps). "
            "Books: 'Hands-On ML with Scikit-Learn' (ML), 'Clean Code' (SE), "
            "'DDIA' (System Design), 'Cracking the Coding Interview'."
        ),
    },
    {
        "id": "general_2026_trends",
        "career": "General",
        "category": "trends",
        "content": (
            "Tech industry trends in 2026: "
            "1. AI/LLM integration is now expected in most software products. "
            "2. Full-stack AI engineers (can build + deploy AI features) are the most in-demand. "
            "3. Remote work is standard for tech roles — global talent pool means more competition. "
            "4. Cybersecurity demand is surging due to increasing AI-powered attacks. "
            "5. Cloud-native development is the default — on-premise is declining. "
            "6. Low-code/no-code tools complement (not replace) developers. "
            "7. Prompt engineering is a real skill but not a standalone career — it's a tool in the AI engineer toolkit. "
            "8. Blockchain/Web3 has settled into niche roles — not the gold rush of 2021. "
            "9. Green tech and sustainability roles are growing. "
            "10. Soft skills (communication, leadership) differentiate senior engineers from IC roles."
        ),
    },
]


# ── RAG Engine ───────────────────────────────────────────────────────────────

class RAGEngine:
    """
    Retrieval-Augmented Generation engine.
    Uses TF-IDF for document vectorization and cosine similarity for retrieval.
    """

    def __init__(self):
        self.documents = CAREER_KNOWLEDGE_BASE
        self.vectorizer = TfidfVectorizer(
            stop_words="english",
            max_features=5000,
            ngram_range=(1, 2),
        )
        self._build_index()

    def _build_index(self):
        """Build TF-IDF index over the knowledge base."""
        self.doc_texts = [doc["content"] for doc in self.documents]
        self.tfidf_matrix = self.vectorizer.fit_transform(self.doc_texts)
        logger.info(f"RAG index built: {len(self.documents)} documents, "
                     f"{self.tfidf_matrix.shape[1]} features")

    def search(self, query: str, top_k: int = 5) -> list[dict]:
        """
        Retrieve top-K most relevant documents for a query.

        Returns list of {document, score, career, category}.
        """
        query_vec = self.vectorizer.transform([query])
        similarities = cosine_similarity(query_vec, self.tfidf_matrix)[0]

        # Get top-K indices
        top_indices = similarities.argsort()[::-1][:top_k]

        results = []
        for idx in top_indices:
            if similarities[idx] < 0.05:  # Skip very low similarity
                continue
            doc = self.documents[idx]
            results.append({
                "content": doc["content"],
                "score": round(float(similarities[idx]), 4),
                "career": doc.get("career", "General"),
                "category": doc.get("category", ""),
                "id": doc.get("id", ""),
            })

        return results

    def search_with_user_context(
        self,
        query: str,
        user_skills: list[str] = None,
        user_interests: list[str] = None,
        top_k: int = 5,
    ) -> list[dict]:
        """
        Enhanced search that considers user context.
        Augments the query with user skills and interests for better retrieval.
        """
        # Build augmented query
        parts = [query]
        if user_skills:
            parts.append(f"skills: {', '.join(user_skills[:10])}")
        if user_interests:
            parts.append(f"interests: {', '.join(user_interests[:5])}")

        augmented_query = " ".join(parts)
        return self.search(augmented_query, top_k)

    def get_context_for_chat(
        self,
        message: str,
        user_skills: list[str] = None,
        user_interests: list[str] = None,
        user_education: str = None,
    ) -> str:
        """
        Build a RAG context string for the chat system prompt.
        Returns a formatted context block to inject into the LLM prompt.
        """
        results = self.search_with_user_context(
            message, user_skills, user_interests, top_k=4
        )

        if not results:
            return ""

        context_parts = ["--- RELEVANT CAREER KNOWLEDGE ---"]
        for i, r in enumerate(results, 1):
            context_parts.append(
                f"[Source {i} | {r['career']} - {r['category']}] "
                f"(relevance: {r['score']:.0%})\n{r['content']}"
            )
        context_parts.append("--- END KNOWLEDGE ---")

        # Add user profile context
        profile_parts = []
        if user_skills:
            profile_parts.append(f"User's current skills: {', '.join(user_skills[:15])}")
        if user_interests:
            profile_parts.append(f"User's interests: {', '.join(user_interests[:5])}")
        if user_education:
            profile_parts.append(f"User's education: {user_education}")

        if profile_parts:
            context_parts.insert(1, "--- USER PROFILE ---\n" + "\n".join(profile_parts) + "\n--- END PROFILE ---")

        return "\n\n".join(context_parts)


# ── Module-level singleton ───────────────────────────────────────────────────

_rag_engine: Optional[RAGEngine] = None


def get_rag_engine() -> RAGEngine:
    """Get or create the singleton RAG engine."""
    global _rag_engine
    if _rag_engine is None:
        _rag_engine = RAGEngine()
    return _rag_engine


def search_career_knowledge(query: str, top_k: int = 5) -> list[dict]:
    """Convenience function for route handlers."""
    return get_rag_engine().search(query, top_k)


def get_chat_context(
    message: str,
    user_skills: list[str] = None,
    user_interests: list[str] = None,
    user_education: str = None,
) -> str:
    """Convenience function to get RAG context for chat."""
    return get_rag_engine().get_context_for_chat(
        message, user_skills, user_interests, user_education
    )
