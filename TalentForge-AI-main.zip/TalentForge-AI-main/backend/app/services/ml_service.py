"""
ML Service — scikit-learn TF-IDF + cosine similarity.
Replaces the manual implementations in C# AIService and CollaborativeFilteringService.
Also handles pgvector skill embeddings.
"""
import logging
import numpy as np
from typing import Optional
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

logger = logging.getLogger(__name__)

# Same vocabulary as C# CollaborativeFilteringService
SKILL_VOCABULARY = [
    "python", "java", "c#", "javascript", "typescript", "react", "angular", "vue",
    "node.js", "asp.net", "django", "flask", "fastapi", "sql", "mongodb", "postgresql",
    "mysql", "redis", "docker", "kubernetes", "aws", "azure", "gcp", "git",
    "machine learning", "deep learning", "tensorflow", "pytorch", "scikit-learn",
    "data analysis", "pandas", "numpy", "tableau", "power bi", "excel",
    "html", "css", "bootstrap", "tailwind", "figma", "ui/ux",
    "communication", "leadership", "teamwork", "problem solving", "agile", "scrum",
    "cybersecurity", "networking", "linux", "devops", "ci/cd", "rest api", "graphql",
]

CAREER_CORPUS: dict[str, list[str]] = {
    "Data Scientist": ["python", "machine learning", "sql", "statistics", "tensorflow",
                       "pandas", "numpy", "data visualization", "deep learning", "scikit-learn"],
    "ML Engineer": ["python", "tensorflow", "pytorch", "docker", "kubernetes", "mlops",
                    "rest api", "git", "linux", "cloud"],
    "Full Stack Developer": ["javascript", "react", "node.js", "html", "css", "sql",
                             "rest api", "git", "docker", "typescript"],
    "Cloud Engineer": ["aws", "azure", "gcp", "docker", "kubernetes", "terraform",
                       "linux", "networking", "ci/cd", "python"],
    "DevOps Engineer": ["docker", "kubernetes", "ci/cd", "jenkins", "git", "linux",
                        "aws", "terraform", "ansible", "python"],
    "Cybersecurity Analyst": ["networking", "linux", "python", "ethical hacking", "siem",
                               "firewalls", "cryptography", "incident response", "compliance",
                               "risk assessment"],
    "Backend Developer": ["python", "flask", "sql", "rest api", "docker", "git",
                          "postgresql", "redis", "microservices", "aws"],
    "Frontend Developer": ["javascript", "react", "html", "css", "typescript", "figma",
                           "bootstrap", "tailwind", "git", "accessibility"],
    "Data Analyst": ["sql", "excel", "python", "tableau", "power bi", "statistics",
                     "data cleaning", "pandas", "communication", "storytelling"],
    "AI Engineer": ["python", "deep learning", "llms", "tensorflow", "pytorch", "mlops",
                    "rest api", "docker", "cloud", "prompt engineering"],
}


# ── TF-IDF content-based matching ────────────────────────────────────────────

def compute_tfidf_career_matches(user_skills: list[str]) -> list[dict]:
    """
    Use sklearn TfidfVectorizer to score user skills against each career's skill set.
    Returns list of {career, score, matchedSkills, missingSkills} sorted by score desc.
    """
    if not user_skills:
        return []

    user_set = {s.strip().lower() for s in user_skills}

    # Build corpus: each career's skills as a single document
    career_names = list(CAREER_CORPUS.keys())
    career_docs = [" ".join(skills) for skills in CAREER_CORPUS.values()]
    user_doc = " ".join(user_set)

    all_docs = career_docs + [user_doc]

    try:
        vectorizer = TfidfVectorizer(analyzer="word", token_pattern=r"[a-z][a-z0-9\.\+\#\/\-]+")
        tfidf_matrix = vectorizer.fit_transform(all_docs)

        # User vector is the last row
        user_vector = tfidf_matrix[-1]
        career_vectors = tfidf_matrix[:-1]

        similarities = cosine_similarity(user_vector, career_vectors)[0]

        results = []
        for i, career in enumerate(career_names):
            required = CAREER_CORPUS[career]
            matched = [s for s in required if s in user_set]
            missing = [s for s in required if s not in user_set]
            score = float(similarities[i])
            # Add 0.3 baseline (same as C# implementation)
            adjusted = min(1.0, max(0.0, score + 0.3))
            results.append({
                "career": career,
                "score": round(adjusted, 3),
                "matchPercentage": round(adjusted * 100, 1),
                "matchedSkills": matched[:8],
                "missingSkills": missing[:8],
            })

        return sorted(results, key=lambda x: x["score"], reverse=True)

    except Exception as exc:
        logger.error("TF-IDF computation error: %s", exc)
        return []


# ── Cosine similarity collaborative filtering ─────────────────────────────────

def build_skill_vector(skills: list[str]) -> np.ndarray:
    """Build a binary vector over SKILL_VOCABULARY for a user's skill list."""
    normalised = {s.strip().lower() for s in skills}
    return np.array([1.0 if v in normalised else 0.0 for v in SKILL_VOCABULARY])


def compute_cosine_similarity(vec_a: np.ndarray, vec_b: np.ndarray) -> float:
    """Cosine similarity between two numpy vectors."""
    mag_a = np.linalg.norm(vec_a)
    mag_b = np.linalg.norm(vec_b)
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return float(np.dot(vec_a, vec_b) / (mag_a * mag_b))


def find_similar_users(
    current_skills: list[str],
    all_users: list[dict],  # [{"id": str, "skills": list[str], "recommendations": list[str]}]
    min_similarity: float = 0.15,
    top_n: int = 5,
) -> list[dict]:
    """
    Collaborative filtering: find careers recommended to users similar to current user.
    Returns list of {careerTitle, similarityScore, similarUsersCount, commonSkills}.
    """
    current_vec = build_skill_vector(current_skills)
    career_scores: dict[str, dict] = {}

    for peer in all_users:
        peer_vec = build_skill_vector(peer.get("skills", []))
        sim = compute_cosine_similarity(current_vec, peer_vec)

        if sim < min_similarity:
            continue

        common = list(
            {s.lower() for s in current_skills} &
            {s.lower() for s in peer.get("skills", [])}
        )

        for career_title in peer.get("recommendations", []):
            if career_title not in career_scores:
                career_scores[career_title] = {
                    "totalSim": 0.0, "count": 0, "commonSkills": common
                }
            career_scores[career_title]["totalSim"] += sim
            career_scores[career_title]["count"] += 1

    if not career_scores:
        return _fallback_collaborative()

    results = [
        {
            "careerTitle": title,
            "similarityScore": round(v["totalSim"] / v["count"], 2),
            "similarUsersCount": v["count"],
            "commonSkills": v["commonSkills"][:5],
        }
        for title, v in career_scores.items()
    ]

    return sorted(results, key=lambda x: x["similarityScore"], reverse=True)[:top_n]


def _fallback_collaborative() -> list[dict]:
    return [
        {"careerTitle": "Data Scientist",       "similarityScore": 0.88, "similarUsersCount": 12, "commonSkills": ["Python", "Machine Learning", "SQL"]},
        {"careerTitle": "ML Engineer",           "similarityScore": 0.82, "similarUsersCount": 9,  "commonSkills": ["Python", "TensorFlow", "Docker"]},
        {"careerTitle": "Cloud Engineer",        "similarityScore": 0.76, "similarUsersCount": 7,  "commonSkills": ["AWS", "Docker", "Linux"]},
        {"careerTitle": "Full Stack Developer",  "similarityScore": 0.71, "similarUsersCount": 15, "commonSkills": ["JavaScript", "React", "Node.js"]},
        {"careerTitle": "DevOps Engineer",       "similarityScore": 0.65, "similarUsersCount": 6,  "commonSkills": ["Docker", "Kubernetes", "CI/CD"]},
    ]


# ── Skill gap analysis ────────────────────────────────────────────────────────

CAREER_SKILL_MAP: dict[str, list[str]] = {
    "Data Scientist":        ["Python", "Machine Learning", "SQL", "Statistics", "TensorFlow", "Pandas", "NumPy", "Data Visualization", "Deep Learning", "Scikit-learn"],
    "ML Engineer":           ["Python", "TensorFlow", "PyTorch", "Docker", "Kubernetes", "MLOps", "REST API", "Git", "Linux", "Cloud (AWS/GCP)"],
    "Full Stack Developer":  ["JavaScript", "React", "Node.js", "HTML", "CSS", "SQL", "REST API", "Git", "Docker", "TypeScript"],
    "Cloud Engineer":        ["AWS", "Azure", "GCP", "Docker", "Kubernetes", "Terraform", "Linux", "Networking", "CI/CD", "Python"],
    "DevOps Engineer":       ["Docker", "Kubernetes", "CI/CD", "Jenkins", "Git", "Linux", "AWS", "Terraform", "Ansible", "Python"],
    "Cybersecurity Analyst": ["Networking", "Linux", "Python", "Ethical Hacking", "SIEM", "Firewalls", "Cryptography", "Incident Response", "Compliance", "Risk Assessment"],
    "Backend Developer":     ["Python", "Flask", "SQL", "REST API", "Docker", "Git", "PostgreSQL", "Redis", "Microservices", "AWS"],
    "Frontend Developer":    ["JavaScript", "React", "HTML", "CSS", "TypeScript", "Figma", "Bootstrap", "Tailwind", "Git", "Accessibility"],
    "Data Analyst":          ["SQL", "Excel", "Python", "Tableau", "Power BI", "Statistics", "Data Cleaning", "Pandas", "Communication", "Storytelling"],
    "AI Engineer":           ["Python", "Deep Learning", "LLMs", "TensorFlow", "PyTorch", "MLOps", "REST API", "Docker", "Cloud", "Prompt Engineering"],
}


def analyze_skill_gap(user_skills: list[str], target_career: str) -> dict:
    """
    Returns {targetCareer, matchPercentage, matchedSkills, missingSkills, requiredSkills}.
    Uses fuzzy matching to find the best career key.
    """
    matched_key = _fuzzy_match_career(target_career)
    required = CAREER_SKILL_MAP.get(matched_key, CAREER_SKILL_MAP["Data Scientist"])
    user_set = {s.strip().lower() for s in user_skills}

    matched = [r for r in required if r.lower() in user_set]
    missing = [r for r in required if r.lower() not in user_set]
    pct = round(len(matched) / len(required) * 100, 1) if required else 0.0

    return {
        "targetCareer": matched_key,
        "matchPercentage": pct,
        "matchedSkills": matched,
        "missingSkills": missing,
        "requiredSkills": required,
    }


def _fuzzy_match_career(target: str) -> str:
    from difflib import SequenceMatcher
    target_lower = target.lower()
    best_key = "Data Scientist"
    best_score = 0

    for key in CAREER_SKILL_MAP:
        key_lower = key.lower()
        if key_lower == target_lower:
            return key
        if target_lower in key_lower or key_lower in target_lower:
            score = 80
        else:
            score = int(SequenceMatcher(None, key_lower, target_lower).ratio() * 100)

        if score > best_score:
            best_score = score
            best_key = key

    return best_key
