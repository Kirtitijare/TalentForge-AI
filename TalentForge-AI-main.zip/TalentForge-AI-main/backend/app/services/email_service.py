"""
Email Service — Flask-Mail for OTP delivery.
Mirrors C# EmailService (MailKit/Gmail SMTP).
"""
import logging
from flask_mail import Message
from ..extensions import mail

logger = logging.getLogger(__name__)


def send_otp_email(to_email: str, otp_code: str, otp_type: str = "registration") -> bool:
    """Send a styled OTP email. Returns True on success."""
    subject_map = {
        "registration": "Verify Your TalentForge AI Account",
        "password_reset": "Reset Your TalentForge AI Password",
    }
    subject = subject_map.get(otp_type, "Your TalentForge AI OTP")
    action_text = "verify your email" if otp_type == "registration" else "reset your password"

    html_body = f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body {{ font-family: 'Segoe UI', Arial, sans-serif; background: #f4f6fb; margin: 0; padding: 0; }}
    .container {{ max-width: 480px; margin: 40px auto; background: #fff; border-radius: 12px;
                  box-shadow: 0 4px 24px rgba(0,0,0,0.08); overflow: hidden; }}
    .header {{ background: linear-gradient(135deg, #6366f1, #8b5cf6); padding: 32px 24px; text-align: center; }}
    .header h1 {{ color: #fff; margin: 0; font-size: 24px; letter-spacing: 1px; }}
    .body {{ padding: 32px 24px; }}
    .otp-box {{ background: #f0f0ff; border: 2px dashed #6366f1; border-radius: 8px;
                text-align: center; padding: 20px; margin: 24px 0; }}
    .otp-code {{ font-size: 40px; font-weight: 700; color: #6366f1; letter-spacing: 8px; }}
    .note {{ color: #888; font-size: 13px; margin-top: 8px; }}
    .footer {{ background: #f4f6fb; padding: 16px 24px; text-align: center;
               color: #aaa; font-size: 12px; }}
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>TalentForge AI</h1>
    </div>
    <div class="body">
      <p>Hi there,</p>
      <p>Use the code below to <strong>{action_text}</strong>. This code expires in
         {'10' if otp_type == 'registration' else '15'} minutes.</p>
      <div class="otp-box">
        <div class="otp-code">{otp_code}</div>
        <div class="note">Do not share this code with anyone.</div>
      </div>
      <p>If you didn't request this, you can safely ignore this email.</p>
    </div>
    <div class="footer">
      &copy; 2026 TalentForge AI &mdash; AI-Powered Career Guidance
    </div>
  </div>
</body>
</html>
"""

    try:
        msg = Message(
            subject=subject,
            recipients=[to_email],
            html=html_body,
        )
        mail.send(msg)
        logger.info("OTP email sent to %s [%s]", to_email, otp_type)
        return True
    except Exception as exc:
        logger.error("Failed to send OTP email to %s: %s", to_email, exc)
        return False
