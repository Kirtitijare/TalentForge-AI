"""
ML Hybrid Service — ml_hybrid_service.py

Three-engine hybrid recommendation pipeline:
1. Content-Based (TF-IDF) — matches user skills to career requirements
2. Collaborative Filtering (SVD) — learns from user preference patterns
3. AI-Powered (Groq) — LLM analysis for skill extraction from resume
"""
import re
import io
import json
from datetime import datetime, timezone
import numpy as np
from rapidfuzz import process, fuzz
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Module-level trained SVD model cache
_svd_model = None
_svd_trained_at = None
_nlp_model = None


def _load_nlp_model():
    """Lazy-load spaCy model."""
    global _nlp_model
    if _nlp_model is None:
        try:
            import spacy
            _nlp_model = spacy.load("en_core_web_sm")
        except OSError:
            print("[ML] spaCy model not found. Run: python -m spacy download en_core_web_sm")
            _nlp_model = None
    return _nlp_model


def parse_resume_with_hybrid(pdf_bytes: bytes, user_id=None) -> dict:
    """
    Stage 1: pdfplumber extracts raw text
    Stage 2: spaCy NER cleans and sections text
    Stage 3: Groq LLM (via ai_service._call_groq) extracts structured JSON

    Returns:
        dict with keys: skills, experience_years, education, goals, inferred_interests
    """
    _fallback = {
        "skills": [],
        "experience_years": 0,
        "education": "Unable to parse",
        "goals": "Career development",
        "inferred_interests": []
    }

    try:
        import pdfplumber

        # STAGE 1: PDF text extraction
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            raw_text = "\n".join(
                (page.extract_text() or "") for page in pdf.pages
            )

        if not raw_text or not raw_text.strip():
            return _fallback

        # STAGE 2: spaCy section splitting (cap for LLM token limit)
        _load_nlp_model()
        cleaned_text = raw_text[:3000]

        # STAGE 3: LLM structured extraction via Groq (uses httpx, no SDK)
        from app.services.ai_service import _call_groq

        prompt = (
            "You are a resume parser. Extract information from this resume text and "
            "return ONLY a valid JSON object with no explanation, no markdown, no "
            "code blocks. Return raw JSON only.\n\n"
            f"Resume text:\n{cleaned_text}\n\n"
            "Return this exact JSON structure (use empty arrays/strings if not found):\n"
            '{\n'
            '  "skills": ["list of technical and soft skills found"],\n'
            '  "experience_years": <integer, total years of work experience, 0 if student>,\n'
            '  "education": "<highest degree and field>",\n'
            '  "goals": "<career goal or objective if mentioned, else infer from content>",\n'
            '  "inferred_interests": ["domains the person seems interested in based on resume"]\n'
            '}'
        )

        raw_response = _call_groq(prompt, max_tokens=500, temperature=0.1)

        # Strip any accidental markdown fences
        raw_json = re.sub(r"^```json|^```|```$", "", raw_response, flags=re.MULTILINE).strip()

        try:
            parsed = json.loads(raw_json)
        except json.JSONDecodeError:
            # Try to extract JSON object from response
            match = re.search(r"\{[\s\S]*\}", raw_json)
            if match:
                parsed = json.loads(match.group(0))
            else:
                print("[ML] Could not parse LLM JSON response")
                return _fallback

        # NORMALIZE skills against skill_taxonomy using rapidfuzz
        from app.models.skill_taxonomy import SkillTaxonomy
        all_skills = SkillTaxonomy.query.all()
        taxonomy_map = {}  # alias_lower → canonical_name
        for s in all_skills:
            taxonomy_map[s.skill_name.lower()] = s.skill_name
            for alias in (s.aliases or []):
                taxonomy_map[alias.lower()] = s.skill_name

        normalized_skills = []
        for raw_skill in parsed.get("skills", []):
            if not raw_skill:
                continue
            match_result = process.extractOne(
                raw_skill.lower(),
                list(taxonomy_map.keys()),
                scorer=fuzz.WRatio,
                score_cutoff=75
            )
            if match_result:
                canonical = taxonomy_map[match_result[0]]
                if canonical not in normalized_skills:
                    normalized_skills.append(canonical)

        parsed["skills"] = normalized_skills
        parsed["experience_years"] = int(parsed.get("experience_years") or 0)
        return parsed

    except Exception as e:
        print(f"[ML] Resume parsing error: {e}")
        return _fallback


def compute_content_scores(user_skills: list, all_careers: list) -> dict:
    """
    TF-IDF cosine similarity between user skill string and each
    career required_skills string.

    Returns:
        dict {career_slug: float score 0.0-1.0}
    """
    if not user_skills or not all_careers:
        return {}

    user_text = " ".join(user_skills).lower()

    career_texts = []
    career_slugs = []
    for career in all_careers:
        if career.required_skills:
            career_texts.append(" ".join(career.required_skills).lower())
            career_slugs.append(career.slug)

    if not career_texts:
        return {}

    corpus = [user_text] + career_texts
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
    tfidf_matrix = vectorizer.fit_transform(corpus)
    scores = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:]).flatten()

    return {slug: float(score) for slug, score in zip(career_slugs, scores)}


class _PurePythonSVD:
    """
    Lightweight matrix-factorization SVD using numpy only.
    Replaces scikit-surprise (which requires C compilation on Windows).
    Same SGD approach: learns user/item latent factors from ratings.
    """
    def __init__(self, n_factors=50, n_epochs=25, lr=0.005, reg=0.02, random_state=42):
        self.n_factors = n_factors
        self.n_epochs = n_epochs
        self.lr = lr
        self.reg = reg
        self.random_state = random_state
        self.user_map = {}   # uid_str -> index
        self.item_map = {}   # career_slug -> index
        self.global_mean = 3.0
        self.bu = None  # user biases
        self.bi = None  # item biases
        self.pu = None  # user factors
        self.qi = None  # item factors

    def fit(self, rows: list[dict]):
        """rows: list of {user_id, career_slug, rating}"""
        np.random.seed(self.random_state)

        # Build index maps
        users = list({r["user_id"] for r in rows})
        items = list({r["career_slug"] for r in rows})
        self.user_map = {u: i for i, u in enumerate(users)}
        self.item_map = {it: i for i, it in enumerate(items)}

        n_users = len(users)
        n_items = len(items)
        ratings = np.array([r["rating"] for r in rows])
        self.global_mean = float(ratings.mean())

        self.bu = np.zeros(n_users)
        self.bi = np.zeros(n_items)
        self.pu = np.random.normal(0, 0.1, (n_users, self.n_factors))
        self.qi = np.random.normal(0, 0.1, (n_items, self.n_factors))

        for _ in range(self.n_epochs):
            for r in rows:
                u = self.user_map[r["user_id"]]
                i = self.item_map[r["career_slug"]]
                rat = r["rating"]
                pred = self.global_mean + self.bu[u] + self.bi[i] + np.dot(self.pu[u], self.qi[i])
                err = rat - pred
                self.bu[u] += self.lr * (err - self.reg * self.bu[u])
                self.bi[i] += self.lr * (err - self.reg * self.bi[i])
                self.pu[u] += self.lr * (err * self.qi[i] - self.reg * self.pu[u])
                self.qi[i] += self.lr * (err * self.pu[u] - self.reg * self.qi[i])

    def predict(self, uid: str, iid: str) -> float:
        """Returns estimated rating (1-5). Falls back to global_mean if unknown."""
        u = self.user_map.get(uid)
        i = self.item_map.get(iid)
        if u is None or i is None:
            # Unknown user or item — return global mean + item bias if item known
            base = self.global_mean
            if i is not None:
                base += self.bi[i]
            return float(np.clip(base, 1.0, 5.0))
        est = self.global_mean + self.bu[u] + self.bi[i] + np.dot(self.pu[u], self.qi[i])
        return float(np.clip(est, 1.0, 5.0))


def train_svd_model():
    """
    Load career_ratings from DB and train pure-numpy SVD.
    Cached in module-level _svd_model. Re-trains when called again.
    """
    global _svd_model, _svd_trained_at

    try:
        from app.models.career_rating import CareerRating

        ratings = CareerRating.query.all()
        if len(ratings) < 10:
            _svd_model = None
            print("[ML] Insufficient training data for SVD (need >= 10 rows)")
            return

        rows = []
        for r in ratings:
            uid = r.user_id if r.user_id else f"anon_{r.id}"
            rows.append({
                "user_id": uid,
                "career_slug": r.career_slug,
                "rating": float(r.rating)
            })

        model = _PurePythonSVD(n_factors=50, n_epochs=25, lr=0.005, reg=0.02, random_state=42)
        model.fit(rows)

        _svd_model = model
        _svd_trained_at = datetime.now(timezone.utc)
        print(f"[ML] SVD model trained on {len(rows)} ratings")

    except Exception as e:
        _svd_model = None
        print(f"[ML] SVD training error: {e}")


def compute_cf_scores(user_id, career_slugs: list) -> dict:
    """
    Predict rating for each career for this user using trained SVD.

    Returns:
        dict {career_slug: float score 0.0-1.0}
        (normalized from 1-5 scale to 0-1)
    """
    global _svd_model
    if _svd_model is None:
        train_svd_model()
    if _svd_model is None:
        return {slug: 0.5 for slug in career_slugs}  # fallback

    try:
        uid_str = str(user_id)
        scores = {}
        for slug in career_slugs:
            est = _svd_model.predict(uid=uid_str, iid=slug)
            # Normalize: (rating - 1) / 4 maps 1-5 to 0-1
            normalized = (est - 1.0) / 4.0
            scores[slug] = float(max(0.0, min(1.0, normalized)))
        return scores
    except Exception as e:
        print(f"[ML] CF score computation error: {e}")
        return {slug: 0.5 for slug in career_slugs}


def hybrid_recommend(user_id, top_n: int = 5) -> list:
    """
    Main recommendation function. Runs TF-IDF + SVD engines, blends scores,
    computes skill gap, returns top_n careers.

    Returns:
        list of dicts with career details, scores, missing skills, learning resources
    """
    try:
        from app.models.user import User
        from app.models.market_trend import MarketTrend
        from app.models.skill_taxonomy import SkillTaxonomy

        user = User.query.get(user_id)
        if not user:
            return []

        user_skills = user.skills or []

        # Fetch all career roles that have required_skills set
        all_careers = MarketTrend.query.filter(
            MarketTrend.required_skills.isnot(None),
            MarketTrend.slug.isnot(None)
        ).all()

        if not all_careers:
            return []

        career_slugs = [c.slug for c in all_careers]
        career_map = {c.slug: c for c in all_careers}

        CONTENT_WEIGHT = 0.6
        CF_WEIGHT = 0.4

        content_scores = compute_content_scores(user_skills, all_careers)
        cf_scores = compute_cf_scores(user_id, career_slugs)

        # Fuse scores
        fused = []
        for slug in career_slugs:
            c_score = content_scores.get(slug, 0.0)
            cf_score = cf_scores.get(slug, 0.5)
            final = CONTENT_WEIGHT * c_score + CF_WEIGHT * cf_score
            fused.append((slug, final, c_score, cf_score))

        fused.sort(key=lambda x: x[1], reverse=True)
        top = fused[:top_n]

        # Build skill gap and learning resources
        taxonomy_map = {s.skill_name: s.learning_url for s in SkillTaxonomy.query.all()}
        user_skills_lower = {s.lower() for s in user_skills}

        results = []
        for slug, final_score, c_score, cf_score in top:
            career = career_map[slug]
            required = career.required_skills or []
            missing = [skill for skill in required if skill.lower() not in user_skills_lower]
            learning_resources = [
                {
                    "skill": skill,
                    "url": taxonomy_map.get(
                        skill,
                        f"https://www.google.com/search?q=learn+{skill.replace(' ', '+')}"
                    )
                }
                for skill in missing
            ]
            results.append({
                "career_slug": slug,
                "job_title": career.job_title,
                "final_score": round(final_score, 4),
                "match_percentage": round(final_score * 100, 1),
                "content_score": round(c_score, 4),
                "cf_score": round(cf_score, 4),
                "required_skills": required,
                "missing_skills": missing,
                "learning_resources": learning_resources,
                "avg_salary": career.average_salary_lpa,
                "demand_score": career.demand_score,
                "growth_rate": career.growth_rate,
                "industry": career.industry
            })

        return results

    except Exception as e:
        print(f"[ML] Hybrid recommendation error: {e}")
        return []
