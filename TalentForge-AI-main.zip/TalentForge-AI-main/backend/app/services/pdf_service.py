"""
PDF Report Service — ReportLab.
Replaces C# QuestPDF PdfReportService.
Generates a career guidance PDF report for a user.
"""
import io
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


def generate_career_report(user: dict, recommendations: list[dict]) -> bytes:
    """
    Generate a PDF career report and return as bytes.
    user: {fullName, email, profile: {skills, education, bio}}
    recommendations: list of recommendation dicts
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import cm
        from reportlab.lib import colors
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
            HRFlowable, KeepTogether
        )
        from reportlab.lib.enums import TA_CENTER, TA_LEFT

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=2 * cm,
            leftMargin=2 * cm,
            topMargin=2 * cm,
            bottomMargin=2 * cm,
        )

        styles = getSampleStyleSheet()
        PURPLE = colors.HexColor("#6366f1")
        LIGHT_PURPLE = colors.HexColor("#ede9fe")
        DARK = colors.HexColor("#1e1b4b")
        GRAY = colors.HexColor("#6b7280")

        title_style = ParagraphStyle("Title", parent=styles["Title"],
                                     textColor=PURPLE, fontSize=22, spaceAfter=4)
        subtitle_style = ParagraphStyle("Subtitle", parent=styles["Normal"],
                                        textColor=GRAY, fontSize=11, spaceAfter=12)
        section_style = ParagraphStyle("Section", parent=styles["Heading2"],
                                       textColor=DARK, fontSize=14, spaceBefore=16, spaceAfter=6)
        body_style = ParagraphStyle("Body", parent=styles["Normal"],
                                    fontSize=10, leading=14, textColor=DARK)
        career_title_style = ParagraphStyle("CareerTitle", parent=styles["Heading3"],
                                            textColor=PURPLE, fontSize=12, spaceBefore=8)

        story = []

        # ── Header ──────────────────────────────────────────────────────────
        story.append(Paragraph("TalentForge AI", title_style))
        story.append(Paragraph("AI-Powered Career Guidance Report", subtitle_style))
        story.append(HRFlowable(width="100%", thickness=2, color=PURPLE))
        story.append(Spacer(1, 0.4 * cm))

        # ── Student Profile ──────────────────────────────────────────────────
        profile = user.get("profile", {})
        story.append(Paragraph("Student Profile", section_style))

        profile_data = [
            ["Name", user.get("fullName", "N/A")],
            ["Email", user.get("email", "N/A")],
            ["Education", profile.get("education") or "Not specified"],
            ["Location", profile.get("location") or "Not specified"],
            ["Report Date", datetime.now().strftime("%B %d, %Y")],
        ]
        profile_table = Table(profile_data, colWidths=[4 * cm, 13 * cm])
        profile_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (0, -1), LIGHT_PURPLE),
            ("TEXTCOLOR", (0, 0), (0, -1), DARK),
            ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 10),
            ("ROWBACKGROUNDS", (0, 0), (-1, -1), [colors.white, colors.HexColor("#f9fafb")]),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e5e7eb")),
            ("PADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(profile_table)
        story.append(Spacer(1, 0.3 * cm))

        # ── Skills ───────────────────────────────────────────────────────────
        skills = profile.get("skills", [])
        if skills:
            story.append(Paragraph("Current Skills", section_style))
            skills_text = " • ".join(skills[:20])
            story.append(Paragraph(skills_text, body_style))
            story.append(Spacer(1, 0.3 * cm))

        # ── Career Recommendations ────────────────────────────────────────────
        story.append(Paragraph("Career Recommendations", section_style))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#e5e7eb")))

        for i, rec in enumerate(recommendations[:5], 1):
            block = []
            block.append(Paragraph(
                f"{i}. {rec.get('careerTitle', 'Unknown')} — {rec.get('matchPercentage', 0):.1f}% Match",
                career_title_style
            ))

            rec_skills = rec.get("recommendedSkills", [])
            if rec_skills:
                block.append(Paragraph(
                    f"<b>Key Skills:</b> {', '.join(rec_skills[:6])}",
                    body_style
                ))

            roadmap = rec.get("roadmapSteps", [])
            if roadmap:
                block.append(Paragraph("<b>Roadmap:</b>", body_style))
                for step in roadmap[:3]:
                    block.append(Paragraph(f"  • {step}", body_style))

            block.append(Spacer(1, 0.2 * cm))
            story.append(KeepTogether(block))

        # ── Footer ────────────────────────────────────────────────────────────
        story.append(Spacer(1, 1 * cm))
        story.append(HRFlowable(width="100%", thickness=1, color=PURPLE))
        story.append(Paragraph(
            "Generated by TalentForge AI — AI-Powered Career Guidance Platform © 2026",
            ParagraphStyle("Footer", parent=styles["Normal"],
                           fontSize=8, textColor=GRAY, alignment=TA_CENTER)
        ))

        doc.build(story)
        return buffer.getvalue()

    except Exception as exc:
        logger.error("PDF generation error: %s", exc)
        raise
