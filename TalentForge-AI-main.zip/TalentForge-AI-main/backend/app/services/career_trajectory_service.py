"""
Career Trajectory Simulation Service.

Monte Carlo simulation of career paths:
- Defined career progression graphs (Junior → Mid → Senior → Lead → Director)
- Probability-weighted transitions based on skill match + market demand
- Salary projections at each stage
- Multiple path generation (3-5 possible trajectories)

This is a unique differentiator — most career platforms give static recommendations.
TalentForge shows dynamic career evolution over time.
"""
import logging
import random
from typing import Optional

logger = logging.getLogger(__name__)

# ── Career Progression Graphs ────────────────────────────────────────────────
# Each career has defined stages with requirements and transitions.

CAREER_PROGRESSIONS = {
    "Data Scientist": {
        "stages": [
            {
                "title": "Junior Data Scientist",
                "level": 1,
                "years_exp": "0-2",
                "salary_range": {"min": 6, "max": 12},
                "key_skills": ["Python", "SQL", "Statistics", "Pandas"],
                "description": "Performs data analysis, builds basic ML models, and supports senior team members.",
            },
            {
                "title": "Data Scientist",
                "level": 2,
                "years_exp": "2-5",
                "salary_range": {"min": 12, "max": 25},
                "key_skills": ["Machine Learning", "Deep Learning", "Feature Engineering", "A/B Testing"],
                "description": "Independently designs and implements ML solutions, mentors juniors.",
            },
            {
                "title": "Senior Data Scientist",
                "level": 3,
                "years_exp": "5-8",
                "salary_range": {"min": 25, "max": 40},
                "key_skills": ["MLOps", "System Design", "Leadership", "Research"],
                "description": "Leads complex projects, defines data strategy, and publishes research.",
            },
            {
                "title": "Lead / Principal Data Scientist",
                "level": 4,
                "years_exp": "8-12",
                "salary_range": {"min": 40, "max": 65},
                "key_skills": ["Strategy", "Cross-functional Leadership", "Innovation", "Architecture"],
                "description": "Sets technical vision for data science org, drives innovation.",
            },
            {
                "title": "Head of Data Science / VP",
                "level": 5,
                "years_exp": "12+",
                "salary_range": {"min": 60, "max": 100},
                "key_skills": ["Executive Leadership", "Business Strategy", "P&L", "Board Presentations"],
                "description": "Leads entire data science division, reports to C-suite.",
            },
        ],
        "lateral_transitions": [
            {"to": "ML Engineer", "probability": 0.25, "at_level": 2, "reason": "Production ML focus"},
            {"to": "AI Engineer", "probability": 0.20, "at_level": 3, "reason": "LLM/GenAI specialization"},
            {"to": "Data Engineering", "probability": 0.15, "at_level": 2, "reason": "Pipeline & infrastructure focus"},
            {"to": "Product Manager (Data)", "probability": 0.10, "at_level": 3, "reason": "Business + technical bridge"},
        ],
    },
    "ML Engineer": {
        "stages": [
            {
                "title": "Junior ML Engineer",
                "level": 1,
                "years_exp": "0-2",
                "salary_range": {"min": 8, "max": 15},
                "key_skills": ["Python", "TensorFlow/PyTorch", "Docker", "Git"],
                "description": "Assists in model training pipelines, writes data processing code.",
            },
            {
                "title": "ML Engineer",
                "level": 2,
                "years_exp": "2-5",
                "salary_range": {"min": 15, "max": 30},
                "key_skills": ["MLOps", "Kubernetes", "Model Serving", "CI/CD"],
                "description": "Builds end-to-end ML pipelines, deploys models to production.",
            },
            {
                "title": "Senior ML Engineer",
                "level": 3,
                "years_exp": "5-8",
                "salary_range": {"min": 30, "max": 50},
                "key_skills": ["System Design", "Distributed Training", "Model Optimization", "Mentorship"],
                "description": "Architects ML systems, optimizes performance at scale.",
            },
            {
                "title": "Staff / Principal ML Engineer",
                "level": 4,
                "years_exp": "8-12",
                "salary_range": {"min": 50, "max": 80},
                "key_skills": ["Technical Strategy", "Cross-team Influence", "Innovation", "Research"],
                "description": "Defines ML platform strategy, influences company-wide technical decisions.",
            },
        ],
        "lateral_transitions": [
            {"to": "AI Engineer", "probability": 0.30, "at_level": 2, "reason": "LLM/GenAI application focus"},
            {"to": "Data Scientist", "probability": 0.15, "at_level": 2, "reason": "Research-focused career"},
            {"to": "DevOps Engineer", "probability": 0.10, "at_level": 2, "reason": "Infrastructure specialization"},
        ],
    },
    "Full Stack Developer": {
        "stages": [
            {
                "title": "Junior Full Stack Developer",
                "level": 1,
                "years_exp": "0-2",
                "salary_range": {"min": 4, "max": 10},
                "key_skills": ["JavaScript", "React", "Node.js", "HTML/CSS"],
                "description": "Builds features under guidance, learns the codebase.",
            },
            {
                "title": "Full Stack Developer",
                "level": 2,
                "years_exp": "2-5",
                "salary_range": {"min": 10, "max": 22},
                "key_skills": ["TypeScript", "System Design", "Databases", "Testing"],
                "description": "Independently delivers features, participates in code reviews.",
            },
            {
                "title": "Senior Full Stack Developer",
                "level": 3,
                "years_exp": "5-8",
                "salary_range": {"min": 22, "max": 40},
                "key_skills": ["Architecture", "Performance Optimization", "Mentorship", "DevOps"],
                "description": "Leads technical decisions, mentors team, owns critical systems.",
            },
            {
                "title": "Staff Engineer / Tech Lead",
                "level": 4,
                "years_exp": "8-12",
                "salary_range": {"min": 35, "max": 60},
                "key_skills": ["Technical Strategy", "Stakeholder Management", "Team Building"],
                "description": "Drives architecture across teams, manages technical roadmap.",
            },
            {
                "title": "Engineering Manager / Director",
                "level": 5,
                "years_exp": "12+",
                "salary_range": {"min": 50, "max": 90},
                "key_skills": ["People Management", "Strategic Planning", "Execution"],
                "description": "Leads engineering organization, responsible for delivery and team growth.",
            },
        ],
        "lateral_transitions": [
            {"to": "Backend Developer", "probability": 0.20, "at_level": 2, "reason": "Backend specialization"},
            {"to": "Frontend Developer", "probability": 0.15, "at_level": 2, "reason": "UI/UX focus"},
            {"to": "DevOps Engineer", "probability": 0.15, "at_level": 3, "reason": "Infrastructure focus"},
            {"to": "Product Manager", "probability": 0.10, "at_level": 3, "reason": "Business + technical bridge"},
        ],
    },
    "Cloud Engineer": {
        "stages": [
            {
                "title": "Junior Cloud Engineer",
                "level": 1,
                "years_exp": "0-2",
                "salary_range": {"min": 6, "max": 14},
                "key_skills": ["AWS/Azure Basics", "Linux", "Networking", "Docker"],
                "description": "Manages cloud resources, assists with infrastructure setup.",
            },
            {
                "title": "Cloud Engineer",
                "level": 2,
                "years_exp": "2-5",
                "salary_range": {"min": 14, "max": 28},
                "key_skills": ["Terraform", "Kubernetes", "CI/CD", "Security"],
                "description": "Designs and implements cloud architectures, automates deployments.",
            },
            {
                "title": "Senior Cloud Engineer",
                "level": 3,
                "years_exp": "5-8",
                "salary_range": {"min": 28, "max": 45},
                "key_skills": ["Multi-Cloud", "Cost Optimization", "Compliance", "Architecture"],
                "description": "Architects multi-cloud solutions, optimizes costs, ensures compliance.",
            },
            {
                "title": "Cloud Architect",
                "level": 4,
                "years_exp": "8-12",
                "salary_range": {"min": 45, "max": 80},
                "key_skills": ["Enterprise Architecture", "Strategy", "Vendor Management"],
                "description": "Defines cloud strategy for the organization, works with C-suite.",
            },
        ],
        "lateral_transitions": [
            {"to": "DevOps Engineer", "probability": 0.25, "at_level": 2, "reason": "Automation focus"},
            {"to": "Cybersecurity Analyst", "probability": 0.15, "at_level": 3, "reason": "Cloud security specialization"},
        ],
    },
    "DevOps Engineer": {
        "stages": [
            {
                "title": "Junior DevOps Engineer",
                "level": 1,
                "years_exp": "0-2",
                "salary_range": {"min": 5, "max": 12},
                "key_skills": ["Linux", "Git", "Docker", "CI/CD Basics"],
                "description": "Manages CI/CD pipelines, assists with deployments.",
            },
            {
                "title": "DevOps Engineer",
                "level": 2,
                "years_exp": "2-5",
                "salary_range": {"min": 12, "max": 25},
                "key_skills": ["Kubernetes", "Terraform", "Monitoring", "Ansible"],
                "description": "Automates infrastructure, manages container orchestration.",
            },
            {
                "title": "Senior DevOps / SRE",
                "level": 3,
                "years_exp": "5-8",
                "salary_range": {"min": 25, "max": 42},
                "key_skills": ["SRE Practices", "System Design", "Incident Management", "Capacity Planning"],
                "description": "Leads reliability initiatives, designs resilient systems.",
            },
            {
                "title": "Staff SRE / DevOps Architect",
                "level": 4,
                "years_exp": "8+",
                "salary_range": {"min": 40, "max": 65},
                "key_skills": ["Platform Engineering", "Technical Strategy", "Organizational Influence"],
                "description": "Defines platform and DevOps strategy across the organization.",
            },
        ],
        "lateral_transitions": [
            {"to": "Cloud Engineer", "probability": 0.25, "at_level": 2, "reason": "Cloud specialization"},
            {"to": "Backend Developer", "probability": 0.10, "at_level": 2, "reason": "Software development focus"},
        ],
    },
    "Cybersecurity Analyst": {
        "stages": [
            {
                "title": "Junior Security Analyst",
                "level": 1,
                "years_exp": "0-2",
                "salary_range": {"min": 5, "max": 12},
                "key_skills": ["Networking", "SIEM", "Linux", "Incident Monitoring"],
                "description": "Monitors security events, responds to basic incidents.",
            },
            {
                "title": "Cybersecurity Analyst",
                "level": 2,
                "years_exp": "2-5",
                "salary_range": {"min": 12, "max": 25},
                "key_skills": ["Penetration Testing", "Vulnerability Assessment", "Python", "Compliance"],
                "description": "Conducts security assessments, implements security controls.",
            },
            {
                "title": "Senior Security Engineer",
                "level": 3,
                "years_exp": "5-8",
                "salary_range": {"min": 25, "max": 42},
                "key_skills": ["Security Architecture", "Incident Response Lead", "Threat Modeling"],
                "description": "Designs security architecture, leads incident response.",
            },
            {
                "title": "Security Architect / CISO",
                "level": 4,
                "years_exp": "10+",
                "salary_range": {"min": 45, "max": 90},
                "key_skills": ["Enterprise Security Strategy", "Risk Management", "Board Reporting"],
                "description": "Responsible for organization's entire security posture.",
            },
        ],
        "lateral_transitions": [
            {"to": "Cloud Engineer", "probability": 0.15, "at_level": 2, "reason": "Cloud security focus"},
            {"to": "DevOps Engineer", "probability": 0.10, "at_level": 2, "reason": "DevSecOps specialization"},
        ],
    },
    "AI Engineer": {
        "stages": [
            {
                "title": "Junior AI Engineer",
                "level": 1,
                "years_exp": "0-2",
                "salary_range": {"min": 8, "max": 18},
                "key_skills": ["Python", "LLM APIs", "RAG Basics", "Prompt Engineering"],
                "description": "Builds AI features using LLM APIs, implements basic RAG pipelines.",
            },
            {
                "title": "AI Engineer",
                "level": 2,
                "years_exp": "2-4",
                "salary_range": {"min": 18, "max": 35},
                "key_skills": ["LangChain", "Vector Databases", "Fine-tuning", "Evaluation"],
                "description": "Designs and deploys AI applications, builds complex RAG systems.",
            },
            {
                "title": "Senior AI Engineer",
                "level": 3,
                "years_exp": "4-7",
                "salary_range": {"min": 35, "max": 60},
                "key_skills": ["AI Architecture", "Multi-agent Systems", "Model Selection", "Scale"],
                "description": "Architects AI systems at scale, makes technology decisions.",
            },
            {
                "title": "Staff AI Engineer / AI Architect",
                "level": 4,
                "years_exp": "7+",
                "salary_range": {"min": 55, "max": 100},
                "key_skills": ["AI Strategy", "Research", "Team Building", "Product Vision"],
                "description": "Defines AI strategy for the organization, leads AI initiatives.",
            },
        ],
        "lateral_transitions": [
            {"to": "ML Engineer", "probability": 0.20, "at_level": 2, "reason": "Model infrastructure focus"},
            {"to": "Data Scientist", "probability": 0.15, "at_level": 2, "reason": "Research-oriented path"},
        ],
    },
    "Backend Developer": {
        "stages": [
            {
                "title": "Junior Backend Developer",
                "level": 1,
                "years_exp": "0-2",
                "salary_range": {"min": 4, "max": 10},
                "key_skills": ["Python/Java/Node.js", "SQL", "REST APIs", "Git"],
                "description": "Writes backend code, builds APIs, fixes bugs.",
            },
            {
                "title": "Backend Developer",
                "level": 2,
                "years_exp": "2-5",
                "salary_range": {"min": 10, "max": 22},
                "key_skills": ["Microservices", "Docker", "Database Design", "Testing"],
                "description": "Designs and builds backend services, manages databases.",
            },
            {
                "title": "Senior Backend Developer",
                "level": 3,
                "years_exp": "5-8",
                "salary_range": {"min": 22, "max": 40},
                "key_skills": ["System Design", "Performance Optimization", "Architecture"],
                "description": "Architects backend systems, ensures scalability and reliability.",
            },
            {
                "title": "Staff Engineer / Architect",
                "level": 4,
                "years_exp": "8+",
                "salary_range": {"min": 35, "max": 60},
                "key_skills": ["Technical Strategy", "Distributed Systems", "Mentorship"],
                "description": "Leads technical architecture across the organization.",
            },
        ],
        "lateral_transitions": [
            {"to": "Full Stack Developer", "probability": 0.20, "at_level": 2, "reason": "Frontend expansion"},
            {"to": "DevOps Engineer", "probability": 0.15, "at_level": 3, "reason": "Infrastructure focus"},
            {"to": "ML Engineer", "probability": 0.10, "at_level": 2, "reason": "ML infrastructure path"},
        ],
    },
    "Frontend Developer": {
        "stages": [
            {
                "title": "Junior Frontend Developer",
                "level": 1,
                "years_exp": "0-2",
                "salary_range": {"min": 3, "max": 8},
                "key_skills": ["HTML/CSS", "JavaScript", "React", "Git"],
                "description": "Builds UI components, fixes styling issues.",
            },
            {
                "title": "Frontend Developer",
                "level": 2,
                "years_exp": "2-5",
                "salary_range": {"min": 8, "max": 20},
                "key_skills": ["TypeScript", "State Management", "Testing", "Performance"],
                "description": "Builds complex UIs, manages state, optimizes performance.",
            },
            {
                "title": "Senior Frontend Developer",
                "level": 3,
                "years_exp": "5-8",
                "salary_range": {"min": 20, "max": 38},
                "key_skills": ["Architecture", "Design Systems", "Accessibility", "Mentorship"],
                "description": "Leads frontend architecture, builds design systems.",
            },
            {
                "title": "Staff Frontend Engineer / UI Architect",
                "level": 4,
                "years_exp": "8+",
                "salary_range": {"min": 35, "max": 55},
                "key_skills": ["Technical Strategy", "Cross-platform", "Performance at Scale"],
                "description": "Defines frontend strategy and standards across organization.",
            },
        ],
        "lateral_transitions": [
            {"to": "Full Stack Developer", "probability": 0.30, "at_level": 2, "reason": "Backend expansion"},
            {"to": "UI/UX Designer", "probability": 0.10, "at_level": 2, "reason": "Design specialization"},
        ],
    },
    "Data Analyst": {
        "stages": [
            {
                "title": "Junior Data Analyst",
                "level": 1,
                "years_exp": "0-2",
                "salary_range": {"min": 3, "max": 8},
                "key_skills": ["SQL", "Excel", "Data Cleaning", "Basic Visualization"],
                "description": "Runs queries, creates reports, cleans datasets.",
            },
            {
                "title": "Data Analyst",
                "level": 2,
                "years_exp": "2-4",
                "salary_range": {"min": 8, "max": 16},
                "key_skills": ["Python/Pandas", "Tableau/Power BI", "Statistics", "Stakeholder Communication"],
                "description": "Conducts analysis independently, presents insights to business teams.",
            },
            {
                "title": "Senior Data Analyst",
                "level": 3,
                "years_exp": "4-7",
                "salary_range": {"min": 16, "max": 28},
                "key_skills": ["Advanced Analytics", "A/B Testing", "Predictive Modeling"],
                "description": "Leads analytics initiatives, mentors junior analysts.",
            },
            {
                "title": "Analytics Manager / Lead",
                "level": 4,
                "years_exp": "7+",
                "salary_range": {"min": 25, "max": 45},
                "key_skills": ["Team Management", "Strategy", "Business Acumen"],
                "description": "Manages analytics team, defines data-driven strategy.",
            },
        ],
        "lateral_transitions": [
            {"to": "Data Scientist", "probability": 0.35, "at_level": 2, "reason": "ML/DS career path — most common transition"},
            {"to": "Data Engineering", "probability": 0.15, "at_level": 2, "reason": "Pipeline engineering focus"},
            {"to": "Product Manager", "probability": 0.10, "at_level": 3, "reason": "Business + data bridge"},
        ],
    },
}


# ── Simulation Engine ────────────────────────────────────────────────────────

def simulate_career_trajectory(
    user_skills: list[str],
    target_career: str | None = None,
    num_paths: int = 3,
    horizon_years: int = 10,
) -> dict:
    """
    Monte Carlo simulation of career trajectories.

    Returns:
    {
        primaryCareer: str,
        currentLevel: int,
        trajectories: [
            {
                pathId: int,
                type: "vertical" | "lateral",
                probability: float,
                stages: [{title, level, yearsExp, salaryRange, keySkills, description}],
                projectedSalary5yr: float,
                projectedSalary10yr: float,
            }
        ],
        lateralOptions: [{to, probability, reason}],
        insights: [str],
    }
    """
    from .ml_service import _fuzzy_match_career

    # Determine the career to simulate
    if not target_career:
        from .hybrid_model import get_hybrid_recommendations
        recs = get_hybrid_recommendations(user_skills, top_n=1)
        target_career = recs[0]["career"] if recs else "Full Stack Developer"

    matched_career = _fuzzy_match_career(target_career)

    # Get career progression data
    career_data = CAREER_PROGRESSIONS.get(matched_career)
    if not career_data:
        # Find closest match
        for key in CAREER_PROGRESSIONS:
            if matched_career.lower() in key.lower() or key.lower() in matched_career.lower():
                career_data = CAREER_PROGRESSIONS[key]
                matched_career = key
                break

    if not career_data:
        career_data = CAREER_PROGRESSIONS.get("Full Stack Developer")
        matched_career = "Full Stack Developer"

    stages = career_data["stages"]
    lateral = career_data.get("lateral_transitions", [])

    # Determine current level based on skill match
    current_level = _estimate_current_level(user_skills, stages)

    # Generate trajectories
    trajectories = []

    # Path 1: Vertical progression (stay in same career)
    vertical_path = _generate_vertical_path(stages, current_level, horizon_years)
    trajectories.append({
        "pathId": 1,
        "type": "vertical",
        "label": f"Stay in {matched_career}",
        "probability": round(0.55 + random.uniform(-0.05, 0.05), 2),
        "stages": vertical_path,
        "projectedSalary5yr": _project_salary(stages, current_level, 5),
        "projectedSalary10yr": _project_salary(stages, current_level, 10),
    })

    # Path 2-N: Lateral transitions
    for i, trans in enumerate(lateral[:num_paths - 1]):
        lateral_career = trans["to"]
        lateral_data = CAREER_PROGRESSIONS.get(lateral_career)

        if lateral_data:
            lateral_path = _generate_lateral_path(
                stages, lateral_data["stages"], current_level, trans, horizon_years
            )
            trajectories.append({
                "pathId": i + 2,
                "type": "lateral",
                "label": f"Transition to {lateral_career}",
                "probability": round(trans["probability"] + random.uniform(-0.03, 0.03), 2),
                "transitionReason": trans["reason"],
                "stages": lateral_path,
                "projectedSalary5yr": _project_salary(
                    lateral_data["stages"], max(1, current_level - 1), 5
                ),
                "projectedSalary10yr": _project_salary(
                    lateral_data["stages"], max(1, current_level - 1), 10
                ),
            })

    # Generate insights
    insights = _generate_insights(user_skills, matched_career, stages, current_level, lateral)

    return {
        "primaryCareer": matched_career,
        "currentLevel": current_level,
        "currentStage": stages[current_level - 1]["title"] if current_level <= len(stages) else stages[-1]["title"],
        "trajectories": trajectories,
        "lateralOptions": [
            {"to": t["to"], "probability": t["probability"], "reason": t["reason"]}
            for t in lateral
        ],
        "insights": insights,
        "simulationParams": {
            "horizonYears": horizon_years,
            "numPaths": len(trajectories),
            "userSkillCount": len(user_skills),
        },
    }


def _estimate_current_level(user_skills: list[str], stages: list[dict]) -> int:
    """Estimate user's current career level based on skill match."""
    user_set = {s.strip().lower() for s in user_skills}
    best_level = 1

    for stage in stages:
        stage_skills = {s.strip().lower() for s in stage["key_skills"]}
        overlap = len(user_set & stage_skills)
        required = len(stage_skills)

        if required > 0 and overlap / required >= 0.5:
            best_level = stage["level"]

    return best_level


def _generate_vertical_path(
    stages: list[dict], current_level: int, horizon_years: int
) -> list[dict]:
    """Generate vertical progression path from current level."""
    path = []
    cumulative_years = 0

    for stage in stages:
        if stage["level"] < current_level:
            continue

        # Parse years range
        years_range = stage["years_exp"]
        if "+" in years_range:
            min_years = int(years_range.replace("+", ""))
            max_years = min_years + 5
        else:
            parts = years_range.split("-")
            min_years = int(parts[0])
            max_years = int(parts[1]) if len(parts) > 1 else min_years + 2

        entry_year = cumulative_years if stage["level"] == current_level else cumulative_years
        cumulative_years += max_years - min_years

        if entry_year > horizon_years:
            break

        path.append({
            **stage,
            "estimatedYear": entry_year,
            "salaryRange": stage["salary_range"],
        })

    return path


def _generate_lateral_path(
    current_stages: list[dict],
    lateral_stages: list[dict],
    current_level: int,
    transition: dict,
    horizon_years: int,
) -> list[dict]:
    """Generate a path that transitions laterally to another career."""
    path = []

    # Current career stages up to transition point
    transition_level = transition.get("at_level", current_level)
    for stage in current_stages:
        if stage["level"] < current_level:
            continue
        if stage["level"] > transition_level:
            break
        path.append({
            **stage,
            "estimatedYear": (stage["level"] - current_level) * 2,
            "salaryRange": stage["salary_range"],
        })

    # Transition point
    transition_year = (transition_level - current_level + 1) * 2
    start_level = max(1, transition_level - 1)  # Usually step back one level

    # Lateral career stages
    for stage in lateral_stages:
        if stage["level"] < start_level:
            continue
        year = transition_year + (stage["level"] - start_level) * 2
        if year > horizon_years:
            break
        path.append({
            **stage,
            "estimatedYear": year,
            "isLateralEntry": stage["level"] == start_level,
            "salaryRange": stage["salary_range"],
        })

    return path


def _project_salary(stages: list[dict], current_level: int, years: int) -> float:
    """Project salary after N years."""
    target_level = min(current_level + years // 3, len(stages))
    if target_level > len(stages):
        target_level = len(stages)
    target_stage = stages[target_level - 1]
    avg_salary = (target_stage["salary_range"]["min"] + target_stage["salary_range"]["max"]) / 2
    return round(avg_salary, 1)


def _generate_insights(
    user_skills: list[str],
    career: str,
    stages: list[dict],
    current_level: int,
    lateral: list[dict],
) -> list[str]:
    """Generate actionable career insights."""
    insights = []

    # Skill gap insight
    if current_level < len(stages):
        next_stage = stages[current_level]
        user_set = {s.strip().lower() for s in user_skills}
        next_skills = {s.strip().lower() for s in next_stage["key_skills"]}
        missing = next_skills - user_set
        if missing:
            insights.append(
                f"To reach {next_stage['title']}, focus on learning: {', '.join(list(missing)[:4])}."
            )

    # Salary insight
    if current_level <= len(stages):
        current_salary = stages[current_level - 1]["salary_range"]
        insights.append(
            f"Expected salary range at your level: ₹{current_salary['min']}-{current_salary['max']} LPA."
        )

    # Lateral transition insight
    if lateral:
        best_lateral = max(lateral, key=lambda x: x["probability"])
        insights.append(
            f"Most common lateral move: {best_lateral['to']} "
            f"({int(best_lateral['probability'] * 100)}% of professionals). "
            f"Reason: {best_lateral['reason']}."
        )

    # Level-specific insight
    if current_level == 1:
        insights.append(
            "Focus on building a strong portfolio with 3-5 projects. "
            "Contributions to open-source can accelerate career growth by 40%."
        )
    elif current_level == 2:
        insights.append(
            "This is the critical growth phase. Specializing deeply in one area "
            "while maintaining breadth will set you apart for senior roles."
        )
    elif current_level >= 3:
        insights.append(
            "At senior level, impact comes from mentoring, architecture decisions, "
            "and cross-functional influence more than individual contribution."
        )

    return insights


def get_career_progression_graph() -> dict:
    """Return the full career progression graph for visualization."""
    return {
        career: {
            "stages": [
                {
                    "title": s["title"],
                    "level": s["level"],
                    "yearsExp": s["years_exp"],
                    "salaryRange": s["salary_range"],
                }
                for s in data["stages"]
            ],
            "transitions": data.get("lateral_transitions", []),
        }
        for career, data in CAREER_PROGRESSIONS.items()
    }
