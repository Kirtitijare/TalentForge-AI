import re
import json
from app import create_app
from app.extensions import db
from app.models.recommendation import CareerRecommendation
from app.models.market_trend import MarketTrend

app = create_app()

def clean_title(title):
    if not title:
        return title
    # Clean leading/trailing asterisks, underscores, and whitespace
    cleaned = re.sub(r'^[\s*_#]+|[\s*_#]+$', '', title)
    return cleaned

with app.app_context():
    print("--- Cleaning MarketTrend job_title ---")
    trends = MarketTrend.query.all()
    cleaned_trends_count = 0
    for trend in trends:
        orig = trend.job_title
        cleaned = clean_title(orig)
        if orig != cleaned:
            print(f"Updating MarketTrend: '{orig}' -> '{cleaned}'")
            trend.job_title = cleaned
            cleaned_trends_count += 1
            
    print("--- Cleaning CareerRecommendation career_title ---")
    recs = CareerRecommendation.query.all()
    cleaned_recs_count = 0
    for rec in recs:
        orig = rec.career_title
        cleaned = clean_title(orig)
        if orig != cleaned:
            print(f"Updating CareerRecommendation: '{orig}' -> '{cleaned}'")
            rec.career_title = cleaned
            cleaned_recs_count += 1
            
        # Also clean description if it has **** in career title patterns
        if rec.description:
            orig_desc = rec.description
            # Replace markdown bold like **Cloud and AI Solutions Architect** or similar
            cleaned_desc = re.sub(r'\*\*+([^*]+)\*\*+', r'\1', orig_desc)
            # Remove leading **** or ** or * from lines
            cleaned_desc = re.sub(r'(?m)^[*_#\s]+([A-Za-z0-9])', r'\1', cleaned_desc)
            if orig_desc != cleaned_desc:
                print(f"Updating Description for {rec.id} to clean asterisks")
                rec.description = cleaned_desc
                cleaned_recs_count += 1
                
    if cleaned_trends_count > 0 or cleaned_recs_count > 0:
        db.session.commit()
        print(f"Committed changes. Cleaned {cleaned_trends_count} trends and {cleaned_recs_count} recommendations.")
    else:
        print("No matches found requiring clean up.")
