# TalentForge AI — Complete Project Documentation

> Full module-by-module breakdown: tech stack, ML models, implementation details, API endpoints, and data flow.

---

## Tech Stack Overview

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite, Tailwind CSS, React Router, Zustand, Axios |
| Backend | Python 3.11, Flask 3.1, Flask-SQLAlchemy, Flask-Migrate, Flask-JWT-Extended |
| Database | PostgreSQL 13 (local), Supabase (cloud) + pgvector extension |
| AI / LLM | Groq API — `llama-3.1-8b-instant` model via direct httpx calls |
| ML Models | scikit-learn TF-IDF + Cosine Similarity, SVD (Singular Value Decomposition), NumPy NCF |
| NLP | spaCy `en_core_web_sm` + PhraseMatcher for skill extraction |
| PDF Parse | pdfplumber (resume text extraction) |
| PDF Generate | ReportLab (career report generation) |
| Auth | JWT (access + refresh tokens), bcrypt password hashing |
| Email | Flask-Mail via Gmail SMTP (OTP delivery) |
| File Storage | Local filesystem (dev), AWS S3 (production) |
| Deployment | Docker + docker-compose, Gunicorn WSGI server |

---

## Module 1 — Authentication System

### What it does
Full user auth flow: register → OTP email verify → login → JWT tokens → forgot/reset password.

### API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Create account, send OTP email |
| POST | `/api/auth/verify-otp` | Verify email with 6-digit OTP |
| POST | `/api/auth/login` | Login, returns access + refresh JWT |
| POST | `/api/auth/refresh` | Get new access token using refresh token |
| POST | `/api/auth/forgot-password` | Send password reset OTP |
| POST | `/api/auth/reset-password` | Reset password with OTP |
| GET | `/api/auth/me` | Get current user profile |

### Implementation Details
- **Password hashing**: `bcrypt` with salt rounds (via `bcrypt` library)
- **Password validation**: Regex enforces min 8 chars, uppercase, lowercase, digit, special char (`@$!%*?&`)
- **OTP**: 6-digit random code, stored in `otp_verifications` table, expires in 10 min (registration) / 15 min (reset)
- **JWT**: Access token (15 min TTL), Refresh token (7 days TTL), stored in `Authorization: Bearer` header
- **Security**: User enumeration protection on forgot-password (always returns success)
- **Roles**: `user` (default) and `admin`

### Database Tables Used
- `users` — stores user profile, hashed password, verification status
- `otp_verifications` — stores OTP codes with expiry and type (`registration` / `password_reset`)

---

## Module 2 — Career Recommender

### What it does
Generates top-5 personalized career recommendations using a 3-layer hybrid ML engine. Users can rate recommendations which triggers live SVD retraining.

### API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/career/recommend` | Generate hybrid recommendations |
| GET | `/api/career/recommendations` | List saved recommendations |
| POST | `/api/career/feedback` | Submit star rating (1–5), triggers SVD retrain |
| DELETE | `/api/career/recommendations/<id>` | Soft-delete a recommendation |

### ML Models Used

#### Layer 1 — Content-Based Filtering (TF-IDF)
- **Model**: `sklearn.feature_extraction.text.TfidfVectorizer` + `cosine_similarity`
- **How it works**: Each career's required skills are treated as a "document". User's skills are vectorized the same way. Cosine similarity is computed between user vector and each career vector.
- **Corpus**: 10 careers × 10–15 skills each (Data Scientist, ML Engineer, Full Stack, Cloud, DevOps, Cybersecurity, Backend, Frontend, Data Analyst, AI Engineer)
- **Score adjustment**: Raw cosine score + 0.3 baseline, clamped to [0.0, 1.0]
- **Output**: `content_score` per career

#### Layer 2 — Collaborative Filtering (SVD + NumPy NCF)
- **Model**: SVD (Singular Value Decomposition) via `numpy.linalg.svd` on a user-career rating matrix
- **Also uses**: NumPy-based Neural Collaborative Filtering (NCF) approximation
- **How it works**: Builds a matrix of user ratings (1–5 stars) for careers. SVD decomposes it into latent factors. Dot product of user and career latent vectors predicts affinity.
- **Live retraining**: Every time a user submits a rating via `/api/career/feedback`, `train_svd_model()` is called immediately — the model updates in-memory
- **Cold start**: Falls back to content-based score when no ratings exist
- **Output**: `cf_score` per career

#### Layer 3 — Market Demand Score
- **Source**: `market_trends` table (seeded with 2026 demand data)
- **How it works**: Each career has a `demand_score` (0–100) from the market trends dataset, normalized to 0.0–1.0
- **Output**: `demand_score` weight in final blend

#### Final Score Formula
```
final_score = (content_score × 0.5) + (cf_score × 0.3) + (demand_score × 0.2)
match_percentage = final_score × 100
```

#### AI Description (Groq LLM)
- **Model**: `llama-3.1-8b-instant` via Groq API
- **Used for**: Generating the narrative description for the top-1 recommendation only
- **Prompt**: Structured prompt with user interests, skills, background, and target career title
- **Retry logic**: 3 retries with exponential backoff on 429/5xx errors

### Database Tables Used
- `users` — skills, interests, education (input to ML)
- `career_recommendations` — stores top-5 results with all scores
- `career_ratings` — user star ratings, used for SVD training data
- `market_trends` — demand scores for market weighting

---

## Module 3 — Resume Analyzer

### What it does
Accepts a PDF resume upload, extracts text, runs dual AI analysis (spaCy local + Groq cloud), and returns structured data: skills, experience, education, certifications, and a full AI review.

### API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/resume/analyze` | Upload PDF, returns analysis + parsed data |
| GET | `/api/resume/preview/<filename>` | Serve uploaded PDF for browser preview |

### Implementation Details

#### Step 1 — PDF Text Extraction
- **Library**: `pdfplumber`
- **How**: Opens PDF page by page, calls `page.extract_text()`, joins all pages
- **Limitation**: Only works on text-based PDFs (not scanned images)

#### Step 2 — Parallel AI Processing (ThreadPoolExecutor, 2 workers)
Two Groq API calls run simultaneously:

**Call A — Resume Analysis** (`analyze_resume`)
- Returns markdown-formatted review with: Overall Assessment, Key Strengths, Areas for Improvement, ATS Optimization tips, Career Fit Analysis, Action Items

**Call B — Structured Parsing** (`parse_resume_structured`)
- Returns JSON with: `skills[]`, `certifications[]`, `projects[]`, `experience[]`, `education[]`, `summary`
- Uses `temperature=0.3` for deterministic JSON output
- Regex extracts JSON block from LLM response

#### Step 3 — spaCy Skill Extraction (local, no API)
- **Model**: `spacy en_core_web_sm` + `PhraseMatcher`
- **Vocabulary**: 100+ skills (Python, React, Docker, Kubernetes, LLMs, etc.)
- **How**: Lowercases resume text, runs PhraseMatcher against skill vocabulary, returns matched skills
- **Fallback**: If spaCy model not loaded, uses regex word-boundary matching

#### Step 4 — Skill Merge
- Combines Groq-parsed skills + spaCy-extracted skills into a deduplicated set
- Auto-updates user's profile skills in the `users` table

#### Step 5 — Profile Save
- Saves full analysis JSON to `users.resume_data` column for later retrieval

### Database Tables Used
- `users` — skills updated, resume_data saved

---

## Module 4 — Skill Gap Analyzer

### What it does
Compares user's current skills against the required skills for a target career and returns a gap report with match percentage.

### API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/skill-gap/` | Auto-analyze vs user's first recommendation |
| POST | `/api/skill-gap/analyze` | Analyze gap for a specific target career |
| GET | `/api/skill-gap/careers` | List all supported career targets |

### Implementation Details
- **No ML model** — pure set comparison
- **Career skill map**: Hardcoded dictionary of 10 careers × 10 required skills
- **Fuzzy matching**: Uses `difflib.SequenceMatcher` to match user-typed career names to the closest key in the map (e.g. "data science" → "Data Scientist")
- **Output**: `matchPercentage`, `matchedSkills[]`, `missingSkills[]`, `requiredSkills[]`
- **Default target**: If user has no recommendations yet, defaults to "Data Scientist"

---

## Module 5 — Learning Path Generator

### What it does
Generates a personalized month-by-month study plan for a target career, combining content-based recommendations, AI-generated learning path, certifications list, and collaborative filtering results.

### API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/learning-path/careers` | List supported careers |
| POST | `/api/learning-path/generate` | Generate full learning path |

### Implementation Details

#### 4 Parallel AI Calls (ThreadPoolExecutor, 4 workers)

| Call | Function | What it returns |
|---|---|---|
| Content-based | `get_content_based_recommendation()` | TF-IDF match scores vs all careers (no API, local) |
| Learning path | `get_learning_path()` | Month-by-month plan with course links (Groq LLM) |
| Certifications | `get_recommended_certifications()` | Top 5 certs with provider, cost, difficulty (Groq LLM) |
| Hybrid rec | `get_hybrid_recommendation()` | Blended content + collaborative narrative (Groq LLM) |

#### Collaborative Filtering (for hybrid context)
- Fetches all other users from DB
- Builds skill vectors for each peer
- Computes cosine similarity between current user and each peer
- Collects careers recommended to similar peers (similarity ≥ 0.15)
- Passes top peer-chosen careers as context to the hybrid Groq prompt

#### Learning Path Prompt Engineering
- Requests `MONTH_1` through `MONTH_N` structured format
- Asks for real clickable markdown URLs (Coursera search, Udemy search, YouTube, edX)
- Includes: Key Topics, Recommended Resources, Hands-on Milestone Project per month
- `max_tokens=3000` to allow full multi-month plans

---

## Module 6 — AI Mentor Chat

### What it does
A persistent conversational AI career mentor. Uses RAG (Retrieval-Augmented Generation) to ground responses in career knowledge. Chat history is stored in PostgreSQL per user.

### API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/chat/history` | Load chat history |
| POST | `/api/chat/send` | Send message, get AI response |
| DELETE | `/api/chat/clear` | Clear chat history |

### Implementation Details

#### RAG Pipeline
- **Service**: `rag_service.get_chat_context()`
- **How**: Retrieves relevant career knowledge (market trends, skill data, career paths) based on the user's message and profile
- **Context injection**: RAG context is injected into the system prompt before the LLM call

#### Chat with Mentor (RAG-augmented)
- **Model**: `llama-3.1-8b-instant` via Groq
- **System prompt includes**:
  - Role definition (expert AI career mentor)
  - RAG career knowledge context
  - User profile (skills, interests, education)
  - Rules: use knowledge base, include salary/cert data, be realistic
- **History**: Last 20 exchanges (40 messages) kept in context window
- **Storage**: Messages stored as JSON array in `chat_sessions.messages` column
- **History limit**: Capped at 40 messages to prevent unbounded DB growth

### Database Tables Used
- `chat_sessions` — one row per user, `messages` column stores full conversation as JSON array

---

## Module 7 — Market Trends

### What it does
Displays real-time (seeded) 2026 job market data: demand scores, salary data, growth rates, trending roles, and skill demand rankings.

### API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/market-trends/` | All trends sorted by demand score |
| GET | `/api/market-trends/skills` | Top N skills by frequency |
| GET | `/api/market-trends/skills/demand` | Skills with demand scores |
| GET | `/api/market-trends/industry/<name>` | Filter by industry |
| GET | `/api/market-trends/public` | Public endpoint (no auth) |

### Implementation Details
- **Data source**: Static 2026 dataset seeded into `market_trends` table on first app start
- **12 career roles** with: demand score (0–100), avg salary (LPA), growth rate (%), trending flag, industry, top skills
- **Skill demand scores**: Computed by averaging demand scores of all careers that require each skill
- **Seeding**: `seed_market_trends()` called in `run.py` — only seeds if table is empty

### Database Tables Used
- `market_trends` — all career market data

---

## Module 8 — Collaborative Filtering (Peer Insights)

### What it does
Shows careers chosen by users with similar skill profiles using cosine similarity collaborative filtering.

### API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/collaborative/` | Get peer-based career suggestions |

### Implementation Details
- **Algorithm**: Cosine similarity on binary skill vectors
- **Skill vocabulary**: 60-item fixed vocabulary (Python, React, Docker, AWS, etc.)
- **Vector building**: Each user's skills mapped to a binary vector over the vocabulary
- **Similarity threshold**: Only peers with similarity ≥ 0.15 are considered
- **Output**: Careers sorted by weighted similarity score, with common skills and peer count
- **Fallback**: If no peers found, returns 5 hardcoded popular careers with mock scores

### Math
```
user_vector = [1 if skill in user_skills else 0 for skill in VOCABULARY]
similarity = dot(vec_a, vec_b) / (norm(vec_a) × norm(vec_b))
career_score = sum(similarity for each peer who chose career) / peer_count
```

---

## Module 9 — Profile Manager

### What it does
View and update user profile: bio, education, skills, interests, location, phone number.

### API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/profile/` | Get full profile |
| PUT | `/api/profile/` | Update profile fields |
| POST | `/api/profile/skills/add` | Merge new skills into profile |

### Implementation Details
- Skills and interests accept both comma-separated strings and arrays
- Skill merging is case-insensitive deduplication
- All fields are optional in PUT — only provided fields are updated

---

## Module 10 — Career Report (PDF Download)

### What it does
Generates and streams a branded PDF career guidance report for the user.

### API Endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/report/download` | Download PDF report |

### Implementation Details
- **Library**: `ReportLab`
- **Content**: User profile table, current skills, top-5 career recommendations with match %, key skills, roadmap steps
- **Styling**: TalentForge purple brand color (`#6366f1`), A4 page, professional table layout
- **Delivery**: Streamed as `application/pdf` with `Content-Disposition: attachment`

---

## Module 11 — Admin Panel

### What it does
Full platform management: user management, career role CRUD, skill taxonomy CRUD, recommendation monitoring, SVD model retraining, and analytics dashboard.

### API Endpoints (all require admin JWT)
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/admin/dashboard` | Platform stats + SVD status + registration timeline |
| GET | `/api/admin/users` | Paginated user list with search/filter |
| GET | `/api/admin/users/<id>/profile` | Full user profile with recs and ratings |
| DELETE | `/api/admin/users/<id>` | Soft-delete user |
| PATCH | `/api/admin/users/<id>/promote` | Promote to admin |
| PATCH | `/api/admin/users/<id>/demote` | Demote to user |
| GET/POST | `/api/admin/careers` | List / create career roles |
| PUT/DELETE | `/api/admin/careers/<id>` | Update / delete career role |
| GET/POST | `/api/admin/skills` | List / create skill taxonomy entries |
| PUT/DELETE | `/api/admin/skills/<id>` | Update / delete skill |
| POST | `/api/admin/skills/bulk` | Bulk import skills (JSON or CSV) |
| GET | `/api/admin/recommendations` | All recommendations with user info |
| GET | `/api/admin/ratings` | All ratings with user info |
| GET | `/api/admin/monitor-stats` | Avg ratings per career, synthetic vs real ratio |
| POST | `/api/admin/retrain` | Manually trigger SVD retraining |

### Implementation Details
- **Auth guard**: `@admin_required` decorator checks JWT claims for `role == "admin"`
- **Career role updates**: If `requiredSkills` changes, all existing recommendations for that career are automatically soft-deleted (invalidated)
- **SVD retrain**: Exposed as manual endpoint + auto-triggered on every user rating
- **Dashboard stats**: Total users, verified users, top careers by recommendation count, top skills across all users, 7-day registration timeline

---

## Database Schema Summary

| Table | Key Columns |
|---|---|
| `users` | id (UUID), full_name, email, password_hash, skills (TEXT[]), interests (TEXT[]), skill_embedding (vector 384), role, is_email_verified, is_deleted |
| `otp_verifications` | id, email, code, type, expiry_time, is_used |
| `career_recommendations` | id (UUID), user_id (FK), career_title, match_percentage, content_score, cf_score, final_score, extra_data (JSON), is_deleted |
| `career_ratings` | id, user_id, career_slug, rating (1.0–5.0), source (user/synthetic) |
| `market_trends` | id, job_title, slug, category, industry, demand_score, average_salary_lpa, growth_rate, is_trending, required_skills (TEXT[]), top_skills_required (TEXT[]) |
| `chat_sessions` | id (UUID), user_id (FK), messages (JSON array) |
| `skill_taxonomy` | id, skill_name, category, aliases (TEXT[]), learning_url |

---

## AI / ML Models Summary

| Module | Model | Type | Library |
|---|---|---|---|
| Career Recommender | TF-IDF + Cosine Similarity | Content-Based Filtering | scikit-learn |
| Career Recommender | SVD (Singular Value Decomposition) | Collaborative Filtering | numpy.linalg.svd |
| Career Recommender | NCF (Neural Collaborative Filtering) | Collaborative Filtering | NumPy |
| Career Recommender | llama-3.1-8b-instant | LLM (description generation) | Groq API |
| Resume Analyzer | llama-3.1-8b-instant | LLM (analysis + parsing) | Groq API |
| Resume Analyzer | spaCy en_core_web_sm + PhraseMatcher | NLP (skill extraction) | spaCy |
| Learning Path | llama-3.1-8b-instant | LLM (path + certs + hybrid) | Groq API |
| AI Mentor Chat | llama-3.1-8b-instant + RAG | LLM + Retrieval | Groq API |
| Collaborative | Cosine Similarity on binary vectors | Collaborative Filtering | NumPy |
| Skill Gap | Fuzzy string matching | Rule-based | difflib |

---

## Groq API Configuration

- **Base URL**: `https://api.groq.com/openai/v1/chat/completions`
- **Model**: `llama-3.1-8b-instant`
- **Timeout**: 60 seconds per request
- **Retry policy**: 3 attempts, exponential backoff (1s → 2s → 4s) on 429/500/502/503/504
- **Max tokens**: 1024–3000 depending on endpoint
- **Temperature**: 0.3 for structured JSON outputs, 0.7 for conversational/narrative outputs

---

## Frontend Pages → Backend Module Mapping

| Page | Route | Backend Module |
|---|---|---|
| Login / Register | `/login`, `/register` | Auth |
| Forgot / Reset Password | `/forgot-password`, `/reset-password` | Auth |
| Dashboard | `/dashboard` | Career Recommender (list) |
| Career Recommendation | `/career` | Career Recommender |
| Resume Analyzer | `/resume` | Resume Analyzer |
| Skill Gap | `/skill-gap` | Skill Gap Analyzer |
| Learning Path | `/learning-path` | Learning Path Generator |
| Market Trends | `/market-trends` | Market Trends |
| AI Mentor | `/chat` | AI Mentor Chat |
| Peer Insights | `/collaborative` | Collaborative Filtering |
| Profile | `/profile` | Profile Manager |
| Admin | `/admin` | Admin Panel |
