import api from "./client";

// Career
export const getCareerRecommendation = (data) => api.post("/career/recommend", data);
export const listRecommendations = () => api.get("/career/recommendations");
export const deleteRecommendation = (id) => api.delete(`/career/recommendations/${id}`);
export const submitCareerFeedback = (data) => api.post("/career/feedback", data);

// Resume
export const analyzeResume = (formData) =>
  api.post("/resume/analyze", formData, { headers: { "Content-Type": "multipart/form-data" } });
export const getResumePreviewUrl = (fileName) => `/api/resume/preview/${fileName}`;

// Skill Gap
export const getSkillGap = () => api.get("/skill-gap/");
export const analyzeSkillGap = (data) => api.post("/skill-gap/analyze", data);
export const listSkillGapCareers = () => api.get("/skill-gap/careers");

// Learning Path
export const generateLearningPath = (data) => api.post("/learning-path/generate", data);
export const listLearningPathCareers = () => api.get("/learning-path/careers");

// Market Trends
export const getMarketTrends = () => api.get("/market-trends/");
export const getTopSkills = (limit = 12) => api.get(`/market-trends/skills?limit=${limit}`);
export const getTrendsByIndustry = (industry) => api.get(`/market-trends/industry/${industry}`);
export const getSkillDemandScores = () => api.get("/market-trends/skills/demand");

// Career Trajectory Simulation
export const simulateCareerTrajectory = (data) => api.post("/career-trajectory/simulate", data);
export const getCareerProgressionGraph = () => api.get("/career-trajectory/graph");

// Skill Synergy Analysis
export const getSkillSynergies = () => api.get("/skill-synergy/");
export const getTopSkillCombinations = () => api.get("/skill-synergy/top");


// Chat
export const getChatHistory = () => api.get("/chat/history");
export const sendChatMessage = (data) => api.post("/chat/send", data);
export const clearChatHistory = () => api.delete("/chat/clear");

// Collaborative
export const getCollaborativeRecs = () => api.get("/collaborative/");

// Profile
export const getProfile = () => api.get("/profile/");
export const updateProfile = (data) => api.put("/profile/", data);
export const addSkills = (data) => api.post("/profile/skills/add", data);

// Report
export const downloadReport = () =>
  api.get("/report/download", { responseType: "blob" });

// Admin
export const getAdminDashboard = () => api.get("/admin/dashboard");
export const listAdminUsers = (params) => api.get("/admin/users", { params });
export const getAdminUserProfile = (id) => api.get(`/admin/users/${id}/profile`);
export const deleteUser = (id) => api.delete(`/admin/users/${id}`);
export const promoteUser = (id) => api.patch(`/admin/users/${id}/promote`);
export const demoteUser = (id) => api.patch(`/admin/users/${id}/demote`);

// Admin Careers CRUD
export const listAdminCareers = (params) => api.get("/admin/careers", { params });
export const createAdminCareer = (data) => api.post("/admin/careers", data);
export const updateAdminCareer = (id, data) => api.put(`/admin/careers/${id}`, data);
export const deleteAdminCareer = (id) => api.delete(`/admin/careers/${id}`);
export const retrainSvdModel = () => api.post("/admin/retrain");

// Admin Skill Taxonomy CRUD
export const listAdminSkills = (params) => api.get("/admin/skills", { params });
export const createAdminSkill = (data) => api.post("/admin/skills", data);
export const updateAdminSkill = (id, data) => api.put(`/admin/skills/${id}`, data);
export const deleteAdminSkill = (id) => api.delete(`/admin/skills/${id}`);
export const bulkImportSkills = (data) => api.post("/admin/skills/bulk", data);

// Admin Ratings & Recommendations Monitor
export const listAdminRecs = (params) => api.get("/admin/recommendations", { params });
export const listAdminRatings = (params) => api.get("/admin/ratings", { params });
export const getAdminMonitorStats = () => api.get("/admin/monitor-stats");

