import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useAuthStore } from "./store/authStore";

// Layouts
import PublicLayout from "./components/layouts/PublicLayout";
import AppLayout from "./components/layouts/AppLayout";

// Public pages
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import VerifyOtp from "./pages/VerifyOtp";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";

// Protected pages
import Dashboard from "./pages/Dashboard";
import CareerRecommendation from "./pages/CareerRecommendation";
import ResumeAnalyzer from "./pages/ResumeAnalyzer";
import SkillGap from "./pages/SkillGap";
import LearningPath from "./pages/LearningPath";
import MarketTrends from "./pages/MarketTrends";
import Chat from "./pages/Chat";
import Collaborative from "./pages/Collaborative";
import Profile from "./pages/Profile";
import Admin from "./pages/Admin";
import CareerTrajectory from "./pages/CareerTrajectory";
import SkillSynergy from "./pages/SkillSynergy";

function ProtectedRoute({ children, adminOnly = false }) {
  const { isAuthenticated, user } = useAuthStore();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (adminOnly && user?.role !== "admin") return <Navigate to="/dashboard" replace />;
  return children;
}

function UserRoute({ children }) {
  const { isAuthenticated, user } = useAuthStore();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (user?.role === "admin") return <Navigate to="/admin" replace />;
  return children;
}

function GuestRoute({ children }) {
  const { isAuthenticated, user } = useAuthStore();
  if (isAuthenticated) {
    if (user?.role === "admin") return <Navigate to="/admin" replace />;
    return <Navigate to="/dashboard" replace />;
  }
  return children;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<GuestRoute><Login /></GuestRoute>} />
          <Route path="/register" element={<GuestRoute><Register /></GuestRoute>} />
          <Route path="/verify-otp" element={<VerifyOtp />} />
          <Route path="/forgot-password" element={<GuestRoute><ForgotPassword /></GuestRoute>} />
          <Route path="/reset-password" element={<GuestRoute><ResetPassword /></GuestRoute>} />
        </Route>

        {/* Protected */}
        <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
          <Route path="/dashboard" element={<UserRoute><Dashboard /></UserRoute>} />
          <Route path="/career" element={<UserRoute><CareerRecommendation /></UserRoute>} />
          <Route path="/resume" element={<UserRoute><Navigate to="/career?tab=resume" replace /></UserRoute>} />
          <Route path="/skill-gap" element={<UserRoute><SkillGap /></UserRoute>} />
          <Route path="/learning-path" element={<UserRoute><LearningPath /></UserRoute>} />
          <Route path="/market-trends" element={<UserRoute><MarketTrends /></UserRoute>} />
          <Route path="/career-trajectory" element={<UserRoute><CareerTrajectory /></UserRoute>} />
          <Route path="/skill-synergy" element={<UserRoute><SkillSynergy /></UserRoute>} />
          <Route path="/chat" element={<UserRoute><Chat /></UserRoute>} />
          <Route path="/collaborative" element={<UserRoute><Collaborative /></UserRoute>} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/admin" element={
            <ProtectedRoute adminOnly><Admin /></ProtectedRoute>
          } />
        </Route>


        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
