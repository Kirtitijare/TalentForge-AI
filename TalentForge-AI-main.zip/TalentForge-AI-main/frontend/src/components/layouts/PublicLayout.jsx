import { Outlet, Link } from "react-router-dom";
import { Zap } from "lucide-react";

export default function PublicLayout() {
  return (
    <div className="min-h-screen flex flex-col">
      <nav className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 text-primary-600 font-bold text-xl">
            <Zap className="w-6 h-6" />
            TalentForge AI
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/login" className="text-sm text-gray-600 hover:text-primary-600 font-medium">
              Sign In
            </Link>
            <Link to="/register" className="btn-primary text-sm">
              Get Started
            </Link>
          </div>
        </div>
      </nav>
      <main className="flex-1">
        <Outlet />
      </main>
      <footer className="bg-gray-900 text-gray-400 text-center py-6 text-sm">
        © 2026 TalentForge AI — AI-Powered Career Guidance
      </footer>
    </div>
  );
}
