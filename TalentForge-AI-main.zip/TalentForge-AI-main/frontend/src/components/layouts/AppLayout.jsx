import { Outlet, Link, useNavigate, useLocation } from "react-router-dom";
import { useAuthStore } from "../../store/authStore";
import {
  Zap, LayoutDashboard, Briefcase, FileText, Target,
  Map, TrendingUp, MessageCircle, Users, User,
  ShieldCheck, LogOut, Menu, X, GitFork, Layers,
  BarChart3, Database
} from "lucide-react";
import { useState } from "react";
import clsx from "clsx";
import { useQueryClient } from "@tanstack/react-query";


const USER_NAV_ITEMS = [
  { to: "/dashboard",      label: "Dashboard",       icon: LayoutDashboard },
  { to: "/career",         label: "Career Rec",      icon: Briefcase },
  { to: "/skill-gap",      label: "Skill Gap",       icon: Target },
  { to: "/learning-path",  label: "Learning Path",   icon: Map },
  { to: "/market-trends",  label: "Market Trends",   icon: TrendingUp },
  { to: "/career-trajectory", label: "Career Paths", icon: GitFork },
  { to: "/skill-synergy",     label: "Skill Synergy", icon: Layers },
  { to: "/chat",           label: "AI Mentor",       icon: MessageCircle },
  { to: "/collaborative",  label: "Peer Insights",   icon: Users },
  { to: "/profile",        label: "Profile",         icon: User },
];

const ADMIN_NAV_ITEMS = [
  { to: "/admin?tab=dashboard", label: "Dashboard Overview", icon: BarChart3 },
  { to: "/admin?tab=careers",   label: "Careers Manager",   icon: Briefcase },
  { to: "/admin?tab=skills",    label: "Skill Taxonomy",    icon: Layers },
  { to: "/admin?tab=users",     label: "User Management",   icon: Users },
  { to: "/admin?tab=monitor",   label: "Monitor & ML Model", icon: Database },
  { to: "/profile",             label: "Profile",           icon: User },
];

export default function AppLayout() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const queryClient = useQueryClient();

  const handleLogout = () => {
    queryClient.clear();
    logout();
    navigate("/login");
  };

  const navItems = user?.role === "admin" ? ADMIN_NAV_ITEMS : USER_NAV_ITEMS;

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      {/* Sidebar */}
      <aside className={clsx(
        "fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 flex flex-col",
        "transform transition-transform duration-200 ease-in-out",
        "lg:relative lg:translate-x-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Logo */}
        <div className="flex items-center gap-2 px-6 py-5 border-b border-gray-100">
          <Zap className="w-6 h-6 text-primary-600" />
          <span className="font-bold text-lg text-primary-600">TalentForge AI</span>
          <button
            className="ml-auto lg:hidden text-gray-400 hover:text-gray-600"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-4 px-3">
          {navItems.map(({ to, label, icon: Icon }) => {
            const isActive = to.includes("?")
              ? location.pathname + location.search === to
              : location.pathname === to;
            return (
              <Link
                key={to}
                to={to}
                onClick={() => setSidebarOpen(false)}
                className={clsx(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium mb-1 transition-colors",
                  isActive
                    ? "bg-primary-50 text-primary-700 font-semibold"
                    : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                )}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                {label}
              </Link>
            );
          })}
        </nav>

        {/* User + Logout */}
        <div className="border-t border-gray-100 p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-semibold text-sm">
              {user?.fullName?.[0]?.toUpperCase() || "U"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{user?.fullName}</p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 w-full px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar (mobile) */}
        <header className="lg:hidden bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3">
          <button onClick={() => setSidebarOpen(true)} className="text-gray-500">
            <Menu className="w-5 h-5" />
          </button>
          <span className="font-semibold text-primary-600">TalentForge AI</span>
        </header>

        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
