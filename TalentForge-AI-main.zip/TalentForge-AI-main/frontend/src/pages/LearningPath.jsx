import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { generateLearningPath, listLearningPathCareers } from "../api/index";
import ReactMarkdown from "react-markdown";
import toast from "react-hot-toast";
import { Map, Loader2, BookOpen, Award, Users, Sparkles } from "lucide-react";
import clsx from "clsx";

const TABS = [
  { key: "learningPath",   label: "6-Month Path",    icon: BookOpen },
  { key: "certifications", label: "Certifications",  icon: Award },
  { key: "contentBased",   label: "Content-Based",   icon: Sparkles },
  { key: "hybridRec",      label: "Hybrid Rec",      icon: Users },
];

const cleanTitle = (title) => {
  if (!title) return "";
  return title.replace(/^[\s*_#]+|[\s*_#]+$/g, "");
};

export default function LearningPath() {
  const [selectedCareer, setSelectedCareer] = useState("");
  const [result, setResult] = useState(null);
  const [activeTab, setActiveTab] = useState("learningPath");

  const { data: careers = [] } = useQuery({
    queryKey: ["learningPathCareers"],
    queryFn: () => listLearningPathCareers().then((r) => r.data.data.careers),
  });

  const mutation = useMutation({
    mutationFn: (career) => generateLearningPath({ targetCareer: career }).then((r) => r.data.data),
    onSuccess: (data) => { setResult(data); toast.success("Learning path generated!"); },
    onError: () => toast.error("Generation failed"),
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <Map className="w-6 h-6 text-primary-600" /> Learning Path Generator
        </h1>
        <p className="text-gray-500 mt-1">Get a personalized 6-month roadmap, certifications, and hybrid AI recommendations</p>
      </div>

      <div className="card flex gap-3">
        <select
          className="input flex-1"
          value={selectedCareer}
          onChange={(e) => setSelectedCareer(e.target.value)}
        >
          <option value="">Select your target career…</option>
          {careers.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <button
          onClick={() => selectedCareer && mutation.mutate(selectedCareer)}
          disabled={!selectedCareer || mutation.isPending}
          className="btn-primary whitespace-nowrap"
        >
          {mutation.isPending
            ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating…</>
            : <><Sparkles className="w-4 h-4" /> Generate</>}
        </button>
      </div>

      {mutation.isPending && (
        <div className="card text-center py-12">
          <Loader2 className="w-10 h-10 animate-spin text-primary-500 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Running 4 AI analyses in parallel…</p>
          <p className="text-sm text-gray-400 mt-1">Learning path · Certifications · Content-based · Hybrid rec</p>
        </div>
      )}

      {result && (
        <div className="card">
          <div className="flex items-center gap-2 mb-5">
            <span className="badge-purple text-sm">{result.targetCareer}</span>
            <span className="text-sm text-gray-400">·</span>
            <span className="text-sm text-gray-500">{result.userSkills?.length || 0} skills on profile</span>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 border-b border-gray-100 mb-6 -mx-6 px-6 overflow-x-auto">
            {TABS.map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={clsx(
                  "flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition-colors",
                  activeTab === key
                    ? "border-primary-500 text-primary-600"
                    : "border-transparent text-gray-500 hover:text-gray-700"
                )}
              >
                <Icon className="w-4 h-4" /> {label}
              </button>
            ))}
          </div>

          <div className="prose prose-sm max-w-none text-gray-700">
            <ReactMarkdown>{result[activeTab]}</ReactMarkdown>
          </div>

          {/* Collaborative results */}
          {activeTab === "hybridRec" && result.collaborativeResults?.length > 0 && (
            <div className="mt-6 pt-4 border-t border-gray-100">
              <p className="text-sm font-semibold text-gray-700 mb-3">Peer Insights (Collaborative Filtering)</p>
              <div className="space-y-2">
                {result.collaborativeResults.map((r) => (
                  <div key={cleanTitle(r.careerTitle)} className="flex items-center justify-between bg-gray-50 rounded-lg px-4 py-2.5">
                    <span className="text-sm font-medium text-gray-800">{cleanTitle(r.careerTitle)}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-gray-400">{r.similarUsersCount} similar users</span>
                      <span className="badge-purple">{(r.similarityScore * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
