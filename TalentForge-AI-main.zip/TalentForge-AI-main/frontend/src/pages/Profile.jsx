import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuthStore } from "../store/authStore";
import { updateProfile } from "../api/index";
import toast from "react-hot-toast";
import { User, Save, Plus, X } from "lucide-react";

export default function Profile() {
  const { user, updateUser } = useAuthStore();
  const profile = user?.profile || {};

  const [form, setForm] = useState({
    fullName: user?.fullName || "",
    bio: profile.bio || "",
    education: profile.education || "",
    location: profile.location || "",
    phoneNumber: user?.phoneNumber || "",
    skillInput: "",
    interestInput: "",
  });
  const [skills, setSkills] = useState(profile.skills || []);
  const [interests, setInterests] = useState(profile.interests || []);

  useEffect(() => {
    setSkills(profile.skills || []);
    setInterests(profile.interests || []);
  }, [user]);

  const mutation = useMutation({
    mutationFn: (data) => updateProfile(data),
    onSuccess: (res) => {
      updateUser(res.data.data);
      toast.success("Profile updated!");
    },
    onError: () => toast.error("Update failed"),
  });

  const handleSave = () => {
    mutation.mutate({
      fullName: form.fullName,
      bio: form.bio,
      education: form.education,
      location: form.location,
      phoneNumber: form.phoneNumber,
      skills,
      interests,
    });
  };

  const addSkill = () => {
    const s = form.skillInput.trim();
    if (s && !skills.includes(s)) {
      setSkills([...skills, s]);
      setForm({ ...form, skillInput: "" });
    }
  };

  const addInterest = () => {
    const i = form.interestInput.trim();
    if (i && !interests.includes(i)) {
      setInterests([...interests, i]);
      setForm({ ...form, interestInput: "" });
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <User className="w-6 h-6 text-primary-600" /> My Profile
        </h1>
        <p className="text-gray-500 mt-1">Keep your profile updated for better AI recommendations</p>
      </div>

      {/* Avatar */}
      <div className="card flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-bold text-2xl">
          {user?.fullName?.[0]?.toUpperCase()}
        </div>
        <div>
          <p className="font-semibold text-gray-900">{user?.fullName}</p>
          <p className="text-sm text-gray-500">{user?.email}</p>
          <span className={`badge mt-1 ${user?.role === "admin" ? "badge-purple" : "badge-gray"}`}>
            {user?.role}
          </span>
        </div>
      </div>

      {/* Basic Info */}
      <div className="card space-y-4">
        <h2 className="font-semibold text-gray-900">Basic Information</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="label">Full Name</label>
            <input type="text" className="input" value={form.fullName}
              onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </div>
          <div>
            <label className="label">Phone Number</label>
            <input type="tel" className="input" placeholder="+91 9876543210" value={form.phoneNumber}
              onChange={(e) => setForm({ ...form, phoneNumber: e.target.value })} />
          </div>
          <div>
            <label className="label">Location</label>
            <input type="text" className="input" placeholder="City, Country" value={form.location}
              onChange={(e) => setForm({ ...form, location: e.target.value })} />
          </div>
          <div>
            <label className="label">Education</label>
            <input type="text" className="input" placeholder="B.Tech CS, IIT Delhi" value={form.education}
              onChange={(e) => setForm({ ...form, education: e.target.value })} />
          </div>
        </div>
        <div>
          <label className="label">Bio</label>
          <textarea rows={3} className="input resize-none" placeholder="Tell us about yourself…"
            value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
        </div>
      </div>

      {/* Skills */}
      <div className="card space-y-3">
        <h2 className="font-semibold text-gray-900">Skills ({skills.length})</h2>
        <div className="flex gap-2">
          <input type="text" className="input flex-1" placeholder="Add a skill…"
            value={form.skillInput}
            onChange={(e) => setForm({ ...form, skillInput: e.target.value })}
            onKeyDown={(e) => e.key === "Enter" && addSkill()} />
          <button onClick={addSkill} className="btn-secondary px-3">
            <Plus className="w-4 h-4" />
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {skills.map((s) => (
            <span key={s} className="badge-purple flex items-center gap-1">
              {s}
              <button onClick={() => setSkills(skills.filter((x) => x !== s))}
                className="hover:text-red-500 transition-colors">
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
          {skills.length === 0 && <p className="text-sm text-gray-400">No skills added yet</p>}
        </div>
      </div>

      {/* Interests */}
      <div className="card space-y-3">
        <h2 className="font-semibold text-gray-900">Interests ({interests.length})</h2>
        <div className="flex gap-2">
          <input type="text" className="input flex-1" placeholder="Add an interest…"
            value={form.interestInput}
            onChange={(e) => setForm({ ...form, interestInput: e.target.value })}
            onKeyDown={(e) => e.key === "Enter" && addInterest()} />
          <button onClick={addInterest} className="btn-secondary px-3">
            <Plus className="w-4 h-4" />
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {interests.map((i) => (
            <span key={i} className="badge bg-blue-50 text-blue-700 flex items-center gap-1">
              {i}
              <button onClick={() => setInterests(interests.filter((x) => x !== i))}
                className="hover:text-red-500 transition-colors">
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
          {interests.length === 0 && <p className="text-sm text-gray-400">No interests added yet</p>}
        </div>
      </div>

      <button onClick={handleSave} disabled={mutation.isPending} className="btn-primary w-full">
        {mutation.isPending
          ? "Saving…"
          : <><Save className="w-4 h-4" /> Save Profile</>}
      </button>
    </div>
  );
}
