import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { simulateCareerTrajectory, getCareerProgressionGraph, getProfile } from "../api/index";
import { useAuthStore } from "../store/authStore";
import { 
  GitFork, Loader2, Sparkles, TrendingUp, ShieldAlert, 
  ArrowRight, Landmark, Briefcase, Award, Clock, HelpCircle, AlertCircle
} from "lucide-react";
import { toast } from "react-hot-toast";

export default function CareerTrajectory() {
  const { user, updateUser } = useAuthStore();
  const [selectedCareer, setSelectedCareer] = useState("");
  const [activePathId, setActivePathId] = useState(1);
  const [selectedStage, setSelectedStage] = useState(null);

  // Sync profile data on component mount
  useQuery({
    queryKey: ["userProfile", user?.id],
    queryFn: () => getProfile().then((r) => {
      const latestUser = r.data.data;
      if (latestUser) {
        updateUser(latestUser);
      }
      return latestUser;
    }),
    enabled: !!user?.id,
  });

  // Get full graph list for select dropdown
  const { data: graphData } = useQuery({
    queryKey: ["careerGraph"],
    queryFn: () => getCareerProgressionGraph().then((r) => r.data.data),
  });

  // Simulation Mutation
  const simulateMutation = useMutation({
    mutationFn: (targetCareer) => 
      simulateCareerTrajectory({ targetCareer }).then((r) => r.data.data),
    onSuccess: (data) => {
      toast.success("Simulation complete! Analysis ready.");
      // Auto-select first stage of active trajectory
      if (data?.trajectories?.[0]?.stages?.[0]) {
        setSelectedStage(data.trajectories[0].stages[0]);
      }
      setActivePathId(1);
    },
    onError: (err) => {
      toast.error(err.response?.data?.message || "Simulation failed");
    }
  });

  const runSimulation = () => {
    simulateMutation.mutate(selectedCareer);
  };

  const simulationResult = simulateMutation.data;
  const isSimulating = simulateMutation.isPending;

  // Resolve skills from all available sources (authStore state + localStorage resume fallback)
  const getMergedSkills = () => {
    const skillsSet = new Set();
    
    // 1. Auth store user skills
    if (user?.skills && Array.isArray(user.skills)) {
      user.skills.forEach(s => skillsSet.add(s.trim()));
    }
    
    // 2. LocalStorage parsed resume skills
    try {
      const resumeKey = user?.id ? `talentforge_resume_result_${user.id}` : "talentforge_resume_result";
      const savedResumeStr = localStorage.getItem(resumeKey);
      if (savedResumeStr) {
        const parsedResume = JSON.parse(savedResumeStr);
        const resumeSkills = parsedResume?.parsed?.skills || parsedResume?.skills || [];
        if (Array.isArray(resumeSkills)) {
          resumeSkills.forEach(s => skillsSet.add(s.trim()));
        }
      }
    } catch (e) {
      console.error("Failed to parse cached resume skills for trajectory:", e);
    }
    
    return Array.from(skillsSet);
  };

  const userSkills = getMergedSkills();

  const activePath = simulationResult?.trajectories?.find(
    (t) => t.pathId === activePathId
  );

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fadeIn">
      {/* Premium Gradient Header */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-indigo-50/90 via-white to-purple-50/60 text-slate-800 p-8 md:p-10 shadow-lg border border-indigo-100/80 shadow-indigo-100/10">
        {/* Ambient Glows */}
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-indigo-400/5 rounded-full blur-[100px] pointer-events-none animate-pulse" />
        <div className="absolute -bottom-20 -left-20 w-[300px] h-[300px] bg-purple-400/5 rounded-full blur-[80px] pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-4 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-100/80 hover:bg-indigo-200/80 text-indigo-700 text-xs font-black tracking-wider border border-indigo-200/60 transition-all shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-spin animate-infinite" style={{ animationDuration: '4s' }} /> 
              <span>UNIQUE HACKATHON USP</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-tight bg-gradient-to-r from-slate-900 via-indigo-950 to-indigo-900 bg-clip-text text-transparent">
              AI Career Trajectory Simulator
            </h1>
            <p className="text-slate-600 text-sm md:text-base font-medium leading-relaxed max-w-2xl">
              Explore your professional future using our <strong>Monte Carlo simulation engine</strong>. 
              TalentForge maps your current skills to probability-weighted vertical and lateral transitions, 
              complete with interactive timeline nodes, salary paths, and real-time gap analysis.
            </p>
          </div>
          <div className="flex-shrink-0 flex items-center">
            <div className="p-5 bg-gradient-to-tr from-indigo-100 to-purple-100 rounded-2xl border border-indigo-200/50 shadow-md shadow-indigo-100/5 backdrop-blur-md relative group hover:scale-105 transition-all duration-300">
              <GitFork className="w-12 h-12 text-indigo-600 relative z-10 animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      {/* Simulator Control Card */}
      <div className="card border border-slate-100 shadow-sm bg-white p-6 rounded-2xl">
        <h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-indigo-600" /> Choose Simulation Target
        </h2>
        <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-end">
          <div className="flex-1 space-y-2">
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Select Career Domain
            </label>
            <select
              value={selectedCareer}
              onChange={(e) => setSelectedCareer(e.target.value)}
              className="w-full rounded-xl border border-slate-200 px-4 py-3 bg-slate-50 text-slate-700 font-medium focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition"
            >
              <option value="">-- Based on my Profile Skills (Recommended) --</option>
              {graphData?.careers?.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <button
            onClick={runSimulation}
            disabled={isSimulating || userSkills.length === 0}
            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold shadow-md shadow-indigo-100 flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99] transition disabled:opacity-50 disabled:pointer-events-none"
          >
            {isSimulating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" /> Simulating...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" /> Run Monte Carlo Simulation
              </>
            )}
          </button>
        </div>
        {userSkills.length === 0 && (
          <div className="mt-3 flex items-center gap-2 p-3 bg-amber-50 rounded-xl text-amber-700 border border-amber-100 text-sm">
            <ShieldAlert className="w-4 h-4 flex-shrink-0" />
            <span>
              Your profile doesn't have any skills yet. Please add skills in the{" "}
              <a href="/profile" className="font-bold underline hover:text-amber-800">Profile</a> page to unlock personalized simulations.
            </span>
          </div>
        )}
      </div>

      {simulationResult ? (
        <div className="grid lg:grid-cols-12 gap-8 animate-fadeIn">
          {/* LEFT COLUMN: TRAJECTORY SELECTOR & TIMELINE */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Trajectory Path Selector */}
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider">
                Simulated Career Paths ({simulationResult.trajectories.length})
              </h3>
              <div className="grid md:grid-cols-2 gap-3">
                {simulationResult.trajectories.map((path) => (
                  <button
                    key={path.pathId}
                    onClick={() => {
                      setActivePathId(path.pathId);
                      setSelectedStage(path.stages[0]);
                    }}
                    className={`flex flex-col items-start p-4 rounded-xl border text-left transition-all ${
                      activePathId === path.pathId
                        ? "bg-indigo-50 border-indigo-300 ring-2 ring-indigo-500/10 shadow-sm"
                        : "bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="font-bold text-slate-800 text-sm">{path.label}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                        path.type === "vertical" 
                          ? "bg-emerald-100 text-emerald-800"
                          : "bg-purple-100 text-purple-800"
                      }`}>
                        {path.type === "vertical" ? "Vertical" : "Lateral"}
                      </span>
                    </div>
                    {path.transitionReason && (
                      <p className="text-xs text-slate-500 mt-1 italic line-clamp-1">
                        "{path.transitionReason}"
                      </p>
                    )}
                    <div className="flex items-center justify-between w-full mt-3 pt-2.5 border-t border-slate-100 text-xs text-slate-400">
                      <span>Prob: <strong className="text-slate-600">{(path.probability * 100).toFixed(0)}%</strong></span>
                      <span>Salary Growth: <strong className="text-emerald-600">+{((path.projectedSalary10yr - path.projectedSalary5yr)/path.projectedSalary5yr * 100 || 30).toFixed(0)}%</strong></span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Vertical Interactive Timeline */}
            <div className="card bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-6">
              <div className="flex justify-between items-center pb-4 border-b border-slate-100">
                <div>
                  <h3 className="font-bold text-slate-800 text-base">
                    Path Timeline: {activePath?.label}
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">Click any stage node to analyze required skills & gap details</p>
                </div>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-semibold">
                  <Clock className="w-3.5 h-3.5" /> 10-Year Horizon
                </span>
              </div>

              {/* Timeline Tree visualization */}
              <div className="relative pl-8 space-y-12 py-4">
                {/* Timeline vertical bar */}
                <div className="absolute left-3.5 top-8 bottom-8 w-1 bg-gradient-to-b from-indigo-500 via-purple-500 to-indigo-100 rounded" />

                {activePath?.stages?.map((stage, idx) => {
                  const isSelected = selectedStage?.title === stage.title;
                  const isLateralEntry = stage.isLateralEntry;
                  const currentLevel = simulationResult.currentLevel;
                  
                  // Stage status relative to estimated current level
                  let statusText = "Future Target";
                  let statusBg = "border-slate-300 bg-white text-slate-400";
                  if (stage.level < currentLevel) {
                    statusText = "Completed / Experience Available";
                    statusBg = "border-emerald-500 bg-emerald-500 text-white shadow-emerald-100 shadow-md";
                  } else if (stage.level === currentLevel) {
                    statusText = "Your Estimated Current Level";
                    statusBg = "border-indigo-600 bg-indigo-600 text-white shadow-indigo-100 shadow-lg animate-pulse";
                  }

                  return (
                    <div 
                      key={idx}
                      className={`relative group cursor-pointer transition-all ${
                        isSelected ? "scale-[1.01]" : "hover:translate-x-1"
                      }`}
                      onClick={() => setSelectedStage(stage)}
                    >
                      {/* Timeline Node Icon/Dot */}
                      <div className={`absolute -left-8 top-1.5 w-8 h-8 rounded-full border-4 flex items-center justify-center font-bold text-xs transition-all z-10 ${statusBg}`}>
                        {stage.level}
                      </div>

                      {/* Timeline Content Block */}
                      <div className={`p-4 rounded-xl border transition-all ${
                        isSelected 
                          ? "bg-indigo-50/70 text-slate-800 border-indigo-300 shadow-md shadow-indigo-100/50"
                          : "bg-white border-slate-100 hover:border-slate-200 hover:shadow-sm"
                      }`}>
                        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className={`font-bold text-sm ${isSelected ? "text-indigo-900" : "text-slate-800"}`}>
                                {stage.title}
                              </h4>
                              {isLateralEntry && (
                                <span className="bg-purple-500/10 text-purple-600 text-[10px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">
                                  Lateral Transition Entry Point
                                </span>
                              )}
                            </div>
                            <p className="text-xs mt-1 text-slate-500">
                              Estimated Year: <strong className="text-slate-700">{stage.estimatedYear === 0 ? "Now (Year 0)" : `Year ${stage.estimatedYear}`}</strong> · Experience: <strong className="text-slate-700">{stage.yearsExp} Yrs</strong>
                            </p>
                          </div>
                          <div className="text-right">
                            <span className={`inline-flex text-xs font-bold px-2.5 py-1 rounded-lg ${
                              isSelected ? "bg-indigo-100 text-indigo-700 border border-indigo-200/55" : "bg-emerald-50 text-emerald-700"
                            }`}>
                              ₹{stage.salaryRange?.min || stage.salary_range?.min || 0} - ₹{stage.salaryRange?.max || stage.salary_range?.max || 0} LPA
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Simulated Path Projections Card */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="card bg-gradient-to-br from-indigo-50 to-indigo-100/50 p-5 rounded-2xl border border-indigo-100 flex items-center gap-4">
                <div className="p-3 bg-white rounded-xl shadow-sm text-indigo-600">
                  <Landmark className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-indigo-800/60 uppercase tracking-wider">Projected 5-Year Average Salary</p>
                  <p className="text-2xl font-black text-indigo-900">₹{activePath?.projectedSalary5yr || 20} LPA</p>
                </div>
              </div>
              <div className="card bg-gradient-to-br from-purple-50 to-purple-100/50 p-5 rounded-2xl border border-purple-100 flex items-center gap-4">
                <div className="p-3 bg-white rounded-xl shadow-sm text-purple-600">
                  <TrendingUp className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-purple-800/60 uppercase tracking-wider">Projected 10-Year Average Salary</p>
                  <p className="text-2xl font-black text-purple-900">₹{activePath?.projectedSalary10yr || 45} LPA</p>
                </div>
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: DETAIL STAGE CARD & SIMULATION INSIGHTS */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Stage Detail Card */}
            {selectedStage ? (
              <div className="card bg-white text-slate-800 p-6 rounded-3xl shadow-lg border border-indigo-100/80 relative overflow-hidden">
                <div className="absolute right-0 top-0 translate-x-1/4 -translate-y-1/4 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />
                
                <h3 className="text-xs font-black text-indigo-650 uppercase tracking-widest mb-2 flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-indigo-600" /> Node Inspector (Level {selectedStage.level})
                </h3>
                <h2 className="text-xl font-black tracking-tight text-slate-900 mb-2">{selectedStage.title}</h2>
                <p className="text-xs text-slate-500 leading-relaxed mb-4">{selectedStage.description}</p>
                
                <div className="space-y-4 pt-4 border-t border-slate-100">
                  <div>
                    <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider mb-2">Key Skills Needed</h4>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedStage.keySkills?.map((skill) => {
                        const hasSkill = userSkills.some(
                          (us) => us.toLowerCase() === skill.toLowerCase()
                        );
                        return (
                          <span
                            key={skill}
                            className={`text-xs px-2.5 py-1.5 rounded-xl flex items-center gap-1 font-bold border ${
                              hasSkill 
                                ? "bg-emerald-50 text-emerald-700 border-emerald-250/60"
                                : "bg-slate-50 text-slate-650 border-slate-200/60"
                            }`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${hasSkill ? "bg-emerald-500" : "bg-slate-400"}`} />
                            {skill}
                          </span>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-xs font-black text-slate-450 uppercase tracking-wider mb-1.5">Expected Salary Range</h4>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-black text-emerald-600">
                        ₹{selectedStage.salaryRange?.min || selectedStage.salary_range?.min || 0}L - ₹{selectedStage.salaryRange?.max || selectedStage.salary_range?.max || 0}L
                      </span>
                      <span className="text-xs text-slate-450">Lakhs / year</span>
                    </div>
                  </div>

                  <div className="bg-indigo-50/50 border border-indigo-100/60 p-3 rounded-2xl">
                    <h4 className="text-xs font-black text-indigo-755 mb-1 flex items-center gap-1">
                      <Award className="w-3.5 h-3.5" /> Next Steps Recommendation
                    </h4>
                    <p className="text-[11px] text-slate-650 leading-relaxed font-semibold">
                      {selectedStage.level <= simulationResult.currentLevel
                        ? "You already satisfy or are currently at this experience stage. Great job!"
                        : `To reach this level, prioritize acquiring any missing skills above, work on relevant projects, and aim for ${selectedStage.yearsExp} years of technical experience.`}
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="card bg-slate-50 border border-dashed border-slate-200 p-8 rounded-2xl text-center text-slate-400 flex flex-col items-center justify-center">
                <HelpCircle className="w-8 h-8 mb-2 text-slate-300" />
                <p className="text-sm font-semibold">No stage selected</p>
                <p className="text-xs mt-1">Select a timeline stage node to view detailed gap analysis.</p>
              </div>
            )}

            {/* Simulation Insights */}
            <div className="card bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider border-b border-slate-100 pb-2">
                Monte Carlo Insights
              </h3>
              <div className="space-y-3">
                {simulationResult.insights?.map((insight, idx) => (
                  <div key={idx} className="flex gap-2.5 items-start text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <AlertCircle className="w-4 h-4 text-indigo-500 flex-shrink-0 mt-0.5" />
                    <span>{insight}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Lateral options summary */}
            {simulationResult.lateralOptions?.length > 0 && (
              <div className="card bg-white text-slate-800 p-6 rounded-3xl shadow-lg space-y-4 border border-indigo-100/80">
                <h3 className="text-xs font-black text-indigo-650 uppercase tracking-widest flex items-center gap-1.5">
                  <GitFork className="w-4 h-4 text-indigo-650" /> Lateral Career Pivots
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                  Our simulator projects these lateral pivots as highly viable transitions based on your shared skill overlap:
                </p>
                <div className="space-y-3">
                  {simulationResult.lateralOptions.map((opt, idx) => (
                    <div key={idx} className="bg-indigo-50/50 border border-indigo-100/60 p-3 rounded-2xl space-y-1.5 shadow-sm">
                      <div className="flex justify-between items-center">
                        <span className="font-black text-slate-800 text-xs">{opt.to}</span>
                        <span className="bg-indigo-100 text-indigo-705 border border-indigo-200/50 font-black text-[10px] px-1.5 py-0.5 rounded">
                          {(opt.probability * 100).toFixed(0)}% Likelihood
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-655 font-medium italic leading-relaxed">
                        "{opt.reason}"
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        </div>
      ) : (
        <div className="card bg-white border border-slate-100 p-12 rounded-2xl shadow-sm text-center flex flex-col items-center justify-center space-y-4">
          <div className="p-4 bg-indigo-50 rounded-2xl text-indigo-600 animate-bounce">
            <GitFork className="w-10 h-10" />
          </div>
          <div className="max-w-md space-y-1">
            <h3 className="font-bold text-slate-800 text-lg">No Active Simulation</h3>
            <p className="text-sm text-slate-500">
              Click the "Run Monte Carlo Simulation" button above to dynamically project your career path over a 10-year horizon.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
