import { useState } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { verifyOtp } from "../api/auth";
import toast from "react-hot-toast";
import { MailCheck } from "lucide-react";

export default function VerifyOtp() {
  const [searchParams] = useSearchParams();
  const email = searchParams.get("email") || "";
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await verifyOtp({ email, code });
      toast.success("Email verified! You can now log in.");
      navigate("/login");
    } catch (err) {
      toast.error(err.response?.data?.message || "Invalid or expired OTP");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-130px)] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-green-100 rounded-xl mb-4">
            <MailCheck className="w-6 h-6 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Verify your email</h1>
          <p className="text-gray-500 mt-1">
            We sent a 6-digit code to <span className="font-medium text-gray-700">{email}</span>
          </p>
        </div>

        <div className="card">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">OTP Code</label>
              <input
                type="text"
                required
                maxLength={6}
                pattern="\d{6}"
                className="input text-center text-2xl tracking-widest font-mono"
                placeholder="000000"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
              />
              <p className="text-xs text-gray-400 mt-1.5">Enter the 6-digit code from your email. Expires in 10 minutes.</p>
            </div>
            <button type="submit" disabled={loading || code.length !== 6} className="btn-primary w-full">
              {loading ? "Verifying…" : "Verify Email"}
            </button>
          </form>
          <p className="text-center text-sm text-gray-500 mt-4">
            Wrong email?{" "}
            <Link to="/register" className="text-primary-600 hover:underline">Go back</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
