import { useQuery } from "@tanstack/react-query";
import { getSkillSynergies, getTopSkillCombinations, getProfile } from "../api/index";
import { useAuthStore } from "../store/authStore";
import { 
  Layers, Sparkles, TrendingUp, ShieldAlert, Award, Lightbulb, 
  HelpCircle, ArrowRight, Zap, Target, BookOpen, Loader2
} from "lucide-react";

export default function SkillSynergy() {
  const { user, updateUser } = useAuthStore();

  // Sync profile data on component mount
  useQuery({
    queryKey: ["userProfile", user?.id],
    queryFn: () => getProfile().then((r) => {
      const latestUser = r.data.data;
      if (latestUser) {
        updateUser(latestUser);
      }
      return latestUser;
    }),
    enabled: !!user?.id,
  });

  // Resolve skills from all available sources (authStore state + localStorage resume fallback)
  const getMergedSkills = () => {
    const skillsSet = new Set();
    
    // 1. Auth store user skills
    if (user?.skills && Array.isArray(user.skills)) {
      user.skills.forEach(s => skillsSet.add(s.trim()));
    }
    
    // 2. LocalStorage parsed resume skills
    try {
      const resumeKey = user?.id ? `talentforge_resume_result_${user.id}` : "talentforge_resume_result";
      const savedResumeStr = localStorage.getItem(resumeKey);
      if (savedResumeStr) {
        const parsedResume = JSON.parse(savedResumeStr);
        const resumeSkills = parsedResume?.parsed?.skills || parsedResume?.skills || [];
        if (Array.isArray(resumeSkills)) {
          resumeSkills.forEach(s => skillsSet.add(s.trim()));
        }
      }
    } catch (e) {
      console.error("Failed to parse cached resume skills for synergy:", e);
    }
    
    return Array.from(skillsSet);
  };

  const userSkills = getMergedSkills();

  // Fetch User-specific Synergy
  const { 
    data: synergyData, 
    isLoading: isUserSynergyLoading,
    error: userSynergyError 
  } = useQuery({
    queryKey: ["userSynergies", user?.id],
    queryFn: () => getSkillSynergies().then((r) => r.data.data),
    enabled: !!user?.id && userSkills.length >= 2,
  });

  // Fetch Global Trending Combos
  const { data: trendingData, isLoading: isTrendingLoading } = useQuery({
    queryKey: ["trendingCombos"],
    queryFn: () => getTopSkillCombinations().then((r) => r.data.data),
  });

  const trendingCombos = trendingData?.combinations || [];

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fadeIn">
      {/* Premium Gradient Header */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-purple-50/90 via-white to-indigo-50/60 text-slate-800 p-8 md:p-10 shadow-lg border border-purple-100/80 shadow-purple-100/10">
        {/* Ambient Glows */}
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-purple-400/5 rounded-full blur-[100px] pointer-events-none animate-pulse" />
        <div className="absolute -bottom-20 -left-20 w-[300px] h-[300px] bg-indigo-400/5 rounded-full blur-[80px] pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-4 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-100/80 hover:bg-purple-200/80 text-purple-700 text-xs font-black tracking-wider border border-purple-200/60 transition-all shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-purple-650 animate-spin animate-infinite" style={{ animationDuration: '4s' }} /> 
              <span>UNIQUE HACKATHON USP</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-tight bg-gradient-to-r from-slate-900 via-purple-950 to-purple-900 bg-clip-text text-transparent">
              Skill Synergy &amp; Co-occurrence Matrix
            </h1>
            <p className="text-slate-605 text-sm md:text-base font-medium leading-relaxed max-w-2xl">
              Most platforms analyze skills in isolation. TalentForge evaluates <strong>synergy multipliers</strong> — 
              how much more valuable skill <em>combinations</em> are together in the live market compared to individual assets. 
              Discover high-value skill pairings and boost your marketability index.
            </p>
          </div>
          <div className="flex-shrink-0 flex items-center">
            <div className="p-5 bg-gradient-to-tr from-purple-100 to-indigo-100 rounded-2xl border border-purple-200/50 shadow-md shadow-purple-100/5 backdrop-blur-md relative group hover:scale-105 transition-all duration-300">
              <Layers className="w-12 h-12 text-purple-600 relative z-10 animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      {userSkills.length < 2 ? (
        <div className="card bg-white border border-slate-100 p-8 rounded-2xl shadow-sm text-center flex flex-col items-center justify-center space-y-4">
          <div className="p-4 bg-amber-50 rounded-2xl text-amber-600">
            <ShieldAlert className="w-10 h-10" />
          </div>
          <div className="max-w-md space-y-1.5">
            <h3 className="font-bold text-slate-800 text-lg">Synergy Analysis Locked</h3>
            <p className="text-sm text-slate-500 leading-relaxed">
              You need at least <strong>2 skills</strong> on your profile for co-occurrence synergy analysis. 
              Go add skills or upload a resume to discover valuable multipliers!
            </p>
            <div className="pt-2">
              <a
                href="/profile"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 px-3 py-2 rounded-xl transition"
              >
                Go to Profile Page <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      ) : isUserSynergyLoading ? (
        <div className="flex flex-col items-center justify-center h-64 space-y-2">
          <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
          <p className="text-xs text-slate-400 font-medium">Computing co-occurrence multipliers...</p>
        </div>
      ) : synergyData ? (
        <div className="grid lg:grid-cols-12 gap-8 animate-fadeIn">
          {/* LEFT COLUMN: OVERALL SYNERGY INDEX & USER COMBOS */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Overall Synergy Gauge Card */}
            <div className="card bg-white border border-slate-100 p-6 rounded-2xl shadow-sm grid md:grid-cols-12 gap-6 items-center relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/5 rounded-full blur-xl pointer-events-none" />
              
              <div className="md:col-span-4 text-center space-y-1 border-r border-slate-100 md:pr-6">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Synergy Index</p>
                <div className="text-4xl font-black text-purple-600 inline-flex items-baseline">
                  {synergyData.overallSynergyScore}
                  <span className="text-sm font-bold text-slate-400 ml-0.5">x</span>
                </div>
                <p className="text-xs text-slate-500">Average co-occurrence strength</p>
              </div>

              <div className="md:col-span-8 space-y-2.5">
                <h3 className="font-bold text-slate-800 text-sm">What does this score mean?</h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  A synergy index above <strong>1.5x</strong> indicates you have selected skills that form 
                  cohesive, highly sought-after pairs in tech teams. Combining them creates leverage, making you 
                  more competitive for specific roles like <strong className="text-purple-600">{synergyData.synergies?.[0]?.relevantCareers?.[0] || "Data Science / Development"}</strong>.
                </p>
                <div className="flex items-center gap-4 text-xs font-semibold pt-1 text-slate-600">
                  <span>Skills Analyzed: <strong className="text-purple-600">{synergyData.userSkillCount}</strong></span>
                  <span>Categories Matched: <strong className="text-purple-600">{Object.keys(synergyData.skillCategories || {}).length}</strong></span>
                </div>
              </div>
            </div>

            {/* Simulated Combinations Grid */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider">
                  Your High-Synergy Combinations ({synergyData.synergies?.length || 0})
                </h3>
              </div>

              <div className="space-y-3">
                {synergyData.synergies?.map((combo, idx) => (
                  <div 
                    key={idx}
                    className="card bg-white border border-slate-100 p-5 rounded-2xl hover:shadow-md hover:border-purple-200 transition-all space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                      {/* Combination Pills */}
                      <div className="flex flex-wrap items-center gap-1.5">
                        {combo.skills.map((s, sidx) => (
                          <span 
                            key={s} 
                            className="inline-flex items-center text-xs font-bold text-slate-700 bg-slate-50 border border-slate-200/60 px-2.5 py-1 rounded-lg"
                          >
                            {sidx > 0 && <span className="text-purple-400 mr-1.5 font-bold">+</span>}
                            {s}
                          </span>
                        ))}
                      </div>
                      
                      {/* Score metrics */}
                      <div className="flex items-center gap-3 flex-shrink-0">
                        <div className="bg-purple-50 text-purple-700 text-xs px-2.5 py-1 rounded-lg border border-purple-100 font-bold">
                          {combo.synergyScore}x Synergy
                        </div>
                        <div className="bg-emerald-50 text-emerald-700 text-xs px-2.5 py-1 rounded-lg border border-emerald-100 font-bold">
                          {combo.demandBoost} Demand
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                      <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        <Target className="w-3.5 h-3.5 text-purple-500" /> Synergy Insight
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {combo.insight}
                      </p>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                      <span>Category: <strong className="text-slate-600 font-semibold">{combo.category}</strong></span>
                      <span>Target Jobs: <strong className="text-slate-600 font-semibold">{combo.relevantCareers.join(", ")}</strong></span>
                    </div>

                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: ACTIONABLE RECOMMENDATIONS & CATEGORIES */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Category breakdown */}
            <div className="card bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-500" /> Skill Archetypes
              </h3>
              <div className="space-y-3.5">
                {Object.entries(synergyData.skillCategories || {}).map(([category, skills]) => (
                  <div key={category} className="space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{category}</span>
                    <div className="flex flex-wrap gap-1">
                      {skills.map((s) => (
                        <span key={s} className="bg-slate-50 text-slate-600 text-xs px-2 py-0.5 rounded border border-slate-100 font-medium">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Strategic Recommendations */}
            <div className="card bg-white text-slate-800 p-6 rounded-3xl shadow-lg border border-purple-100/80 space-y-4 relative overflow-hidden">
              <div className="absolute bottom-0 right-0 translate-x-1/4 translate-y-1/4 w-32 h-32 bg-purple-500/5 rounded-full blur-2xl pointer-events-none" />
              
              <h3 className="text-xs font-black text-purple-650 uppercase tracking-widest flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4 text-purple-600 animate-pulse" /> Strategic Recommendations
              </h3>
              <div className="space-y-3.5">
                {synergyData.recommendations?.map((rec, idx) => (
                  <div key={idx} className="flex gap-2.5 items-start text-xs text-slate-650 font-semibold bg-purple-50/40 p-3 rounded-2xl border border-purple-100/30 shadow-sm">
                    <BookOpen className="w-4 h-4 text-purple-500 flex-shrink-0 mt-0.5" />
                    <span className="leading-relaxed">{rec}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      ) : null}

      {/* Global Trending combinations */}
      <div className="card bg-white border border-slate-100 p-6 rounded-2xl shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h3 className="font-bold text-slate-800 text-base">
              Global Trending Skill Combos 2026
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Most in-demand co-occurrences extracted from global tech roles</p>
          </div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-50 text-purple-700 text-xs font-semibold border border-purple-100">
            <TrendingUp className="w-3.5 h-3.5" /> Trending Stacks
          </span>
        </div>

        {isTrendingLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-purple-500" />
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {trendingCombos.slice(0, 9).map((combo, idx) => (
              <div 
                key={idx} 
                className="bg-slate-50/50 p-4 rounded-xl border border-slate-100 space-y-3.5 hover:shadow-sm hover:bg-white hover:border-purple-100 transition-all"
              >
                <div className="flex justify-between items-center">
                  <span className="text-[10px] bg-purple-50 text-purple-700 font-bold px-2 py-0.5 rounded">
                    Rank #{idx + 1}
                  </span>
                  <span className="text-xs font-extrabold text-emerald-600">
                    {combo.demandBoost} Boost
                  </span>
                </div>
                
                <div className="flex flex-wrap items-center gap-1">
                  {combo.skills.map((s, sidx) => (
                    <span 
                      key={s} 
                      className="text-xs font-bold text-slate-700 bg-white border border-slate-200/50 px-2 py-0.5 rounded"
                    >
                      {s}
                    </span>
                  ))}
                </div>

                <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-200/50 flex justify-between items-center">
                  <span>Target: <strong className="text-slate-600">{combo.relevantCareers?.[0]}</strong></span>
                  <span className="font-semibold text-purple-600">{combo.synergyScore}x strength</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
