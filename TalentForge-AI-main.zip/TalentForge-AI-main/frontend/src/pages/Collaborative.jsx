import { useQuery } from "@tanstack/react-query";
import { getCollaborativeRecs } from "../api/index";
import ReactFlow, { Background, Controls, MiniMap } from "reactflow";
import "reactflow/dist/style.css";
import { Users, Loader2, TrendingUp } from "lucide-react";
import { useMemo } from "react";
import { useAuthStore } from "../store/authStore";

const cleanTitle = (title) => {
  if (!title) return "";
  return title.replace(/^[\s*_#]+|[\s*_#]+$/g, "");
};

function buildFlowGraph(recs, userSkills) {
  const nodes = [
    {
      id: "user",
      type: "input",
      data: {
        label: (
          <div className="p-3 rounded-xl border border-primary-200 bg-primary-50 shadow-sm text-center">
            <p className="text-xs text-primary-600 font-semibold uppercase tracking-wider mb-1">Your Profile</p>
            <p className="text-sm font-bold text-gray-900 truncate max-w-[160px]">{userSkills.slice(0, 3).join(", ") || "No Skills"}{userSkills.length > 3 ? "..." : ""}</p>
          </div>
        ),
      },
      position: { x: 250, y: 0 },
    },
  ];

  recs.forEach((r, i) => {
    nodes.push({
      id: `rec-${i}`,
      type: "output",
      data: {
        label: (
          <div className="p-3 rounded-xl border border-purple-200 bg-purple-50 shadow-sm text-center">
            <p className="text-sm font-bold text-gray-900 truncate max-w-[160px]">{cleanTitle(r.careerTitle)}</p>
            <div className="mt-1 flex items-center justify-center gap-1.5 text-xs font-semibold text-purple-600">
              <TrendingUp className="w-3 h-3" /> {(r.similarityScore * 100).toFixed(0)}% Similarity
            </div>
          </div>
        ),
      },
      position: { x: 50 + i * 200, y: 150 },
    });
  });

  const edges = recs.map((r, i) => ({
    id: `e-user-rec-${i}`,
    source: "user",
    target: `rec-${i}`,
    label: `${r.similarUsersCount} peers`,
    style: { stroke: "#a78bfa" },
    labelStyle: { fontSize: 10, fill: "#7c3aed" },
    animated: true,
  }));

  return { nodes, edges };
}

export default function Collaborative() {
  const { user } = useAuthStore();
  const { data, isLoading } = useQuery({
    queryKey: ["collaborative", user?.id],
    queryFn: () => getCollaborativeRecs().then((r) => r.data.data),
    enabled: !!user?.id,
  });

  const recs = data?.recommendations || [];
  const userSkills = data?.userSkills || [];

  const { nodes, edges } = useMemo(() => buildFlowGraph(recs, userSkills), [recs, userSkills]);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <Users className="w-6 h-6 text-primary-600" /> Peer Insights
        </h1>
        <p className="text-gray-500 mt-1">
          Careers chosen by users with similar skill profiles — cosine similarity collaborative filtering
        </p>
      </div>

      {isLoading ? (
        <div className="card text-center py-16">
          <Loader2 className="w-8 h-8 animate-spin text-primary-500 mx-auto mb-3" />
          <p className="text-gray-500">Computing cosine similarity across all users…</p>
        </div>
      ) : (
        <>
          {/* Stats */}
          <div className="grid grid-cols-3 gap-4">
            <div className="card text-center">
              <p className="text-2xl font-bold text-primary-600">{data?.peerCount || 0}</p>
              <p className="text-sm text-gray-500">Similar Peers Found</p>
            </div>
            <div className="card text-center">
              <p className="text-2xl font-bold text-purple-600">{recs.length}</p>
              <p className="text-sm text-gray-500">Career Suggestions</p>
            </div>
            <div className="card text-center">
              <p className="text-2xl font-bold text-blue-600">{userSkills.length}</p>
              <p className="text-sm text-gray-500">Your Skills</p>
            </div>
          </div>

          {/* React Flow Graph */}
          {recs.length > 0 && (
            <div className="card p-0 overflow-hidden" style={{ height: 480 }}>
              <div className="px-4 py-3 border-b border-gray-100">
                <p className="text-sm font-semibold text-gray-700">Career Similarity Graph</p>
                <p className="text-xs text-gray-400">Edges show number of peers who chose each career</p>
              </div>
              <ReactFlow nodes={nodes} edges={edges} fitView>
                <Background color="#f0f0f0" gap={16} />
                <Controls />
                <MiniMap nodeColor="#a78bfa" />
              </ReactFlow>
            </div>
          )}

          {/* Recommendation Cards */}
          <div className="space-y-3">
            {recs.map((r, i) => (
              <div key={i} className="card flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center flex-shrink-0">
                  <TrendingUp className="w-5 h-5 text-purple-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-900">{cleanTitle(r.careerTitle)}</p>
                  <p className="text-sm text-gray-500">
                    Common skills: {r.commonSkills?.join(", ") || "—"}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-lg font-bold text-purple-600">
                    {(r.similarityScore * 100).toFixed(0)}%
                  </p>
                  <p className="text-xs text-gray-400">{r.similarUsersCount} peers</p>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
