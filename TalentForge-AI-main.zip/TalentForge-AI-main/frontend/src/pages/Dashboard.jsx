import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { useAuthStore } from "../store/authStore";
import { listRecommendations, downloadReport } from "../api/index";
import { Briefcase, Target, Map, TrendingUp, FileText, Download, ArrowRight, Zap } from "lucide-react";
import toast from "react-hot-toast";

const QUICK_LINKS = [
  { to: "/career",        label: "Get Career Recommendation", icon: Briefcase,  color: "bg-purple-50 text-purple-600" },
  { to: "/resume",        label: "Analyze Resume",            icon: FileText,   color: "bg-blue-50 text-blue-600" },
  { to: "/skill-gap",     label: "Check Skill Gap",           icon: Target,     color: "bg-green-50 text-green-600" },
  { to: "/learning-path", label: "Generate Learning Path",    icon: Map,        color: "bg-orange-50 text-orange-600" },
  { to: "/market-trends", label: "View Market Trends",        icon: TrendingUp, color: "bg-pink-50 text-pink-600" },
  { to: "/chat",          label: "Chat with AI Mentor",       icon: Zap,        color: "bg-indigo-50 text-indigo-600" },
];

const cleanTitle = (title) => {
  if (!title) return "";
  return title.replace(/^[\s*_#]+|[\s*_#]+$/g, "");
};

export default function Dashboard() {
  const { user } = useAuthStore();
  const { data, isLoading } = useQuery({
    queryKey: ["recommendations", user?.id],
    queryFn: () => listRecommendations().then((r) => r.data.data),
    enabled: !!user?.id,
  });

  const recs = data || [];

  const handleDownload = async () => {
    try {
      const res = await downloadReport();
      const url = URL.createObjectURL(new Blob([res.data], { type: "application/pdf" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = "talentforge_report.pdf";
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      toast.error("Failed to generate report");
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Welcome */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Welcome back, {user?.fullName?.split(" ")[0]}
          </h1>
          <p className="text-gray-500 mt-1">Here's your career guidance overview</p>
        </div>
        <button onClick={handleDownload} className="btn-secondary flex items-center gap-2">
          <Download className="w-4 h-4" /> Download PDF Report
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Recommendations",  value: recs.length,                                                  color: "text-primary-600" },
          { label: "Avg Match Score",  value: recs.length ? `${(recs.reduce((s, r) => s + r.matchPercentage, 0) / recs.length).toFixed(1)}%` : "—", color: "text-green-600" },
          { label: "Skills on Profile", value: user?.profile?.skills?.length || 0,                          color: "text-blue-600" },
          { label: "Top Career",        value: recs[0] ? cleanTitle(recs[0].careerTitle).split(" ").slice(0, 2).join(" ") : "—", color: "text-purple-600" },
        ].map(({ label, value, color }) => (
          <div key={label} className="card text-center">
            <p className={`text-3xl font-bold ${color}`}>{value}</p>
            <p className="text-sm text-gray-500 mt-1">{label}</p>
          </div>
        ))}
      </div>

      {/* Quick Links */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {QUICK_LINKS.map(({ to, label, icon: Icon, color }) => (
            <Link key={to} to={to}
              className="card hover:shadow-md transition-shadow flex items-center gap-3 group">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-sm font-medium text-gray-700 group-hover:text-primary-600 transition-colors">
                {label}
              </span>
              <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-primary-400 ml-auto transition-colors" />
            </Link>
          ))}
        </div>
      </div>

      {/* Recent Recommendations */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Recent Recommendations</h2>
          <Link to="/career" className="text-sm text-primary-600 hover:underline flex items-center gap-1">
            Get new <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="card animate-pulse h-20 bg-gray-100" />
            ))}
          </div>
        ) : recs.length === 0 ? (
          <div className="card text-center py-12">
            <Briefcase className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 mb-4">No recommendations yet</p>
            <Link to="/career" className="btn-primary">Get Your First Recommendation</Link>
          </div>
        ) : (
          <div className="space-y-3">
            {recs.slice(0, 5).map((rec) => (
              <div key={rec.id} className="card flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary-100 flex items-center justify-center flex-shrink-0">
                  <Briefcase className="w-6 h-6 text-primary-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-900">{cleanTitle(rec.careerTitle)}</p>
                  <p className="text-sm text-gray-500 truncate">{rec.aiModelUsed}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-lg font-bold text-green-600">{rec.matchPercentage?.toFixed(1)}%</p>
                  <p className="text-xs text-gray-400">match</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
