import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { analyzeResume } from "../api/index";
import ReactMarkdown from "react-markdown";
import toast from "react-hot-toast";
import {
  FileText, Upload, Loader2, CheckCircle, X, Eye,
  Sparkles, Brain, GraduationCap, Briefcase, Award,
  ChevronRight, AlertCircle
} from "lucide-react";
import clsx from "clsx";

const TABS = [
  { id: "analysis",   label: "AI Analysis",  icon: Brain },
  { id: "skills",     label: "Skills",       icon: Sparkles },
  { id: "experience", label: "Experience",   icon: Briefcase },
  { id: "education",  label: "Education",    icon: GraduationCap },
];

function SkillBadge({ skill }) {
  return (
    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r from-primary-50 to-violet-50 text-primary-700 border border-primary-100 hover:border-primary-300 transition-colors">
      {skill}
    </span>
  );
}

function StatCard({ label, value, color = "primary" }) {
  const colors = {
    primary: "from-primary-500 to-violet-500",
    green:   "from-green-400 to-emerald-500",
    amber:   "from-amber-400 to-orange-500",
    blue:    "from-blue-400 to-cyan-500",
  };
  return (
    <div className="bg-white rounded-xl border border-gray-100 p-4 flex flex-col gap-1 shadow-sm">
      <span className={`text-2xl font-bold bg-gradient-to-r ${colors[color]} bg-clip-text text-transparent`}>
        {value}
      </span>
      <span className="text-xs text-gray-500 font-medium">{label}</span>
    </div>
  );
}

export default function ResumeAnalyzer() {
  const [file, setFile]         = useState(null);
  const [loading, setLoading]   = useState(false);
  const [result, setResult]     = useState(null);
  const [activeTab, setActiveTab] = useState("analysis");

  const onDrop = useCallback((accepted) => {
    if (accepted[0]) { setFile(accepted[0]); setResult(null); }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { "application/pdf": [".pdf"] },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024,
    onDropRejected: () => toast.error("Only PDF files up to 10 MB are accepted"),
  });

  const handleAnalyze = async () => {
    if (!file) return;
    setLoading(true);
    setResult(null);
    const formData = new FormData();
    formData.append("resume", file);
    try {
      const res = await analyzeResume(formData);
      setResult(res.data.data);
      setActiveTab("analysis");
      toast.success("Resume analyzed successfully!");
    } catch (err) {
      toast.error(err.response?.data?.message || "Analysis failed");
    } finally {
      setLoading(false);
    }
  };

  const skillCount   = result?.parsed?.skills?.length || 0;
  const expCount     = result?.parsed?.experience?.length || 0;
  const eduCount     = result?.parsed?.education?.length || 0;
  const certCount    = result?.parsed?.certifications?.length || 0;

  return (
    <div className="max-w-4xl mx-auto space-y-6">

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-500 to-violet-500 flex items-center justify-center">
              <FileText className="w-4 h-4 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Resume Analyzer</h1>
          </div>
          <p className="text-gray-500 text-sm ml-10">
            AI-powered resume parsing — extract skills, experience &amp; get actionable insights
          </p>
        </div>
        {result && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 border border-green-200 rounded-full">
            <CheckCircle className="w-3.5 h-3.5 text-green-600" />
            <span className="text-xs font-medium text-green-700">Analysis complete</span>
          </div>
        )}
      </div>

      {/* Upload Card */}
      <div className="card">
        <div
          {...getRootProps()}
          className={clsx(
            "relative border-2 border-dashed rounded-xl transition-all duration-200 cursor-pointer overflow-hidden",
            isDragActive
              ? "border-primary-400 bg-primary-50 scale-[1.01]"
              : file
              ? "border-green-300 bg-green-50/50"
              : "border-gray-200 hover:border-primary-300 hover:bg-gray-50/80"
          )}
        >
          <input {...getInputProps()} />

          {/* Decorative gradient blob */}
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-gradient-to-br from-primary-100 to-violet-100 rounded-full opacity-40 pointer-events-none" />

          <div className="relative px-8 py-10 text-center">
            {file ? (
              <div className="flex flex-col items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-green-100 flex items-center justify-center">
                  <FileText className="w-7 h-7 text-green-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">{file.name}</p>
                  <p className="text-sm text-gray-400 mt-0.5">
                    {(file.size / 1024 / 1024).toFixed(2)} MB · PDF
                  </p>
                </div>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setFile(null); setResult(null); }}
                  className="flex items-center gap-1.5 text-xs text-red-500 hover:text-red-700 hover:bg-red-50 px-3 py-1.5 rounded-full border border-red-200 transition-colors"
                >
                  <X className="w-3 h-3" /> Remove file
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3">
                <div className={clsx(
                  "w-14 h-14 rounded-2xl flex items-center justify-center transition-colors",
                  isDragActive ? "bg-primary-100" : "bg-gray-100"
                )}>
                  <Upload className={clsx("w-7 h-7", isDragActive ? "text-primary-600" : "text-gray-400")} />
                </div>
                <div>
                  <p className="font-semibold text-gray-700">
                    {isDragActive ? "Drop it here!" : "Drop your PDF resume here"}
                  </p>
                  <p className="text-sm text-gray-400 mt-1">or click to browse — max 10 MB</p>
                </div>
                <div className="flex items-center gap-4 mt-1">
                  {["PDF only", "Max 10 MB", "AI-powered"].map((tag) => (
                    <span key={tag} className="flex items-center gap-1 text-xs text-gray-400">
                      <ChevronRight className="w-3 h-3 text-primary-400" />{tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Action buttons */}
        {file && (
          <div className="mt-4 flex gap-3">
            <button
              onClick={handleAnalyze}
              disabled={loading}
              className="btn-primary flex-1 py-3 text-base"
            >
              {loading ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing…</>
              ) : (
                <><Sparkles className="w-4 h-4" /> Analyze Resume</>
              )}
            </button>
            {result?.fileName && (
              <a
                href={`/api/resume/preview/${result.fileName}`}
                target="_blank"
                rel="noreferrer"
                className="btn-secondary flex items-center gap-2"
              >
                <Eye className="w-4 h-4" /> Preview
              </a>
            )}
          </div>
        )}
      </div>

      {/* Loading state */}
      {loading && (
        <div className="card">
          <div className="flex flex-col items-center py-10 gap-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-full bg-primary-50 flex items-center justify-center">
                <Brain className="w-8 h-8 text-primary-500" />
              </div>
              <Loader2 className="w-6 h-6 animate-spin text-primary-500 absolute -bottom-1 -right-1" />
            </div>
            <div className="text-center">
              <p className="font-semibold text-gray-800">Analyzing your resume…</p>
              <p className="text-sm text-gray-400 mt-1">spaCy + Groq AI is extracting skills, experience &amp; insights</p>
            </div>
            <div className="flex gap-2 mt-2">
              {["Parsing PDF", "Extracting skills", "Generating insights"].map((step, i) => (
                <span key={i} className="text-xs px-3 py-1 bg-primary-50 text-primary-600 rounded-full border border-primary-100 animate-pulse" style={{ animationDelay: `${i * 200}ms` }}>
                  {step}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Results */}
      {result && (
        <div className="space-y-4">

          {/* Stats row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <StatCard label="Skills Detected"    value={skillCount} color="primary" />
            <StatCard label="Experience Entries" value={expCount}   color="blue" />
            <StatCard label="Education Entries"  value={eduCount}   color="green" />
            <StatCard label="Certifications"     value={certCount}  color="amber" />
          </div>

          {/* Tabbed results card */}
          <div className="card !p-0 overflow-hidden">

            {/* Tab bar */}
            <div className="flex border-b border-gray-100 bg-gray-50/60 px-2 pt-2">
              {TABS.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id)}
                  className={clsx(
                    "flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium rounded-t-lg border-b-2 transition-all",
                    activeTab === id
                      ? "border-primary-500 text-primary-600 bg-white shadow-sm"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:bg-white/60"
                  )}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {label}
                  {id === "skills" && skillCount > 0 && (
                    <span className="ml-0.5 px-1.5 py-0.5 text-[10px] font-semibold bg-primary-100 text-primary-700 rounded-full">
                      {skillCount}
                    </span>
                  )}
                </button>
              ))}
            </div>

            <div className="p-6">

              {/* Analysis tab */}
              {activeTab === "analysis" && (
                <div className="prose prose-sm max-w-none text-gray-700 prose-headings:text-gray-900 prose-strong:text-gray-800 prose-li:text-gray-600">
                  <ReactMarkdown>{result.analysis}</ReactMarkdown>
                </div>
              )}

              {/* Skills tab */}
              {activeTab === "skills" && (
                <div className="space-y-5">
                  {result.parsed?.summary && (
                    <div className="flex gap-3 p-4 bg-gradient-to-r from-primary-50 to-violet-50 rounded-xl border border-primary-100">
                      <div className="w-8 h-8 rounded-lg bg-primary-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <FileText className="w-4 h-4 text-primary-600" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-primary-700 uppercase tracking-wide mb-1">Professional Summary</p>
                        <p className="text-sm text-gray-700 leading-relaxed">{result.parsed.summary}</p>
                      </div>
                    </div>
                  )}

                  {skillCount > 0 ? (
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-primary-500" />
                        Detected Skills
                        <span className="badge-purple">{skillCount}</span>
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {result.parsed.skills.map((s) => <SkillBadge key={s} skill={s} />)}
                      </div>
                    </div>
                  ) : (
                    <EmptyState icon={AlertCircle} message="No skills extracted from this resume" />
                  )}

                  {result.parsed?.certifications?.length > 0 && (
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                        <Award className="w-4 h-4 text-amber-500" /> Certifications
                      </p>
                      <ul className="space-y-2">
                        {result.parsed.certifications.map((c, i) => (
                          <li key={i} className="flex items-center gap-2 text-sm text-gray-600 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
                            <Award className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />{c}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}

              {/* Experience tab */}
              {activeTab === "experience" && (
                <div className="space-y-3">
                  {expCount === 0 ? (
                    <EmptyState icon={Briefcase} message="No experience entries extracted" />
                  ) : (
                    result.parsed.experience.map((exp, i) => (
                      <div key={i} className="group flex gap-4 p-4 rounded-xl border border-gray-100 hover:border-primary-200 hover:bg-primary-50/30 transition-all">
                        <div className="w-9 h-9 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                          <Briefcase className="w-4 h-4 text-blue-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 flex-wrap">
                            <div>
                              <p className="font-semibold text-gray-900">{exp.role}</p>
                              <p className="text-sm text-primary-600 font-medium">{exp.company}</p>
                            </div>
                            {exp.duration && (
                              <span className="badge-gray text-xs flex-shrink-0">{exp.duration}</span>
                            )}
                          </div>
                          {exp.description && (
                            <p className="text-sm text-gray-500 mt-2 leading-relaxed">{exp.description}</p>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Education tab */}
              {activeTab === "education" && (
                <div className="space-y-3">
                  {eduCount === 0 ? (
                    <EmptyState icon={GraduationCap} message="No education entries extracted" />
                  ) : (
                    result.parsed.education.map((edu, i) => (
                      <div key={i} className="flex gap-4 p-4 rounded-xl border border-gray-100 hover:border-green-200 hover:bg-green-50/30 transition-all">
                        <div className="w-9 h-9 rounded-lg bg-green-100 flex items-center justify-center flex-shrink-0">
                          <GraduationCap className="w-4 h-4 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-gray-900">{edu.degree}</p>
                          <p className="text-sm text-primary-600 font-medium">{edu.institution}</p>
                          <div className="flex gap-3 mt-1.5">
                            {edu.year  && <span className="badge-gray">{edu.year}</span>}
                            {edu.score && <span className="badge-green">Score: {edu.score}</span>}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function EmptyState({ icon: Icon, message }) {
  return (
    <div className="flex flex-col items-center gap-2 py-10 text-center">
      <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">
        <Icon className="w-5 h-5 text-gray-400" />
      </div>
      <p className="text-sm text-gray-400">{message}</p>
    </div>
  );
}
