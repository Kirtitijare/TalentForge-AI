import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getAdminDashboard,
  listAdminUsers,
  getAdminUserProfile,
  deleteUser,
  promoteUser,
  demoteUser,
  listAdminCareers,
  createAdminCareer,
  updateAdminCareer,
  deleteAdminCareer,
  retrainSvdModel,
  listAdminSkills,
  createAdminSkill,
  updateAdminSkill,
  deleteAdminSkill,
  bulkImportSkills,
  listAdminRecs,
  listAdminRatings,
  getAdminMonitorStats
} from "../api/index";
import toast from "react-hot-toast";
import {
  ShieldCheck, Users, Briefcase, TrendingUp, Trash2, ArrowUp, ArrowDown,
  Search, Loader2, Plus, Edit2, RotateCw, Upload, Database, Star,
  Calendar, CheckCircle, AlertTriangle, X, FileText, ChevronRight,
  Sparkles, Award, BarChart3, HelpCircle, Layers, CheckSquare,
  Brain, Cpu, Sliders, Activity, Zap, History
} from "lucide-react";

export default function Admin() {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeTab = searchParams.get("tab") || "dashboard";
  const setActiveTab = (tab) => setSearchParams({ tab });
  const queryClient = useQueryClient();

  // Search & Pagination States
  const [userSearch, setUserSearch] = useState("");
  const [userPage, setUserPage] = useState(1);
  const [userRole, setUserRole] = useState("");
  const [userVerified, setUserVerified] = useState("");

  const [careerSearch, setCareerSearch] = useState("");
  const [careerPage, setCareerPage] = useState(1);

  const [skillSearch, setSkillSearch] = useState("");
  const [skillPage, setSkillPage] = useState(1);
  const [skillCategory, setSkillCategory] = useState("");

  const [recSearch, setRecSearch] = useState("");
  const [recPage, setRecPage] = useState(1);

  const [ratingPage, setRatingPage] = useState(1);

  // Modal States
  const [careerModalOpen, setCareerModalOpen] = useState(false);
  const [editingCareer, setEditingCareer] = useState(null); // null for create, object for edit
  const [careerForm, setCareerForm] = useState({
    jobTitle: "",
    category: "",
    industry: "",
    demandScore: 70,
    averageSalaryLPA: 12.0,
    growthRate: 15.0,
    isTrending: false,
    requiredSkills: "",
    topSkillsRequired: ""
  });

  const [skillModalOpen, setSkillModalOpen] = useState(false);
  const [editingSkill, setEditingSkill] = useState(null); // null for create, object for edit
  const [skillForm, setSkillForm] = useState({
    skillName: "",
    category: "programming",
    aliases: "",
    learningUrl: ""
  });

  const [bulkModalOpen, setBulkModalOpen] = useState(false);
  const [bulkForm, setBulkForm] = useState({
    format: "json",
    data: ""
  });

  // User Profile Inspector Drawer/Modal State
  const [selectedUser, setSelectedUser] = useState(null);
  const [inspectorOpen, setInspectorOpen] = useState(false);

  // --- Queries ---
  const { data: stats, isLoading: isStatsLoading } = useQuery({
    queryKey: ["adminDashboard"],
    queryFn: () => getAdminDashboard().then((r) => r.data.data),
    refetchOnWindowFocus: false,
  });

  const { data: usersData, isLoading: isUsersLoading } = useQuery({
    queryKey: ["adminUsers", userPage, userSearch, userRole, userVerified],
    queryFn: () =>
      listAdminUsers({
        page: userPage,
        perPage: 10,
        search: userSearch,
        role: userRole,
        verified: userVerified
      }).then((r) => r.data.data),
    keepPreviousData: true,
  });

  const { data: careersData, isLoading: isCareersLoading } = useQuery({
    queryKey: ["adminCareers", careerPage, careerSearch],
    queryFn: () =>
      listAdminCareers({
        page: careerPage,
        perPage: 10,
        search: careerSearch
      }).then((r) => r.data.data),
    keepPreviousData: true,
  });

  const { data: skillsData, isLoading: isSkillsLoading } = useQuery({
    queryKey: ["adminSkills", skillPage, skillSearch, skillCategory],
    queryFn: () =>
      listAdminSkills({
        page: skillPage,
        perPage: 15,
        search: skillSearch,
        category: skillCategory
      }).then((r) => r.data.data),
    keepPreviousData: true,
  });

  const { data: recsData, isLoading: isRecsLoading } = useQuery({
    queryKey: ["adminRecs", recPage, recSearch],
    queryFn: () =>
      listAdminRecs({
        page: recPage,
        perPage: 10,
        career: recSearch
      }).then((r) => r.data.data),
    keepPreviousData: true,
  });

  const { data: ratingsData, isLoading: isRatingsLoading } = useQuery({
    queryKey: ["adminRatings", ratingPage],
    queryFn: () =>
      listAdminRatings({
        page: ratingPage,
        perPage: 10
      }).then((r) => r.data.data),
    keepPreviousData: true,
  });

  const { data: monitorStats, isLoading: isMonitorStatsLoading } = useQuery({
    queryKey: ["adminMonitorStats"],
    queryFn: () => getAdminMonitorStats().then((r) => r.data.data),
  });

  const { data: userProfileData, isLoading: isUserProfileLoading } = useQuery({
    queryKey: ["adminUserProfile", selectedUser],
    queryFn: () => getAdminUserProfile(selectedUser).then((r) => r.data.data),
    enabled: !!selectedUser,
  });

  // --- Helpers ---
  const invalidateAll = () => {
    queryClient.invalidateQueries(["adminDashboard"]);
    queryClient.invalidateQueries(["adminUsers"]);
    queryClient.invalidateQueries(["adminCareers"]);
    queryClient.invalidateQueries(["adminSkills"]);
    queryClient.invalidateQueries(["adminRecs"]);
    queryClient.invalidateQueries(["adminRatings"]);
    queryClient.invalidateQueries(["adminMonitorStats"]);
    if (selectedUser) queryClient.invalidateQueries(["adminUserProfile", selectedUser]);
  };

  // --- Mutations ---
  const promoteMutation = useMutation({
    mutationFn: promoteUser,
    onSuccess: (res) => {
      toast.success(res.data.message || "User promoted to admin");
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Failed to promote user"),
  });

  const demoteMutation = useMutation({
    mutationFn: demoteUser,
    onSuccess: (res) => {
      toast.success(res.data.message || "User demoted to regular user");
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Failed to demote user"),
  });

  const deleteUserMutation = useMutation({
    mutationFn: deleteUser,
    onSuccess: (res) => {
      toast.success(res.data.message || "User soft-deleted successfully");
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Failed to delete user"),
  });

  const retrainSvdMutation = useMutation({
    mutationFn: retrainSvdModel,
    onSuccess: (res) => {
      toast.success(res.data.message || "Collaborative filtering SVD retrained successfully!");
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Failed to retrain model"),
  });

  const createCareerMutation = useMutation({
    mutationFn: createAdminCareer,
    onSuccess: (res) => {
      toast.success(res.data.message || "Career role added successfully");
      setCareerModalOpen(false);
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Failed to add career role"),
  });

  const updateCareerMutation = useMutation({
    mutationFn: ({ id, data }) => updateAdminCareer(id, data),
    onSuccess: (res) => {
      toast.success(res.data.message || "Career role updated successfully");
      setCareerModalOpen(false);
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Failed to update career role"),
  });

  const deleteCareerMutation = useMutation({
    mutationFn: deleteAdminCareer,
    onSuccess: (res) => {
      toast.success(res.data.message || "Career role removed successfully");
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Failed to remove career role"),
  });

  const createSkillMutation = useMutation({
    mutationFn: createAdminSkill,
    onSuccess: (res) => {
      toast.success(res.data.message || "Skill added successfully");
      setSkillModalOpen(false);
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Failed to add skill"),
  });

  const updateSkillMutation = useMutation({
    mutationFn: ({ id, data }) => updateAdminSkill(id, data),
    onSuccess: (res) => {
      toast.success(res.data.message || "Skill updated successfully");
      setSkillModalOpen(false);
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Failed to update skill"),
  });

  const deleteSkillMutation = useMutation({
    mutationFn: deleteAdminSkill,
    onSuccess: (res) => {
      toast.success(res.data.message || "Skill removed successfully");
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Failed to remove skill"),
  });

  const bulkImportMutation = useMutation({
    mutationFn: bulkImportSkills,
    onSuccess: (res) => {
      toast.success(res.data.message || "Skills bulk-imported successfully!");
      setBulkModalOpen(false);
      setBulkForm({ format: "json", data: "" });
      invalidateAll();
    },
    onError: (err) => toast.error(err.response?.data?.message || "Bulk import failed. Check format syntax."),
  });

  // --- Handlers ---
  const handleOpenCareerCreate = () => {
    setEditingCareer(null);
    setCareerForm({
      jobTitle: "",
      category: "Technology",
      industry: "General Industry",
      demandScore: 75,
      averageSalaryLPA: 12.5,
      growthRate: 15.0,
      isTrending: false,
      requiredSkills: "",
      topSkillsRequired: ""
    });
    setCareerModalOpen(true);
  };

  const handleOpenCareerEdit = (career) => {
    setEditingCareer(career);
    setCareerForm({
      jobTitle: career.jobTitle,
      category: career.category || "Technology",
      industry: career.industry || "General Industry",
      demandScore: career.demandScore || 50,
      averageSalaryLPA: career.averageSalaryLPA || 0,
      growthRate: career.growthRate || 0,
      isTrending: career.isTrending || false,
      requiredSkills: (career.requiredSkills || []).join(", "),
      topSkillsRequired: (career.topSkillsRequired || []).join(", ")
    });
    setCareerModalOpen(true);
  };

  const handleCareerFormSubmit = (e) => {
    e.preventDefault();
    const payload = {
      ...careerForm,
      requiredSkills: careerForm.requiredSkills.split(",").map(s => s.trim()).filter(Boolean),
      topSkillsRequired: careerForm.topSkillsRequired.split(",").map(s => s.trim()).filter(Boolean)
    };
    if (editingCareer) {
      updateCareerMutation.mutate({ id: editingCareer.id, data: payload });
    } else {
      createCareerMutation.mutate(payload);
    }
  };

  const handleOpenSkillCreate = () => {
    setEditingSkill(null);
    setSkillForm({
      skillName: "",
      category: "programming",
      aliases: "",
      learningUrl: ""
    });
    setSkillModalOpen(true);
  };

  const handleOpenSkillEdit = (skill) => {
    setEditingSkill(skill);
    setSkillForm({
      skillName: skill.skillName,
      category: skill.category || "programming",
      aliases: (skill.aliases || []).join(", "),
      learningUrl: skill.learningUrl || ""
    });
    setSkillModalOpen(true);
  };

  const handleSkillFormSubmit = (e) => {
    e.preventDefault();
    const payload = {
      ...skillForm,
      aliases: skillForm.aliases.split(",").map(s => s.trim()).filter(Boolean)
    };
    if (editingSkill) {
      updateSkillMutation.mutate({ id: editingSkill.id, data: payload });
    } else {
      createSkillMutation.mutate(payload);
    }
  };

  const handleBulkSubmit = (e) => {
    e.preventDefault();
    if (!bulkForm.data.trim()) {
      toast.error("Please paste import data first");
      return;
    }
    bulkImportMutation.mutate(bulkForm);
  };

  const handleInspectUser = (userId) => {
    setSelectedUser(userId);
    setInspectorOpen(true);
  };

  const formatTrainedAt = (isoStr) => {
    if (!isoStr) return "Never Trained";
    const date = new Date(isoStr);
    return date.toLocaleString();
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-16">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-gray-200/60 pb-5">
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 flex items-center gap-3 tracking-tight">
            <ShieldCheck className="w-8 h-8 text-primary-600" /> TalentForge Admin Console
          </h1>
          <p className="text-gray-500 mt-1">Configure systemic variables, manage catalogs, inspect profiles, and trigger recommender retraining.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => { invalidateAll(); toast.success("Refreshed all datasets"); }}
            className="btn-secondary flex items-center gap-2"
          >
            <RotateCw className="w-4 h-4" /> Refresh Telemetry
          </button>
        </div>
      </div>


      {/* TABS CONTENT */}

      {/* 1. DASHBOARD OVERVIEW */}
      {activeTab === "dashboard" && (
        <div className="space-y-8 animate-fadeIn">
          {/* Dashboard Stats Panel */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              { label: "Total Accounts", value: stats?.totalUsers || 0, icon: Users, color: "text-primary-600", desc: `${stats?.adminCount || 0} Admins elevated` },
              { label: "Verified Email Accounts", value: stats?.verifiedUsers || 0, icon: CheckSquare, color: "text-green-600", desc: `${Math.round(((stats?.verifiedUsers || 0) / (stats?.totalUsers || 1)) * 100)}% verification rate` },
              { label: "Recommendations Cached", value: stats?.totalRecommendations || 0, icon: Briefcase, color: "text-indigo-600", desc: `Avg Match Score: ${stats?.avgMatchScore ? `${stats.avgMatchScore}%` : "—"}` },
              { label: "Ratings Logged (SVD)", value: stats?.totalRatings || 0, icon: Star, color: "text-amber-600", desc: `Model Trained: ${stats?.svdLastTrained ? "Active" : "Pending"}` },
            ].map(({ label, value, icon: Icon, color, desc }) => (
              <div key={label} className="card relative overflow-hidden bg-white/70 backdrop-blur-md transition-all hover:-translate-y-0.5 hover:shadow-md">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl bg-gray-50 flex items-center justify-center ${color} border border-gray-100`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div>
                    <p className={`text-2.5xl font-black ${color} tracking-tight`}>{value}</p>
                    <p className="text-xs text-gray-500 font-medium">{label}</p>
                  </div>
                </div>
                {desc && <div className="mt-3.5 pt-2.5 border-t border-gray-100 text-xxs text-gray-400 font-medium flex items-center gap-1"><Sparkles className="w-3 h-3 text-primary-400" /> {desc}</div>}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Col: Registrations Trend (HTML/SVG visual graph) */}
            <div className="card lg:col-span-2 space-y-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary-500" /> Recent Registration Activity
                </h3>
                <p className="text-xs text-gray-500 mt-1">Telemetry showing daily new user account creations in the past 7 days</p>
              </div>

              {stats?.registrationsTimeline?.length > 0 ? (
                <div className="space-y-6">
                  {/* Custom Minimalist Visual SVG Graph */}
                  <div className="relative h-48 w-full border-b border-l border-gray-100 flex items-end justify-between px-4 pb-2">
                    {stats.registrationsTimeline.map((item, idx) => {
                      const maxVal = Math.max(...stats.registrationsTimeline.map(d => d.count), 1);
                      const heightPercent = (item.count / maxVal) * 80; // keep headroom
                      return (
                        <div key={item.date} className="flex flex-col items-center flex-1 group">
                          {/* Tooltip on hover */}
                          <div className="absolute bottom-full mb-2 bg-gray-900 text-white text-xxs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity font-bold">
                            {item.count} users
                          </div>
                          {/* Bar */}
                          <div
                            style={{ height: `${Math.max(heightPercent, 6)}%` }}
                            className={`w-10 rounded-t-md transition-all duration-300 ${
                              item.count > 0 ? "bg-primary-500/80 hover:bg-primary-600" : "bg-gray-100"
                            } border border-transparent hover:shadow`}
                          ></div>
                          <span className="text-xxs text-gray-400 font-semibold mt-2">{item.date}</span>
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-500 bg-gray-50 p-3 rounded-lg border border-gray-100">
                    <span className="font-semibold text-gray-700">Total in last 7 days:</span>
                    <span className="badge-purple font-black text-sm">{stats?.recentRegistrationsCount || 0} registrations</span>
                  </div>
                </div>
              ) : (
                <div className="h-48 flex items-center justify-center text-gray-400 text-sm">No recent activity detected</div>
              )}
            </div>

            {/* Right Col: Extra Entry Stats */}
            <div className="card flex flex-col justify-between">
              <div>
                <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <Database className="w-5 h-5 text-indigo-500" /> Database Catalog Footprint
                </h3>
                <p className="text-xs text-gray-500 mt-1">Live counts of data elements driving the recommendation engine</p>
              </div>

              <div className="space-y-4 my-6">
                {[
                  { label: "Active Career Profiles", value: stats?.careerRolesCount || 0, badge: "market_trends" },
                  { label: "Canonical Skill Matrix", value: stats?.skillsCount || 0, badge: "skill_taxonomy" },
                  { label: "SVD Matrix Trained On", value: `${stats?.totalRatings || 0} ratings`, badge: "career_ratings" }
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between p-3 rounded-lg border border-gray-100/80 bg-gray-50/50 hover:bg-gray-50">
                    <div>
                      <p className="text-sm font-semibold text-gray-700">{item.label}</p>
                      <p className="text-xxs text-gray-400 font-semibold">{item.badge}</p>
                    </div>
                    <span className="text-base font-black text-primary-600">{item.value}</span>
                  </div>
                ))}
              </div>

              <div className="bg-primary-50 border border-primary-100 p-3 rounded-lg text-xxs text-primary-700 font-semibold flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-primary-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">ML Core Telemetry Status</p>
                  <p className="text-primary-600/80 mt-0.5">Collaborative SVD & dense TF-IDF engines connected. Seed datasets successfully validated.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Grids: Top Careers vs Top Skills */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top 5 Careers */}
            <div className="card">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-purple-500" /> Top 5 Recommended Careers
              </h3>
              {stats?.topCareers?.length > 0 ? (
                <div className="space-y-3.5">
                  {stats.topCareers.map((c, i) => (
                    <div key={c.career} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-100">
                      <span className="w-7 h-7 rounded-full bg-primary-100 text-primary-700 text-xs font-black flex items-center justify-center border border-primary-200">
                        {i + 1}
                      </span>
                      <span className="flex-1 text-sm font-semibold text-gray-700">{c.career}</span>
                      <span className="badge-purple font-bold">{c.count} Recommendations</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center py-8 text-sm text-gray-400">No recommendation logs available yet</p>
              )}
            </div>

            {/* Top 10 Skills */}
            <div className="card">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-500" /> Most Common User Skills (Top 10)
              </h3>
              {stats?.topSkills?.length > 0 ? (
                <div className="flex flex-wrap gap-2.5">
                  {stats.topSkills.map((s, i) => (
                    <div
                      key={s.skill}
                      className="flex items-center gap-2.5 bg-gray-50 border border-gray-200/80 rounded-xl px-3.5 py-2 hover:bg-primary-50 hover:border-primary-200 transition-all group"
                    >
                      <span className="text-xxs bg-gray-200/80 group-hover:bg-primary-200 text-gray-600 group-hover:text-primary-800 font-extrabold w-5 h-5 rounded-full flex items-center justify-center transition-colors">
                        {i + 1}
                      </span>
                      <span className="text-xs font-semibold text-gray-700 group-hover:text-primary-900">{s.skill}</span>
                      <span className="text-xxs bg-primary-100/50 text-primary-600 px-1.5 py-0.5 rounded font-black border border-primary-100/50">{s.count} users</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center py-8 text-sm text-gray-400">No skills logged in user accounts</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 2. CAREERS MANAGER */}
      {activeTab === "careers" && (
        <div className="space-y-6 animate-fadeIn">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-gray-100 shadow-xs">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                className="input pl-10"
                placeholder="Search job title, category or industry..."
                value={careerSearch}
                onChange={(e) => { setCareerSearch(e.target.value); setCareerPage(1); }}
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleOpenCareerCreate}
                className="btn-primary flex items-center gap-2"
              >
                <Plus className="w-4 h-4" /> Add Career Role
              </button>
            </div>
          </div>

          <div className="card overflow-hidden p-0 border-gray-200/70">
            {isCareersLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-primary-500" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">Job Title</th>
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">Slug (ML Identifier)</th>
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">Category / Industry</th>
                      <th className="text-center py-3.5 px-4 text-gray-500 font-semibold">Demand Score</th>
                      <th className="text-center py-3.5 px-4 text-gray-500 font-semibold">Average Salary (LPA)</th>
                      <th className="text-center py-3.5 px-4 text-gray-500 font-semibold">Growth Rate</th>
                      <th className="text-center py-3.5 px-4 text-gray-500 font-semibold">Trending</th>
                      <th className="text-right py-3.5 px-4 text-gray-500 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {careersData?.careers?.map((c) => (
                      <tr key={c.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                        <td className="py-4 px-4 font-bold text-gray-900 max-w-xs truncate">{c.jobTitle}</td>
                        <td className="py-4 px-4 font-mono text-xxs text-primary-600 bg-primary-50/30 rounded px-1.5 py-0.5">{c.slug}</td>
                        <td className="py-4 px-4 text-gray-600">
                          <p className="font-semibold text-xs text-gray-800">{c.category}</p>
                          <p className="text-xxs text-gray-400 mt-0.5">{c.industry}</p>
                        </td>
                        <td className="py-4 px-4 text-center">
                          <div className="inline-flex items-center gap-1.5 bg-gray-50 border border-gray-200/80 rounded-lg px-2 py-0.5 text-xs font-black text-gray-700">
                            {c.demandScore}
                          </div>
                        </td>
                        <td className="py-4 px-4 text-center font-bold text-gray-700">₹{c.averageSalaryLPA} LPA</td>
                        <td className="py-4 px-4 text-center text-green-600 font-extrabold">+{c.growthRate}%</td>
                        <td className="py-4 px-4 text-center">
                          <span className={c.isTrending ? "badge-green" : "badge-gray"}>
                            {c.isTrending ? "Active" : "No"}
                          </span>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleOpenCareerEdit(c)}
                              className="p-1.5 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors border border-transparent hover:border-primary-100"
                              title="Edit role properties"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Caution! Deleting the career "${c.jobTitle}" will delete it permanently and soft-delete all saved user recommendations for this path. Proceed?`)) {
                                  deleteCareerMutation.mutate(c.id);
                                }
                              }}
                              className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-100"
                              title="Delete career role"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {!careersData?.careers?.length && (
                      <tr>
                        <td colSpan={8} className="text-center py-16 text-gray-400">No career paths matches found in database.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* Pagination */}
            {careersData?.pages > 1 && (
              <div className="flex items-center justify-between p-4 bg-gray-50 border-t border-gray-100">
                <p className="text-xs font-medium text-gray-500">
                  Showing Page {careerPage} of {careersData.pages}
                </p>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setCareerPage(p => Math.max(1, p - 1))}
                    disabled={careerPage === 1}
                    className="btn-secondary text-xs px-3 py-1.5"
                  >
                    Prev
                  </button>
                  <button
                    onClick={() => setCareerPage(p => Math.min(careersData.pages, p + 1))}
                    disabled={careerPage === careersData.pages}
                    className="btn-secondary text-xs px-3 py-1.5"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. SKILL TAXONOMY MANAGER */}
      {activeTab === "skills" && (
        <div className="space-y-6 animate-fadeIn">
          {/* Internal Subtabs for List vs Bulk Ingestion */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-gray-100 shadow-xs">
            <div className="flex gap-4 flex-1 max-w-2xl">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  className="input pl-10"
                  placeholder="Search skill name or aliases..."
                  value={skillSearch}
                  onChange={(e) => { setSkillSearch(e.target.value); setSkillPage(1); }}
                />
              </div>
              <select
                value={skillCategory}
                onChange={(e) => { setSkillCategory(e.target.value); setSkillPage(1); }}
                className="input max-w-[200px]"
              >
                <option value="">All Categories</option>
                <option value="programming">Programming</option>
                <option value="data">Data Science</option>
                <option value="cloud">Cloud Architecture</option>
                <option value="web">Web Development</option>
                <option value="soft_skill">Soft Skills</option>
              </select>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setBulkModalOpen(true)}
                className="btn-secondary flex items-center gap-2 border-primary-200 text-primary-700 bg-primary-50/50 hover:bg-primary-50"
              >
                <Upload className="w-4 h-4" /> Bulk Import
              </button>
              <button
                onClick={handleOpenSkillCreate}
                className="btn-primary flex items-center gap-2"
              >
                <Plus className="w-4 h-4" /> Add Skill
              </button>
            </div>
          </div>

          <div className="card overflow-hidden p-0 border-gray-200/70">
            {isSkillsLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-primary-500" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">Skill Name</th>
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">Category</th>
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">Aliases (Resume Parser Matches)</th>
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">Learning / Course URL</th>
                      <th className="text-right py-3.5 px-4 text-gray-500 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {skillsData?.skills?.map((s) => (
                      <tr key={s.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                        <td className="py-4 px-4 font-bold text-gray-900">{s.skillName}</td>
                        <td className="py-4 px-4 text-gray-600">
                          <span className="badge-purple font-semibold">{s.category}</span>
                        </td>
                        <td className="py-4 px-4 text-gray-500 max-w-sm">
                          {s.aliases?.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {s.aliases.map((alias) => (
                                <span key={alias} className="text-xxs bg-gray-100 border border-gray-200 text-gray-600 rounded px-1.5 py-0.2">{alias}</span>
                              ))}
                            </div>
                          ) : (
                            <span className="text-gray-300 italic text-xs">No aliases configured</span>
                          )}
                        </td>
                        <td className="py-4 px-4 text-gray-500 max-w-xs truncate">
                          {s.learningUrl ? (
                            <a
                              href={s.learningUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-xs text-primary-600 font-medium hover:underline flex items-center gap-1"
                            >
                              {s.learningUrl} <ChevronRight className="w-3 h-3" />
                            </a>
                          ) : (
                            <span className="text-gray-300 text-xs">No redirect course link</span>
                          )}
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleOpenSkillEdit(s)}
                              className="p-1.5 text-primary-600 hover:bg-primary-50 rounded-lg transition-colors border border-transparent hover:border-primary-100"
                              title="Edit skill details"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Remove "${s.skillName}" from the canonical skill taxonomy? Future resumes matching this word will not map cleanly.`)) {
                                  deleteSkillMutation.mutate(s.id);
                                }
                              }}
                              className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-100"
                              title="Delete skill"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {!skillsData?.skills?.length && (
                      <tr>
                        <td colSpan={5} className="text-center py-16 text-gray-400">No taxonomy skills configured. Click Add Skill to create.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* Pagination */}
            {skillsData?.pages > 1 && (
              <div className="flex items-center justify-between p-4 bg-gray-50 border-t border-gray-100">
                <p className="text-xs font-medium text-gray-500">
                  Showing Page {skillPage} of {skillsData.pages}
                </p>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setSkillPage(p => Math.max(1, p - 1))}
                    disabled={skillPage === 1}
                    className="btn-secondary text-xs px-3 py-1.5"
                  >
                    Prev
                  </button>
                  <button
                    onClick={() => setSkillPage(p => Math.min(skillsData.pages, p + 1))}
                    disabled={skillPage === skillsData.pages}
                    className="btn-secondary text-xs px-3 py-1.5"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4. USER MANAGEMENT */}
      {activeTab === "users" && (
        <div className="space-y-6 animate-fadeIn">
          {/* User Filtering Panel */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 bg-white p-4 rounded-xl border border-gray-100 shadow-xs">
            <div className="relative sm:col-span-2">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                className="input pl-10"
                placeholder="Search user name or email..."
                value={userSearch}
                onChange={(e) => { setUserSearch(e.target.value); setUserPage(1); }}
              />
            </div>
            <select
              value={userRole}
              onChange={(e) => { setUserRole(e.target.value); setUserPage(1); }}
              className="input"
            >
              <option value="">All Roles</option>
              <option value="admin">Admins</option>
              <option value="user">Regular Users</option>
            </select>
            <select
              value={userVerified}
              onChange={(e) => { setUserVerified(e.target.value); setUserPage(1); }}
              className="input"
            >
              <option value="">Verification Status</option>
              <option value="true">Verified Accounts</option>
              <option value="false">Unverified Accounts</option>
            </select>
          </div>

          <div className="card overflow-hidden p-0 border-gray-200/70">
            {isUsersLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-primary-500" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">User Details</th>
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">Email</th>
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">Systemic Role</th>
                      <th className="text-left py-3.5 px-4 text-gray-500 font-semibold">Email Verified</th>
                      <th className="text-center py-3.5 px-4 text-gray-500 font-semibold">Profile Skills</th>
                      <th className="text-right py-3.5 px-4 text-gray-500 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {usersData?.users?.map((u) => (
                      <tr key={u.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-700 font-bold flex items-center justify-center text-xs border border-primary-200">
                              {u.fullName?.[0]?.toUpperCase() || "U"}
                            </div>
                            <div>
                              <p className="font-bold text-gray-900 hover:text-primary-600 cursor-pointer flex items-center gap-1" onClick={() => handleInspectUser(u.id)}>
                                {u.fullName} <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                              </p>
                              <p className="text-xxs text-gray-400 font-medium">ID: {u.id}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-4 text-gray-600 font-medium">{u.email}</td>
                        <td className="py-4 px-4">
                          <span className={u.role === "admin" ? "badge-purple font-bold" : "badge-gray font-semibold"}>
                            {u.role}
                          </span>
                        </td>
                        <td className="py-4 px-4">
                          <span className={u.isEmailVerified ? "badge-green" : "badge-yellow"}>
                            {u.isEmailVerified ? "Verified" : "Pending"}
                          </span>
                        </td>
                        <td className="py-4 px-4 text-center font-bold text-gray-700">
                          {u.profile?.skills?.length || 0} skills
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center justify-end gap-1.5">
                            {u.role !== "admin" ? (
                              <button
                                onClick={() => promoteMutation.mutate(u.id)}
                                className="p-1.5 text-green-600 hover:bg-green-50 rounded-lg transition-colors border border-transparent hover:border-green-100"
                                title="Promote to system Admin"
                              >
                                <ArrowUp className="w-4 h-4" />
                              </button>
                            ) : (
                              <button
                                onClick={() => demoteMutation.mutate(u.id)}
                                className="p-1.5 text-amber-600 hover:bg-amber-50 rounded-lg transition-colors border border-transparent hover:border-amber-100"
                                title="Demote back to regular User"
                              >
                                <ArrowDown className="w-4 h-4" />
                              </button>
                            )}
                            <button
                              onClick={() => {
                                if (confirm(`Caution! Are you absolutely sure you want to soft-delete user "${u.fullName}"? They will lose access to login.`)) {
                                  deleteUserMutation.mutate(u.id);
                                }
                              }}
                              className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-100"
                              title="Delete user account"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {!usersData?.users?.length && (
                      <tr>
                        <td colSpan={6} className="text-center py-16 text-gray-400">No active accounts matching those parameters found in the system.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* Pagination */}
            {usersData?.pages > 1 && (
              <div className="flex items-center justify-between p-4 bg-gray-50 border-t border-gray-100">
                <p className="text-xs font-medium text-gray-500">
                  Showing Page {userPage} of {usersData.pages}
                </p>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setUserPage(p => Math.max(1, p - 1))}
                    disabled={userPage === 1}
                    className="btn-secondary text-xs px-3 py-1.5"
                  >
                    Prev
                  </button>
                  <button
                    onClick={() => setUserPage(p => Math.min(usersData.pages, p + 1))}
                    disabled={userPage === usersData.pages}
                    className="btn-secondary text-xs px-3 py-1.5"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 5. RECOMMENDATIONS & RATINGS MONITOR */}
      {activeTab === "monitor" && (
        <div className="space-y-8 animate-fadeIn">
          {/* Futuristic ML Calibration Command Center */}
          <div className="relative overflow-hidden bg-white/80 backdrop-blur-xl border border-indigo-100/80 rounded-2xl p-6 md:p-8 shadow-sm transition-all hover:shadow-md">
            {/* Ambient background glows */}
            <div className="absolute -top-12 -left-12 w-48 h-48 bg-primary-100/30 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute -bottom-16 -right-16 w-64 h-64 bg-indigo-100/20 rounded-full blur-3xl pointer-events-none"></div>

            <div className="relative flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="space-y-3.5 max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-50 border border-primary-100/80 text-primary-700 text-xs font-semibold animate-pulse">
                  <Activity className="w-3.5 h-3.5 text-primary-600 animate-pulse" />
                  ML Recommendation Subsystem Active
                </div>
                <h3 className="text-2xl font-black text-gray-900 tracking-tight flex items-center gap-3">
                  <Brain className="w-7 h-7 text-primary-600 stroke-[1.75] animate-pulse" />
                  ML Model Orchestration Center
                </h3>
                <p className="text-sm text-gray-600 leading-relaxed font-medium">
                  Re-calibrate latent vectors and user bias fields dynamically across live feedback matrices. Fine-tune singular values using NumPy stochastic gradient descent (SGD) to resolve recommendation cold-starts.
                </p>
                
                {/* Hyperparameters grid */}
                <div className="flex flex-wrap gap-2 pt-1.5">
                  <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gray-50/80 border border-gray-200/50 text-xxs font-bold text-gray-600 shadow-xxs">
                    <Cpu className="w-3.5 h-3.5 text-primary-500" />
                    <span>Algorithm: <strong className="text-gray-900 font-extrabold">NumPy SVD Matrix Factorization</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gray-50/80 border border-gray-200/50 text-xxs font-bold text-gray-600 shadow-xxs">
                    <Sliders className="w-3.5 h-3.5 text-primary-500" />
                    <span>Latent Factors: <strong className="text-gray-900 font-extrabold">50 Dimensions</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gray-50/80 border border-gray-200/50 text-xxs font-bold text-gray-600 shadow-xxs">
                    <Zap className="w-3.5 h-3.5 text-primary-500" />
                    <span>Learning Rate (α): <strong className="text-gray-900 font-extrabold">0.005</strong></span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:items-start lg:items-end justify-center gap-2.5 flex-shrink-0">
                <button
                  onClick={() => retrainSvdMutation.mutate()}
                  disabled={retrainSvdMutation.isPending}
                  className="w-full sm:w-auto relative group overflow-hidden bg-primary-600 hover:bg-primary-700 active:bg-primary-800 disabled:opacity-75 text-white font-bold text-sm px-6 py-3.5 rounded-xl shadow-lg shadow-primary-500/10 hover:shadow-primary-500/25 transition-all duration-300 flex items-center justify-center gap-3 border border-primary-500/20"
                >
                  <span className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></span>
                  {retrainSvdMutation.isPending ? (
                    <>
                      <Loader2 className="w-4.5 h-4.5 animate-spin text-white" />
                      <span>Re-computing Latent Weights...</span>
                    </>
                  ) : (
                    <>
                      <RotateCw className="w-4.5 h-4.5 transition-transform group-hover:rotate-180 duration-500" />
                      <span>Retrain SVD Collaborative Recommender</span>
                    </>
                  )}
                </button>
                <div className="flex items-center gap-2 text-xxs text-gray-400 font-semibold self-center lg:self-end">
                  <Calendar className="w-3.5 h-3.5 text-gray-300" />
                  <span>Last Model Sync: <strong className="text-gray-600 font-bold">{formatTrainedAt(monitorStats?.svdLastTrained || stats?.svdLastTrained)}</strong></span>
                </div>
              </div>
            </div>

            {/* Performance/Telemetry Instrument Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mt-8 pt-8 border-t border-indigo-100/60">
              {/* Telemetry card A: Ratings Distribution */}
              <div className="relative group bg-white/90 p-5 rounded-xl border border-gray-200/50 shadow-xxs hover:border-primary-200 hover:shadow-xs transition-all duration-200">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <p className="text-xxs font-extrabold text-gray-400 uppercase tracking-widest">Database Bootstrap Index</p>
                    <p className="text-3xl font-black text-gray-900 tracking-tight">
                      {monitorStats?.totalRatings || 0}
                    </p>
                    <p className="text-xxs text-gray-500 font-semibold">Total Logged Star Ratings</p>
                  </div>
                  <div className="p-2 rounded-lg bg-indigo-50 border border-indigo-100/50 text-primary-600">
                    <Database className="w-4.5 h-4.5 stroke-[1.75]" />
                  </div>
                </div>

                {/* Gorgeous ratio indicator */}
                <div className="mt-5 space-y-2">
                  <div className="flex items-center justify-between text-xxs font-bold text-gray-600">
                    <span className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-primary-500"></span>
                      {monitorStats?.realPercentage || 0}% Real Feedback
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                      {monitorStats?.syntheticPercentage || 0}% Synthetic
                    </span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2.5 flex overflow-hidden border border-gray-100 shadow-inner">
                    <div style={{ width: `${monitorStats?.realPercentage || 0}%` }} className="bg-primary-500 h-full transition-all duration-500"></div>
                    <div style={{ width: `${monitorStats?.syntheticPercentage || 0}%` }} className="bg-emerald-400 h-full transition-all duration-500"></div>
                  </div>
                  <p className="text-xxs text-gray-400 leading-normal">
                    Real ratings provide personalization triggers; synthetic bootstrap indices secure initialization vectors.
                  </p>
                </div>
              </div>

              {/* Telemetry card B: Recommendation Hits */}
              <div className="relative group bg-white/90 p-5 rounded-xl border border-gray-200/50 shadow-xxs hover:border-primary-200 hover:shadow-xs transition-all duration-200 flex flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <p className="text-xxs font-extrabold text-gray-400 uppercase tracking-widest">Recommendation Volume</p>
                      <p className="text-3xl font-black text-gray-900 tracking-tight">
                        {stats?.totalRecommendations || 0}
                      </p>
                      <p className="text-xxs text-gray-500 font-semibold">Active Pipeline Outputs</p>
                    </div>
                    <div className="p-2 rounded-lg bg-amber-50 border border-amber-100/50 text-amber-600">
                      <Sparkles className="w-4.5 h-4.5 stroke-[1.75]" />
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-3.5 border-t border-gray-100 text-xxs text-gray-500 leading-relaxed font-semibold">
                  Average compatibility matching calculates at{" "}
                  <span className="px-1.5 py-0.5 rounded bg-primary-50 border border-primary-100 text-primary-700 font-bold inline-flex items-center">
                    {stats?.avgMatchScore || 0}%
                  </span>{" "}
                  suitability efficiency mapped across the skill taxonomy.
                </div>
              </div>

              {/* Telemetry card C: Collaborative Filtering State */}
              <div className="relative group bg-white/90 p-5 rounded-xl border border-gray-200/50 shadow-xxs hover:border-primary-200 hover:shadow-xs transition-all duration-200 flex flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <p className="text-xxs font-extrabold text-gray-400 uppercase tracking-widest">Signal Reliability</p>
                      <div className="flex items-center gap-2.5 mt-2">
                        <span className="relative flex h-3 w-3">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-50"></span>
                        </span>
                        <span className="font-extrabold text-sm text-emerald-700">Online Telemetry Stable</span>
                      </div>
                    </div>
                    <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-100/50 text-emerald-600">
                      <ShieldCheck className="w-4.5 h-4.5 stroke-[1.75]" />
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-3.5 border-t border-gray-100 text-xxs text-gray-500 leading-relaxed font-semibold">
                  SVD active. Matrix trained on dense feedback loop. Synced dynamically with system recommenders.
                </div>
              </div>
            </div>
          </div>

          {/* Main Monitor Metrics Split Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left: Ratings distribution chart */}
            <div className="card bg-white border border-gray-200/60 shadow-sm rounded-2xl flex flex-col p-5">
              <div className="border-b border-gray-100 pb-4 mb-4">
                <h4 className="text-base font-extrabold text-gray-900 flex items-center gap-2">
                  <BarChart3 className="w-4.5 h-4.5 text-primary-600 stroke-[1.75]" />
                  Career Ratings Rankings
                </h4>
                <p className="text-xxs text-gray-400 mt-0.5 font-medium">Average feedback score rating per career catalog element</p>
              </div>

              <div className="space-y-2.5 overflow-y-auto max-h-[460px] pr-1.5 flex-1">
                {monitorStats?.distribution?.length > 0 ? (
                  monitorStats.distribution.map((item) => (
                    <div
                      key={item.careerSlug}
                      className="group flex flex-col gap-2 p-3 bg-gray-50/50 hover:bg-white rounded-xl border border-gray-200/40 hover:border-primary-100 hover:shadow-xxs transition-all duration-200"
                    >
                      <div className="flex items-center justify-between text-xs font-semibold">
                        <span className="text-gray-700 font-bold truncate max-w-[190px]" title={item.careerTitle}>
                          {item.careerTitle}
                        </span>
                        <div className="flex items-center gap-1 font-black text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-100 text-xxs">
                          <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                          <span>{item.averageRating ? parseFloat(item.averageRating).toFixed(2) : "0.00"}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 text-xxs text-gray-500 font-medium">
                        <div className="flex-1 bg-gray-200/60 rounded-full h-2 overflow-hidden border border-gray-100">
                          <div
                            style={{ width: `${(item.averageRating / 5) * 100}%` }}
                            className="bg-gradient-to-r from-amber-400 to-amber-500 h-full rounded-full transition-all duration-500"
                          ></div>
                        </div>
                        <span className="font-bold flex-shrink-0 text-gray-400 group-hover:text-primary-600 transition-colors">
                          {item.count} {item.count === 1 ? 'response' : 'responses'}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="flex flex-col items-center justify-center py-20 text-center text-gray-400 space-y-3">
                    <div className="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center border border-gray-100 text-gray-300">
                      <BarChart3 className="w-5 h-5 stroke-[1.5]" />
                    </div>
                    <p className="text-xs font-semibold text-gray-400">No rating metrics compiled yet</p>
                  </div>
                )}
              </div>
            </div>

            {/* Right: Live Ratings log feed */}
            <div className="card bg-white border border-gray-200/60 shadow-sm rounded-2xl lg:col-span-2 flex flex-col justify-between p-5">
              <div className="space-y-4">
                <div className="border-b border-gray-100 pb-4 flex items-center justify-between">
                  <div>
                    <h4 className="text-base font-extrabold text-gray-900 flex items-center gap-2">
                      <History className="w-4.5 h-4.5 text-primary-600 stroke-[1.75]" />
                      Ratings Transaction Logs
                    </h4>
                    <p className="text-xxs text-gray-400 mt-0.5 font-medium">Chronological record of career star ratings submitted across the app</p>
                  </div>
                </div>

                <div className="overflow-hidden border border-gray-200/60 rounded-xl">
                  {isRatingsLoading ? (
                    <div className="flex flex-col items-center justify-center py-24 gap-3">
                      <Loader2 className="w-8 h-8 animate-spin text-primary-500" />
                      <p className="text-xxs font-bold text-gray-400">Loading transaction logs...</p>
                    </div>
                  ) : ratingsData?.ratings?.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="bg-gray-50/70 border-b border-gray-100/80">
                            <th className="text-left py-3 px-4 text-gray-500 font-bold uppercase tracking-wider text-xxs">User</th>
                            <th className="text-left py-3 px-4 text-gray-500 font-bold uppercase tracking-wider text-xxs">Career Role</th>
                            <th className="text-center py-3 px-4 text-gray-500 font-bold uppercase tracking-wider text-xxs">Stars</th>
                            <th className="text-center py-3 px-4 text-gray-500 font-bold uppercase tracking-wider text-xxs">Source</th>
                            <th className="text-right py-3 px-4 text-gray-500 font-bold uppercase tracking-wider text-xxs">Logged At</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100/60">
                          {ratingsData.ratings.map((r) => {
                            const initials = r.userFullName
                              ? r.userFullName.split(" ").map(n => n[0]).join("").substring(0, 2).toUpperCase()
                              : "US";
                            return (
                              <tr key={r.id} className="hover:bg-gray-50/40 transition-colors duration-150">
                                <td className="py-3 px-4">
                                  <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary-100 to-indigo-100 border border-primary-200 flex items-center justify-center text-primary-700 text-xxs font-extrabold shadow-xxs flex-shrink-0">
                                      {initials}
                                    </div>
                                    <div>
                                      <p className="font-bold text-gray-800">{r.userFullName}</p>
                                      <p className="text-xxs text-gray-400 font-medium">{r.userEmail}</p>
                                    </div>
                                  </div>
                                </td>
                                <td className="py-3 px-4">
                                  <span className="font-mono text-primary-600 font-bold px-2 py-1 bg-primary-50 rounded-lg text-xxs border border-primary-100/50">
                                    {r.careerSlug}
                                  </span>
                                </td>
                                <td className="py-3 px-4 text-center">
                                  <div className="inline-flex items-center gap-1 font-extrabold text-amber-600 bg-amber-50 rounded-lg px-2.5 py-0.5 border border-amber-100 text-xxs">
                                    <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                                    <span>{r.rating}</span>
                                  </div>
                                </td>
                                <td className="py-3 px-4 text-center">
                                  <span className={r.source === "synthetic" ? "badge-yellow font-bold" : "badge-green font-bold"}>
                                    {r.source}
                                  </span>
                                </td>
                                <td className="py-3 px-4 text-right text-gray-400 font-semibold text-xxs">
                                  {r.createdAt ? new Date(r.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : "—"}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-20 text-center px-4 bg-gray-50/20">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-primary-600 mb-3 shadow-sm">
                        <FileText className="w-5.5 h-5.5 stroke-[1.75]" />
                      </div>
                      <h5 className="text-sm font-bold text-gray-900">No ratings transaction logs found</h5>
                      <p className="text-xxs text-gray-400 max-w-xs mt-1 leading-relaxed">
                        No telemetry logs are currently logged in the ledger. Active ratings from users will trigger real-time collaborative SVD feedback items here.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Rating Pagination */}
              {ratingsData?.pages > 1 && (
                <div className="flex items-center justify-between p-4 bg-gray-50/60 border-t border-gray-100 mt-4 rounded-b-2xl text-xxs font-bold">
                  <span className="text-gray-500">Page {ratingPage} of {ratingsData.pages}</span>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => setRatingPage(p => Math.max(1, p - 1))}
                      disabled={ratingPage === 1}
                      className="btn-secondary px-3 py-1.5 text-xxs font-bold"
                    >
                      Prev
                    </button>
                    <button
                      onClick={() => setRatingPage(p => Math.min(ratingsData.pages, p + 1))}
                      disabled={ratingPage === ratingsData.pages}
                      className="btn-secondary px-3 py-1.5 text-xxs font-bold"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- MODAL WIDGETS --- */}

      {/* Career CRUD Modal */}
      {careerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-gray-100 overflow-hidden my-8 animate-slideUp">
            <div className="flex items-center justify-between px-6 py-4.5 bg-gray-50 border-b border-gray-100">
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                {editingCareer ? <Edit2 className="w-5 h-5 text-primary-600" /> : <Plus className="w-5 h-5 text-primary-600" />}
                {editingCareer ? `Edit Career: ${editingCareer.jobTitle}` : "Create New Career Catalog Role"}
              </h3>
              <button onClick={() => setCareerModalOpen(false)} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCareerFormSubmit} className="p-6 space-y-5">
              {editingCareer && (
                <div className="bg-amber-50 border border-amber-100 p-3.5 rounded-xl text-xxs text-amber-800 font-semibold flex gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold uppercase tracking-wider">Recommendation Invalidation Warning</p>
                    <p className="mt-0.5">Changing the <strong>Required Skills</strong> set below will instantly delete all current user recommendation records cache matching this role, forcing users to regenerate fresh paths.</p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="label">Job Title*</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Prompt Engineer"
                    value={careerForm.jobTitle}
                    onChange={(e) => setCareerForm({ ...careerForm, jobTitle: e.target.value })}
                    className="input"
                  />
                </div>
                <div>
                  <label className="label">Category*</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Technology"
                    value={careerForm.category}
                    onChange={(e) => setCareerForm({ ...careerForm, category: e.target.value })}
                    className="input"
                  />
                </div>
                <div>
                  <label className="label">Industry*</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. FinTech"
                    value={careerForm.industry}
                    onChange={(e) => setCareerForm({ ...careerForm, industry: e.target.value })}
                    className="input"
                  />
                </div>
                <div>
                  <label className="label">Demand Score (0-100)*</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    required
                    value={careerForm.demandScore}
                    onChange={(e) => setCareerForm({ ...careerForm, demandScore: parseInt(e.target.value) })}
                    className="input"
                  />
                </div>
                <div>
                  <label className="label">Average Salary LPA (₹)*</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={careerForm.averageSalaryLPA}
                    onChange={(e) => setCareerForm({ ...careerForm, averageSalaryLPA: parseFloat(e.target.value) })}
                    className="input"
                  />
                </div>
                <div>
                  <label className="label">Growth Rate (% YoY)*</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={careerForm.growthRate}
                    onChange={(e) => setCareerForm({ ...careerForm, growthRate: parseFloat(e.target.value) })}
                    className="input"
                  />
                </div>
              </div>

              <div>
                <label className="label">Trending Option</label>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="isTrendingCheck"
                    checked={careerForm.isTrending}
                    onChange={(e) => setCareerForm({ ...careerForm, isTrending: e.target.checked })}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 h-4 w-4"
                  />
                  <label htmlFor="isTrendingCheck" className="text-sm text-gray-700 font-semibold select-none cursor-pointer">
                    Flag as Currently Trending in the job market
                  </label>
                </div>
              </div>

              <div>
                <label className="label">Required Skills (Comma separated list)*</label>
                <textarea
                  required
                  rows="2"
                  placeholder="e.g. Python, Large Language Models, PyTorch, Prompt Design"
                  value={careerForm.requiredSkills}
                  onChange={(e) => setCareerForm({ ...careerForm, requiredSkills: e.target.value })}
                  className="input"
                ></textarea>
                <span className="text-xxs text-gray-400 mt-1 font-semibold block">Feed ML vector matches. Provide canonical taxonomy names for precision matching.</span>
              </div>

              <div>
                <label className="label">Top Extra Skills (Comma separated list)</label>
                <textarea
                  rows="2"
                  placeholder="e.g. ChatGPT API, LangChain, Fine-tuning"
                  value={careerForm.topSkillsRequired}
                  onChange={(e) => setCareerForm({ ...careerForm, topSkillsRequired: e.target.value })}
                  className="input"
                ></textarea>
              </div>

              <div className="flex justify-end gap-2.5 pt-4 border-t border-gray-100">
                <button type="button" onClick={() => setCareerModalOpen(false)} className="btn-secondary">
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createCareerMutation.isPending || updateCareerMutation.isPending}
                  className="btn-primary"
                >
                  {(createCareerMutation.isPending || updateCareerMutation.isPending) && <Loader2 className="w-4 h-4 animate-spin" />}
                  Save Career Role
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Skill CRUD Modal */}
      {skillModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-gray-100 overflow-hidden my-8 animate-slideUp">
            <div className="flex items-center justify-between px-6 py-4.5 bg-gray-50 border-b border-gray-100">
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                {editingSkill ? <Edit2 className="w-5 h-5 text-primary-600" /> : <Plus className="w-5 h-5 text-primary-600" />}
                {editingSkill ? `Edit Taxonomy Skill` : "Add Canonical Taxonomy Skill"}
              </h3>
              <button onClick={() => setSkillModalOpen(false)} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSkillFormSubmit} className="p-6 space-y-4">
              <div>
                <label className="label">Skill Name*</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. LangChain"
                  value={skillForm.skillName}
                  onChange={(e) => setSkillForm({ ...skillForm, skillName: e.target.value })}
                  className="input"
                />
              </div>

              <div>
                <label className="label">Category*</label>
                <select
                  required
                  value={skillForm.category}
                  onChange={(e) => setSkillForm({ ...skillForm, category: e.target.value })}
                  className="input"
                >
                  <option value="programming">programming</option>
                  <option value="data">data</option>
                  <option value="cloud">cloud</option>
                  <option value="web">web</option>
                  <option value="soft_skill">soft_skill</option>
                </select>
              </div>

              <div>
                <label className="label">Aliases (Comma separated)</label>
                <input
                  type="text"
                  placeholder="e.g. langchain, lang chain, langchain-py"
                  value={skillForm.aliases}
                  onChange={(e) => setSkillForm({ ...skillForm, aliases: e.target.value })}
                  className="input"
                />
                <span className="text-xxs text-gray-400 mt-1 font-semibold block">Aliases help the resume parser normalize alternate phrasing.</span>
              </div>

              <div>
                <label className="label">Learning / Course URL</label>
                <input
                  type="url"
                  placeholder="e.g. https://www.coursera.org/learn/langchain"
                  value={skillForm.learningUrl}
                  onChange={(e) => setSkillForm({ ...skillForm, learningUrl: e.target.value })}
                  className="input"
                />
                <span className="text-xxs text-gray-400 mt-1 font-semibold block">Hyperlink shown inside user Skill Gap curricula pathways.</span>
              </div>

              <div className="flex justify-end gap-2.5 pt-4 border-t border-gray-100">
                <button type="button" onClick={() => setSkillModalOpen(false)} className="btn-secondary">
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createSkillMutation.isPending || updateSkillMutation.isPending}
                  className="btn-primary"
                >
                  {(createSkillMutation.isPending || updateSkillMutation.isPending) && <Loader2 className="w-4 h-4 animate-spin" />}
                  Save Skill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bulk Import Modal */}
      {bulkModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-gray-100 overflow-hidden my-8 animate-slideUp">
            <div className="flex items-center justify-between px-6 py-4 bg-gray-50 border-b border-gray-100">
              <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                <Upload className="w-5 h-5 text-primary-600" /> Bulk Ingest Canonical Skills
              </h3>
              <button onClick={() => setBulkModalOpen(false)} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBulkSubmit} className="p-6 space-y-4">
              <div>
                <label className="label">Choose Ingestion Data Format</label>
                <div className="flex gap-4">
                  {["json", "csv"].map((fmt) => (
                    <label key={fmt} className="flex items-center gap-2 cursor-pointer text-sm font-bold text-gray-700 uppercase">
                      <input
                        type="radio"
                        name="bulkFormat"
                        value={fmt}
                        checked={bulkForm.format === fmt}
                        onChange={() => setBulkForm({ ...bulkForm, format: fmt })}
                        className="text-primary-600 focus:ring-primary-500 h-4 w-4"
                      />
                      {fmt} Format
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="label">Data Payload</label>
                <textarea
                  rows="10"
                  required
                  placeholder={
                    bulkForm.format === "json"
                      ? '[\n  {\n    "skillName": "React Native",\n    "category": "web",\n    "aliases": "reactnative, react-native",\n    "learningUrl": "https://reactnative.dev"\n  }\n]'
                      : "skill_name,category,aliases,learning_url\nReact Native,web,reactnative,https://reactnative.dev"
                  }
                  value={bulkForm.data}
                  onChange={(e) => setBulkForm({ ...bulkForm, data: e.target.value })}
                  className="input font-mono text-xs whitespace-pre bg-gray-50/50"
                ></textarea>
                <span className="text-xxs text-gray-400 mt-1 font-semibold block">Paste headers matching skill_name, category, aliases, learning_url. Existing skill names will be skipped automatically to avoid duplicates.</span>
              </div>

              <div className="flex justify-end gap-2.5 pt-4 border-t border-gray-100">
                <button type="button" onClick={() => setBulkModalOpen(false)} className="btn-secondary">
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={bulkImportMutation.isPending}
                  className="btn-primary"
                >
                  {bulkImportMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
                  Execute Bulk Ingestion
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- USER DETAILS INSPECTOR PANEL (Sliding Modal) --- */}
      {inspectorOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-black/40 backdrop-blur-xs flex justify-end">
          <div className="bg-white max-w-2xl w-full h-full shadow-2xl border-l border-gray-200 overflow-y-auto p-6 space-y-6 flex flex-col justify-between animate-slideLeft">
            
            {/* Inspector Header */}
            <div>
              <div className="flex items-center justify-between border-b border-gray-200 pb-4">
                <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                  <Users className="w-6 h-6 text-primary-600" /> User Profile Inspector
                </h3>
                <button
                  onClick={() => { setInspectorOpen(false); setSelectedUser(null); }}
                  className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-100 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {isUserProfileLoading ? (
                <div className="flex items-center justify-center py-24">
                  <Loader2 className="w-8 h-8 animate-spin text-primary-500" />
                </div>
              ) : userProfileData ? (
                <div className="space-y-6 mt-6">
                  {/* General Profile card */}
                  <div className="bg-gray-50 p-4.5 rounded-xl border border-gray-100 space-y-4">
                    <div className="flex items-center gap-3.5">
                      <div className="w-11 h-11 rounded-full bg-primary-100 text-primary-700 font-bold flex items-center justify-center text-sm border border-primary-200">
                        {userProfileData.fullName?.[0]?.toUpperCase() || "U"}
                      </div>
                      <div>
                        <h4 className="font-extrabold text-base text-gray-900">{userProfileData.fullName}</h4>
                        <p className="text-xs text-gray-500 font-semibold">{userProfileData.email}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-xs pt-3 border-t border-gray-200/60 font-semibold text-gray-600">
                      <div>
                        <span className="text-xxs text-gray-400 block uppercase font-bold">Account Role</span>
                        <span className={`inline-block mt-0.5 ${userProfileData.role === "admin" ? "badge-purple" : "badge-gray"}`}>{userProfileData.role}</span>
                      </div>
                      <div>
                        <span className="text-xxs text-gray-400 block uppercase font-bold">Email Verified</span>
                        <span className={`inline-block mt-0.5 ${userProfileData.isEmailVerified ? "badge-green" : "badge-yellow"}`}>{userProfileData.isEmailVerified ? "Yes" : "No"}</span>
                      </div>
                      <div>
                        <span className="text-xxs text-gray-400 block uppercase font-bold">Experience Horizon</span>
                        <span className="text-gray-800 font-black text-sm block mt-0.5">{userProfileData.experienceYears || 0} Years</span>
                      </div>
                      <div>
                        <span className="text-xxs text-gray-400 block uppercase font-bold">Joined Date</span>
                        <span className="text-gray-700 block mt-0.5">{userProfileData.createdAt ? new Date(userProfileData.createdAt).toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' }) : "—"}</span>
                      </div>
                    </div>
                  </div>

                  {/* Career Goal */}
                  <div className="card space-y-2">
                    <span className="text-xxs text-gray-400 uppercase font-bold block">Designated Objectives / Goals</span>
                    <p className="text-sm font-semibold text-gray-700 italic">
                      "{userProfileData.goals || "No objectives declared yet"}"
                    </p>
                  </div>

                  {/* Registered Skills list */}
                  <div className="card space-y-3">
                    <span className="text-xxs text-gray-400 uppercase font-bold block">Associated Profile Skills ({userProfileData.profile?.skills?.length || 0})</span>
                    {userProfileData.profile?.skills?.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5">
                        {userProfileData.profile.skills.map((skill) => (
                          <span key={skill} className="text-xs bg-primary-50 text-primary-700 border border-primary-100 rounded px-2.5 py-0.5 font-semibold">{skill}</span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-gray-400 italic">No skills registered on profile</p>
                    )}
                  </div>

                  {/* Recommendations */}
                  <div className="card space-y-3">
                    <span className="text-xxs text-gray-400 uppercase font-bold block">Generated Recommendation Scores ({userProfileData.recommendations?.length || 0})</span>
                    {userProfileData.recommendations?.length > 0 ? (
                      <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                        {userProfileData.recommendations.map((rec) => (
                          <div key={rec.id} className="flex items-center justify-between text-xs p-2.5 rounded-lg border border-gray-100 bg-gray-50/50">
                            <div>
                              <p className="font-bold text-gray-800">{rec.careerTitle}</p>
                              <p className="text-xxs text-gray-400">Match score computed via Dense NCF & SVD</p>
                            </div>
                            <span className="badge-purple font-black text-xs">{rec.matchPercentage}% match</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-gray-400 italic">No recommendations run for this user yet</p>
                    )}
                  </div>

                  {/* Star Ratings */}
                  <div className="card space-y-3">
                    <span className="text-xxs text-gray-400 uppercase font-bold block">Submitted Star Ratings ({userProfileData.ratings?.length || 0})</span>
                    {userProfileData.ratings?.length > 0 ? (
                      <div className="flex flex-wrap gap-2 max-h-[120px] overflow-y-auto">
                        {userProfileData.ratings.map((rt) => (
                          <div key={rt.id} className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-100 text-xxs font-bold px-2 py-1 rounded">
                            <span className="truncate max-w-[80px]" title={rt.careerSlug}>{rt.careerSlug}</span>
                            <span className="flex items-center font-extrabold text-amber-600"><Star className="w-3 h-3 fill-amber-500 text-amber-500" /> {rt.rating}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-gray-400 italic">User has not evaluated any recommended paths yet</p>
                    )}
                  </div>

                  {/* Parsed Resume Data JSON */}
                  <div className="card space-y-3">
                    <div className="flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-gray-400" />
                      <span className="text-xxs text-gray-400 uppercase font-bold block">Inferred Resume Data (LLM Sectioning)</span>
                    </div>
                    {userProfileData.parsedResumeJson ? (
                      <div className="bg-gray-900 text-green-400 font-mono text-xxs p-4.5 rounded-xl whitespace-pre overflow-x-auto max-h-[180px] scrollbar-thin">
                        {JSON.stringify(userProfileData.parsedResumeJson, null, 2)}
                      </div>
                    ) : (
                      <p className="text-xs text-gray-400 italic">No parsed resume JSON present. User hasn't uploaded resume.</p>
                    )}
                  </div>
                </div>
              ) : (
                <p className="text-center py-20 text-sm text-gray-400">Failed to compile user details.</p>
              )}
            </div>

            {/* Inspector Footer */}
            <div className="border-t border-gray-200 pt-4 flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => { setInspectorOpen(false); setSelectedUser(null); }}
                className="btn-secondary w-full"
              >
                Close Profile Inspection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
