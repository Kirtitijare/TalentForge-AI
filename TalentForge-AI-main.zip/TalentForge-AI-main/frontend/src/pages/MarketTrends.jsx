import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { getMarketTrends, getTopSkills, getSkillDemandScores } from "../api/index";
import {
  ComposedChart, AreaChart, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Line, Legend, Area
} from "recharts";
import { 
  TrendingUp, Loader2, Flame, Search, Globe, Trophy, Sparkles, Award, Shield, 
  Landmark, Compass, CheckCircle, RefreshCw, Briefcase, ChevronRight
} from "lucide-react";

export default function MarketTrends() {
  const { data: trendsData, isLoading } = useQuery({
    queryKey: ["marketTrends"],
    queryFn: () => getMarketTrends().then((r) => r.data.data.trends),
  });
  const { data: skillsData } = useQuery({
    queryKey: ["topSkills"],
    queryFn: () => getTopSkills(12).then((r) => r.data.data.skills),
  });
  const { data: skillDemandData } = useQuery({
    queryKey: ["skillDemand"],
    queryFn: () => getSkillDemandScores().then((r) => r.data.data.skills),
  });

  const trends = trendsData || [];
  const skills = skillsData || [];
  const skillDemand = skillDemandData || [];

  // Sector and Query Search States
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSkillFilter, setSelectedSkillFilter] = useState(null);

  // Live Stream Log telemetry state
  const [liveLogs, setLiveLogs] = useState([
    "Established secure telemetry link with Postgres Global Index...",
    "Analyzing 1,428 live job postings across Tech & FinTech sectors",
    "System integrity active: Machine learning confidence score nominal"
  ]);

  // Periodic Simulated Ingestions Ticker
  useEffect(() => {
    const LOG_TEMPLATES = [
      "DEMAND SURGE: AI/ML Engineer listings in Bengaluru saw a +3.2% salary surge",
      "NEW JOB POSTING: Senior Cloud Architect uploaded by Technical Partners (₹32 LPA)",
      "GROWTH TICK: Prompt Engineering growth rate calibrated to +60% YoY acceleration",
      "SKILL SIGNAL: Kubernetes demand weight in DevOps increased by +1.9% in enterprise boards",
      "SEC COMPLIANCE: Cybersecurity vacancy matching in Finance sector is active",
      "VALUE MULTIPLIER: Python + PyTorch combination value calculated at 1.48x high synergy",
      "DEV RADAR: Full Stack developer listings rose (+18 new listings detected)",
      "UI/UX DESIGN: Average Figma skill demand reached new 2026 high in product firms",
      "SMART CONTRACTS: Solidity expert roles posted in FinTech (Average ₹26 LPA)",
      "METRIC UPDATE: Technology sector average hiring confidence index hit 94.5 points"
    ];

    const timer = setInterval(() => {
      const randomLog = LOG_TEMPLATES[Math.floor(Math.random() * LOG_TEMPLATES.length)];
      const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLiveLogs(prev => [`[${timestamp}] ${randomLog}`, ...prev.slice(0, 4)]);
    }, 4500);

    return () => clearInterval(timer);
  }, []);

  // Filter trends data reactively based on UI states
  const filteredTrends = useMemo(() => {
    return trends.filter(t => {
      // 1. Sector Category Filter
      let catMatch = true;
      if (selectedCategory !== "All") {
        if (selectedCategory === "AI & Data") catMatch = t.category === "AI & Data";
        else if (selectedCategory === "Cloud") catMatch = t.category === "Cloud";
        else if (selectedCategory === "Security & Web3") catMatch = t.category === "Security" || t.category === "Web3";
        else if (selectedCategory === "Dev & Design") catMatch = t.category === "Web Dev" || t.category === "Design";
        else if (selectedCategory === "Hardware & Management") catMatch = t.category === "Hardware" || t.category === "Management";
      }

      // 2. Search Query Input Matching
      const q = searchQuery.toLowerCase();
      const searchMatch = !searchQuery || 
        t.jobTitle.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.industry.toLowerCase().includes(q) ||
        (t.topSkillsRequired || []).some(s => s.toLowerCase().includes(q));

      // 3. Skill Tag Filter Selection
      const skillMatch = !selectedSkillFilter ||
        (t.topSkillsRequired || []).includes(selectedSkillFilter);

      return catMatch && searchMatch && skillMatch;
    });
  }, [trends, selectedCategory, searchQuery, selectedSkillFilter]);

  // Compute stats aggregates based on fetched data
  const stats = useMemo(() => {
    if (trends.length === 0) return { totalIngested: 1428, peakSalary: 32, avgGrowth: 28.5, trendingCount: 6 };
    const peakSalary = Math.max(...trends.map(t => t.averageSalaryLPA));
    const avgGrowth = (trends.reduce((acc, t) => acc + t.growthRate, 0) / trends.length).toFixed(1);
    const trendingCount = trends.filter(t => t.isTrending).length;
    return {
      totalIngested: 1428 + (liveLogs.length * 3),
      peakSalary,
      avgGrowth,
      trendingCount
    };
  }, [trends, liveLogs]);

  // Prepare chart formats
  const chartData = filteredTrends.map((t) => ({
    name: t.jobTitle.replace(" Engineer", " Eng.").replace(" Developer", " Dev.").replace(" Specialist", " Spec."),
    demand: t.demandScore,
    salary: t.averageSalaryLPA,
    growth: t.growthRate,
  }));

  const radarData = skillDemand.slice(0, 8).map((s) => ({
    skill: s.skill,
    demand: s.demandScore,
  }));

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-32 space-y-4 max-w-6xl mx-auto">
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-indigo-500/10 blur-xl w-16 h-16 animate-pulse" />
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600" />
        </div>
        <p className="text-base text-slate-655 font-bold animate-pulse">Establishing real-time market data indexes...</p>
        <p className="text-xs text-slate-400">Syncing telemetry logs & active job board catalogs</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fadeIn text-slate-800 pb-12">
      {/* Premium Glow Header */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-indigo-50/90 via-white to-sky-50/60 text-slate-800 p-8 md:p-10 shadow-lg border border-indigo-100/85 shadow-indigo-100/10">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-indigo-400/5 rounded-full blur-[100px] pointer-events-none animate-pulse" />
        <div className="absolute -bottom-20 -left-20 w-[300px] h-[300px] bg-sky-400/5 rounded-full blur-[80px] pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-4 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-100/80 hover:bg-indigo-200/80 text-indigo-700 text-xs font-black tracking-wider border border-indigo-200/60 transition-all shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-spin" style={{ animationDuration: '4s' }} /> 
              <span>LIVE GLOBAL MARKET INDEX</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-tight bg-gradient-to-r from-slate-900 via-indigo-950 to-indigo-900 bg-clip-text text-transparent">
              Real-time Market Telemetry
            </h1>
            <p className="text-slate-600 text-sm md:text-base font-medium leading-relaxed max-w-2xl">
              Track global hiring velocity, salary adjustments, and technological growth rates. Filter by active sector clusters or isolate specific skill competencies dynamically.
            </p>
          </div>
          <div className="flex-shrink-0 flex items-center">
            <div className="p-5 bg-gradient-to-tr from-indigo-100 to-sky-100 rounded-2xl border border-indigo-200/50 shadow-md shadow-indigo-100/5 relative group hover:scale-105 transition-all duration-300">
              <TrendingUp className="w-12 h-12 text-indigo-600 relative z-10 animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Activity Ticker */}
      <div className="bg-slate-950/5 border border-slate-200/60 rounded-3xl p-5 shadow-inner relative overflow-hidden bg-white/70 backdrop-blur-md">
        <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
          <h3 className="text-[11px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
            <Globe className="w-4 h-4 text-indigo-500 animate-spin" style={{ animationDuration: '20s' }} />
            Ingestion Telemetry Stream
          </h3>
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-100 text-[10px] font-black uppercase tracking-wider shadow-sm animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-ping" />
            Live Connection Active
          </span>
        </div>
        
        <div className="space-y-2.5 font-mono text-[11px] md:text-xs text-slate-600 leading-relaxed max-h-[140px] overflow-y-auto">
          {liveLogs.map((log, idx) => (
            <div 
              key={idx} 
              className={`flex items-start gap-2 animate-fadeIn border-l-2 pl-3 py-1.5 transition-all duration-300 ${
                idx === 0 
                  ? "border-indigo-500 text-indigo-750 font-bold bg-indigo-50/40 rounded-r-xl" 
                  : "border-slate-200"
              }`}
            >
              <span>{log}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Stats KPI Ribbon Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white border border-slate-200/80 shadow-md p-6 rounded-3xl hover:shadow-lg hover:border-slate-300 transition-all duration-300 flex items-center gap-4">
          <div className="p-3 bg-indigo-50 text-indigo-650 rounded-2xl border border-indigo-100">
            <Globe className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xl font-black text-slate-800 leading-none">{stats.totalIngested}</p>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Ingested Listings</p>
            <span className="text-[9px] text-emerald-600 font-extrabold flex items-center gap-0.5 mt-0.5">+12% today</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200/80 shadow-md p-6 rounded-3xl hover:shadow-lg hover:border-slate-300 transition-all duration-300 flex items-center gap-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl border border-amber-100">
            <Trophy className="w-6 h-6 animate-bounce" style={{ animationDuration: '3s' }} />
          </div>
          <div>
            <p className="text-xl font-black text-slate-800 leading-none">₹{stats.peakSalary} LPA</p>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Peak Salary Tier</p>
            <span className="text-[9px] text-slate-500 font-extrabold mt-0.5 truncate block max-w-[130px]">Cloud Architect</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200/80 shadow-md p-6 rounded-3xl hover:shadow-lg hover:border-slate-300 transition-all duration-300 flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl border border-emerald-100">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xl font-black text-slate-800 leading-none">+{stats.avgGrowth}%</p>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Average Growth</p>
            <span className="text-[9px] text-emerald-600 font-extrabold mt-0.5">YoY Accelerating</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200/80 shadow-md p-6 rounded-3xl hover:shadow-lg hover:border-slate-300 transition-all duration-300 flex items-center gap-4">
          <div className="p-3 bg-rose-50 text-rose-600 rounded-2xl border border-rose-100">
            <Flame className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <p className="text-xl font-black text-slate-800 leading-none">{stats.trendingCount} Roles</p>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Hot / Trending</p>
            <span className="text-[9px] text-rose-600 font-extrabold mt-0.5">High hiring velocity</span>
          </div>
        </div>
      </div>

      {/* Configuration & Selection Card */}
      <div className="bg-white border border-slate-200/80 shadow-md p-6 md:p-8 rounded-3xl grid lg:grid-cols-12 gap-6 items-center hover:shadow-lg hover:border-slate-300 transition-all duration-300">
        
        {/* Category sector selectors */}
        <div className="lg:col-span-8 space-y-2">
          <label className="text-xs font-black text-slate-400 uppercase tracking-widest block flex items-center gap-1.5">
            <Briefcase className="w-3.5 h-3.5 text-indigo-500" /> Sector Filter
          </label>
          <div className="flex flex-wrap gap-2">
            {[
              { id: "All", label: "All Sectors" },
              { id: "AI & Data", label: "AI & Data Science" },
              { id: "Cloud", label: "Cloud & Infrastructure" },
              { id: "Security & Web3", label: "Cybersecurity & Web3" },
              { id: "Dev & Design", label: "Web Dev & Figma" },
              { id: "Hardware & Management", label: "Management & Embedded" }
            ].map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`py-2 px-3 text-xs font-black rounded-xl transition-all duration-300 border ${
                  selectedCategory === cat.id
                    ? "bg-indigo-600 border-indigo-650 text-white shadow-md shadow-indigo-500/20 scale-102"
                    : "bg-slate-50 border-slate-200 text-slate-550 hover:border-slate-350 hover:bg-white"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Live query search input */}
        <div className="lg:col-span-4 space-y-2">
          <label className="text-xs font-black text-slate-400 uppercase tracking-widest block flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-indigo-500" /> Filter by Target Query
          </label>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search jobs, categories, skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-3 bg-slate-50/50 text-slate-800 font-bold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all text-xs shadow-inner"
            />
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* Visual Workspace Segment */}
      {filteredTrends.length > 0 ? (
        <div className="space-y-8">
          
          {/* Main Composed Chart Dashboard */}
          <div className="bg-white border border-slate-200/80 shadow-md p-6 md:p-8 rounded-3xl hover:shadow-lg transition-shadow duration-300">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-100 pb-5 mb-6 gap-4">
              <div>
                <h2 className="text-sm font-black text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-indigo-500" /> Multi-Dimensional Cluster Telemetry
                </h2>
                <p className="text-[10px] text-slate-400 mt-1 font-semibold">Comparing Demand Score (Left Y-Axis) against Average Salaries & YoY Growth Acceleration (Right Y-Axis)</p>
              </div>
              <span className="text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-150 px-2.5 py-1 rounded-xl font-bold uppercase tracking-wider">
                Interactive Rendering
              </span>
            </div>

            <ResponsiveContainer width="100%" height={340}>
              <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 40 }}>
                <defs>
                  <linearGradient id="colorDemand" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0}/>
                  </linearGradient>
                  <linearGradient id="colorSalary" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="name" angle={-25} textAnchor="end" tick={{ fontSize: 9, fill: "#64748b", fontWeight: "700" }} interval={0} />
                <YAxis yAxisId="left" domain={[0, 100]} tick={{ fontSize: 9, fill: "#64748b" }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 9, fill: "#64748b" }} />
                <Tooltip
                  contentStyle={{ 
                    backgroundColor: "rgba(255, 255, 255, 0.95)", 
                    borderRadius: "16px", 
                    border: "1px solid #e2e8f0", 
                    fontSize: "12px", 
                    boxShadow: "0 10px 15px -3px rgba(0,0,0,0.05)" 
                  }}
                />
                <Legend wrapperStyle={{ fontSize: "11px", pt: 10 }} />
                <Area yAxisId="left" type="monotone" dataKey="demand" name="Demand Index (0-100)" stroke="#6366f1" strokeWidth={2.5} fillOpacity={1} fill="url(#colorDemand)" />
                <Bar yAxisId="left" dataKey="salary" name="Avg Salary (LPA)" fill="#8b5cf6" radius={[4, 4, 0, 0]} maxBarSize={28} />
                <Line yAxisId="right" type="monotone" dataKey="growth" name="YoY Growth Rate (%)" stroke="#10b981" strokeWidth={3} dot={{ r: 4, stroke: "#10b981", strokeWidth: 2, fill: "#fff" }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {/* Salary vs Growth Analytics Grid */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white border border-slate-200/80 shadow-md p-6 md:p-8 rounded-3xl hover:shadow-lg transition-shadow duration-300">
              <h2 className="text-sm font-black text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-1.5">
                <Landmark className="w-4 h-4 text-purple-500" /> Salary Ranges By Target (₹ LPA)
              </h2>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={chartData} layout="vertical" margin={{ left: 5, right: 10, top: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 9, fill: "#64748b" }} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 9, fill: "#64748b", fontWeight: "700" }} width={80} />
                  <Tooltip formatter={(v) => [`₹${v} LPA`]} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
                  <Bar dataKey="salary" name="Avg Salary" fill="url(#colorSalary)" stroke="#8b5cf6" strokeWidth={1} radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white border border-slate-200/80 shadow-md p-6 md:p-8 rounded-3xl hover:shadow-lg transition-shadow duration-300">
              <h2 className="text-sm font-black text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-emerald-500" /> YoY Acceleration Percentage (%)
              </h2>
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                  <defs>
                    <linearGradient id="colorGrowth" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" angle={-25} textAnchor="end" tick={{ fontSize: 9, fill: "#64748b", fontWeight: "700" }} interval={0} />
                  <YAxis tick={{ fontSize: 9, fill: "#64748b" }} />
                  <Tooltip formatter={(v) => [`${v}% Growth`]} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
                  <Area type="monotone" dataKey="growth" name="Growth" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorGrowth)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* In-Demand Skills Interactive Heatmap */}
          <div className="bg-white border border-slate-200/80 shadow-md p-6 md:p-8 rounded-3xl hover:shadow-lg transition-shadow duration-300">
            <h2 className="text-sm font-black text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-indigo-500" /> Technical Competency Heatmap
            </h2>
            <div className="grid md:grid-cols-12 gap-8 items-center">
              <div className="md:col-span-6 flex justify-center">
                <ResponsiveContainer width="100%" height={280}>
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="#cbd5e1" />
                    <PolarAngleAxis dataKey="skill" tick={{ fontSize: 10, fill: "#475569", fontWeight: "700" }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 8 }} />
                    <Radar name="Market Demand" dataKey="demand" stroke="#6366f1" fill="#6366f1" fillOpacity={0.25} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              
              <div className="md:col-span-6 space-y-4">
                <p className="text-xs text-slate-500 leading-relaxed font-bold">
                  Click on any high-frequency skill competency tag below to instantly isolate target professions matching that specific technical stack.
                </p>
                <div className="flex flex-wrap gap-2">
                  {skills.map((s) => {
                    const isActive = selectedSkillFilter === s;
                    return (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setSelectedSkillFilter(isActive ? null : s)}
                        className={`text-xs px-3.5 py-2 rounded-xl border transition-all duration-300 font-extrabold flex items-center gap-1.5 ${
                          isActive
                            ? "bg-indigo-600 border-indigo-650 text-white shadow-lg shadow-indigo-500/20 scale-105"
                            : "bg-indigo-50/50 border-indigo-100 hover:border-indigo-300 text-indigo-700 hover:bg-indigo-50"
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full inline-block ${isActive ? "bg-white" : "bg-indigo-500 animate-pulse"}`} />
                        {s}
                      </button>
                    );
                  })}
                </div>
                {selectedSkillFilter && (
                  <button 
                    onClick={() => setSelectedSkillFilter(null)}
                    className="text-[10px] text-rose-500 font-extrabold uppercase tracking-widest hover:underline block pt-2"
                  >
                    Clear Skill Filter [✕]
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Segmented Job Cards Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTrends.map((t) => (
              <div 
                key={t.id || t.jobTitle} 
                className="bg-white border border-slate-200/80 p-6 rounded-3xl hover:shadow-xl hover:border-slate-350 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div className="min-w-0">
                      <p className="font-extrabold text-slate-800 text-sm md:text-base leading-snug truncate">{t.jobTitle}</p>
                      <p className="text-[10px] font-black uppercase text-slate-400 tracking-wider mt-0.5">{t.category} · {t.industry}</p>
                    </div>
                    {t.isTrending && (
                      <span className="flex-shrink-0 flex items-center gap-1 text-[10px] font-black bg-orange-50 text-orange-600 border border-orange-200/50 px-2.5 py-1 rounded-full uppercase tracking-wider animate-pulse">
                        <Flame className="w-3.5 h-3.5 fill-current" /> Hot
                      </span>
                    )}
                  </div>

                  {/* Micro dashboard grids */}
                  <div className="grid grid-cols-3 gap-2.5 text-center mb-5">
                    <div className="bg-indigo-50/50 border border-indigo-100/30 rounded-2xl p-2.5">
                      <p className="text-base font-black text-indigo-755">{t.demandScore}</p>
                      <p className="text-[9px] font-extrabold text-slate-450 uppercase tracking-widest mt-0.5">Demand</p>
                    </div>
                    <div className="bg-emerald-50/50 border border-emerald-100/30 rounded-2xl p-2.5">
                      <p className="text-base font-black text-emerald-700">₹{t.averageSalaryLPA}L</p>
                      <p className="text-[9px] font-extrabold text-slate-450 uppercase tracking-widest mt-0.5">Salary</p>
                    </div>
                    <div className="bg-purple-50/50 border border-purple-100/30 rounded-2xl p-2.5">
                      <p className="text-base font-black text-purple-755">+{t.growthRate}%</p>
                      <p className="text-[9px] font-extrabold text-slate-450 uppercase tracking-widest mt-0.5">Growth</p>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <div className="flex flex-wrap gap-1.5">
                    {(t.topSkillsRequired || []).slice(0, 3).map((s) => (
                      <span 
                        key={s} 
                        className="text-[9px] px-2.5 py-1 bg-slate-100 text-slate-600 border border-slate-200/50 rounded-xl font-bold uppercase tracking-wider"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      ) : (
        <div className="text-center py-16 bg-white border border-slate-200/80 rounded-3xl shadow-sm space-y-4">
          <Compass className="w-12 h-12 mx-auto text-slate-300 animate-pulse" />
          <div>
            <p className="text-sm font-bold text-slate-605">No market metrics match your current active filter conditions.</p>
            <p className="text-xs text-slate-400 mt-1">Try resetting your category tab or clearing your search keywords.</p>
          </div>
          <button
            onClick={() => { setSelectedCategory("All"); setSearchQuery(""); setSelectedSkillFilter(null); }}
            className="px-4 py-2 bg-indigo-50 border border-indigo-150 hover:bg-indigo-100 hover:text-indigo-700 text-indigo-650 text-xs font-black rounded-xl transition-all shadow-sm"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
}
