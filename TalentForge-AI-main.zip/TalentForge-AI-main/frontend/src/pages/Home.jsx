import { Link } from "react-router-dom";
import { Zap, Brain, Target, TrendingUp, FileText, MessageCircle, ArrowRight } from "lucide-react";

const FEATURES = [
  { icon: Brain,         title: "AI Career Recommendations", desc: "Groq-powered Llama 3 analyzes your skills and interests to suggest the best career paths." },
  { icon: FileText,      title: "Resume Analyzer",           desc: "Upload your PDF resume. spaCy + AI extract skills, experience, and give improvement tips." },
  { icon: Target,        title: "Skill Gap Analysis",        desc: "See exactly which skills you're missing for your target career with a match percentage." },
  { icon: TrendingUp,    title: "Market Trends",             desc: "Real-time 2026 job market data — demand scores, salaries, and growth rates." },
  { icon: MessageCircle, title: "AI Career Mentor",          desc: "Chat with an AI mentor powered by Llama 3 for personalized career advice." },
  { icon: Zap,           title: "Learning Paths",            desc: "Get a 6-month personalized roadmap with courses, certifications, and projects." },
];

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary-600 via-primary-700 to-purple-800 text-white py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 rounded-full px-4 py-1.5 text-sm mb-6">
            <Zap className="w-4 h-4" /> Powered by Groq · spaCy · scikit-learn · pgvector
          </div>
          <h1 className="text-5xl font-extrabold mb-6 leading-tight">
            Your AI-Powered<br />Career Guidance Platform
          </h1>
          <p className="text-xl text-primary-100 mb-10 max-w-2xl mx-auto">
            TalentForge AI combines cutting-edge NLP, machine learning, and LLMs to help you
            discover the right career path, close skill gaps, and land your dream job.
          </p>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <Link to="/register" className="bg-white text-primary-700 font-semibold px-8 py-3 rounded-lg hover:bg-primary-50 transition-colors flex items-center gap-2">
              Get Started Free <ArrowRight className="w-4 h-4" />
            </Link>
            <Link to="/login" className="border border-white/40 text-white px-8 py-3 rounded-lg hover:bg-white/10 transition-colors">
              Sign In
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-4">
            Everything you need to navigate your career
          </h2>
          <p className="text-center text-gray-500 mb-12 max-w-xl mx-auto">
            From resume parsing to collaborative filtering — all in one platform.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="card hover:shadow-md transition-shadow">
                <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="w-5 h-5 text-primary-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-16 px-6 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Built with modern AI/ML stack</h2>
          <div className="flex flex-wrap justify-center gap-3">
            {["React.js", "Flask", "PostgreSQL", "pgvector", "spaCy", "scikit-learn", "Groq / Llama 3", "Recharts", "React Flow", "AWS"].map((tech) => (
              <span key={tech} className="badge-purple text-sm px-4 py-1.5">{tech}</span>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 bg-primary-600 text-white text-center">
        <h2 className="text-3xl font-bold mb-4">Ready to forge your career?</h2>
        <p className="text-primary-100 mb-8">Join thousands of students using AI to plan their future.</p>
        <Link to="/register" className="bg-white text-primary-700 font-semibold px-8 py-3 rounded-lg hover:bg-primary-50 transition-colors inline-flex items-center gap-2">
          Start for Free <ArrowRight className="w-4 h-4" />
        </Link>
      </section>
    </div>
  );
}
