import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getChatHistory, sendChatMessage, clearChatHistory } from "../api/index";
import ReactMarkdown from "react-markdown";
import toast from "react-hot-toast";
import { MessageCircle, Send, Trash2, Loader2, Bot, User } from "lucide-react";
import clsx from "clsx";
import { useAuthStore } from "../store/authStore";

const SUGGESTIONS = [
  "What career suits someone with Python and ML skills?",
  "How do I transition from software dev to data science?",
  "What certifications should I get for cloud engineering?",
  "How long does it take to become an AI engineer?",
];

export default function Chat() {
  const { user } = useAuthStore();
  const [input, setInput] = useState("");
  const bottomRef = useRef(null);
  const queryClient = useQueryClient();

  const { data: historyData, isLoading } = useQuery({
    queryKey: ["chatHistory", user?.id],
    queryFn: () => getChatHistory().then((r) => r.data.data.messages),
    enabled: !!user?.id,
  });

  const messages = historyData || [];

  const sendMutation = useMutation({
    mutationFn: (message) => sendChatMessage({ message }).then((r) => r.data.data),
    onSuccess: (data) => {
      queryClient.setQueryData(["chatHistory", user?.id], data.messages);
    },
    onError: () => toast.error("Failed to send message"),
  });

  const clearMutation = useMutation({
    mutationFn: clearChatHistory,
    onSuccess: () => {
      queryClient.setQueryData(["chatHistory", user?.id], []);
      toast.success("Chat cleared");
    },
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sendMutation.isPending]);

  const handleSend = (msg) => {
    const text = (msg || input).trim();
    if (!text || sendMutation.isPending) return;
    setInput("");
    sendMutation.mutate(text);
  };

  return (
    <div className="max-w-3xl mx-auto flex flex-col h-[calc(100vh-8rem)]">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <MessageCircle className="w-6 h-6 text-primary-600" /> AI Career Mentor
          </h1>
          <p className="text-gray-500 text-sm mt-0.5">Powered by Groq · llama-3.1-8b-instant</p>
        </div>
        {messages.length > 0 && (
          <button
            onClick={() => clearMutation.mutate()}
            disabled={clearMutation.isPending}
            className="btn-secondary text-sm flex items-center gap-1.5"
          >
            <Trash2 className="w-4 h-4" /> Clear
          </button>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto card p-4 space-y-4 mb-4">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="w-6 h-6 animate-spin text-primary-400" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Bot className="w-12 h-12 text-primary-200 mb-4" />
            <p className="text-gray-500 font-medium">Your AI Career Mentor is ready</p>
            <p className="text-sm text-gray-400 mt-1 mb-6">Ask anything about careers, skills, or job market</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-md">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => handleSend(s)}
                  className="text-left text-sm bg-primary-50 hover:bg-primary-100 text-primary-700 rounded-lg px-3 py-2 transition-colors"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <>
            {messages.map((msg, i) => (
              <div
                key={i}
                className={clsx("flex gap-3", msg.role === "user" ? "flex-row-reverse" : "flex-row")}
              >
                <div className={clsx(
                  "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                  msg.role === "user" ? "bg-primary-100" : "bg-gray-100"
                )}>
                  {msg.role === "user"
                    ? <User className="w-4 h-4 text-primary-600" />
                    : <Bot className="w-4 h-4 text-gray-600" />}
                </div>
                <div className={clsx(
                  "max-w-[80%] rounded-2xl px-4 py-3 text-sm",
                  msg.role === "user"
                    ? "bg-primary-600 text-white rounded-tr-sm"
                    : "bg-gray-100 text-gray-800 rounded-tl-sm"
                )}>
                  {msg.role === "assistant"
                    ? <div className="prose prose-sm max-w-none"><ReactMarkdown>{msg.content}</ReactMarkdown></div>
                    : msg.content}
                </div>
              </div>
            ))}
            {sendMutation.isPending && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                  <Bot className="w-4 h-4 text-gray-600" />
                </div>
                <div className="bg-gray-100 rounded-2xl rounded-tl-sm px-4 py-3">
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div key={i} className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                        style={{ animationDelay: `${i * 0.15}s` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </>
        )}
      </div>

      {/* Input */}
      <div className="flex gap-3">
        <input
          type="text"
          className="input flex-1"
          placeholder="Ask your career mentor anything…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
          disabled={sendMutation.isPending}
        />
        <button
          onClick={() => handleSend()}
          disabled={!input.trim() || sendMutation.isPending}
          className="btn-primary px-4"
        >
          {sendMutation.isPending
            ? <Loader2 className="w-4 h-4 animate-spin" />
            : <Send className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
}
