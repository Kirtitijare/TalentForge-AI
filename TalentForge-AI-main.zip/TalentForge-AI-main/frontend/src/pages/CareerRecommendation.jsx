import { useState, useEffect, useCallback } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useDropzone } from "react-dropzone";
import ReactMarkdown from "react-markdown";
import toast from "react-hot-toast";
import {
  Briefcase, Sparkles, Loader2, FileText, Keyboard, ArrowRight,
  Upload, CheckCircle, X, Eye, Brain, GraduationCap, Award,
  ChevronRight, AlertCircle, TrendingUp, Info, User, HelpCircle,
  BarChart2, Zap, Trash2, Star, BookOpen, DollarSign
} from "lucide-react";
import clsx from "clsx";
import { getCareerRecommendation, getProfile, analyzeResume, listRecommendations, submitCareerFeedback } from "../api/index";
import { useAuthStore } from "../store/authStore";

// Sub-components for styling
function SkillBadge({ skill }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-primary-50/80 text-primary-700 border border-primary-100 hover:border-primary-300 hover:bg-primary-50 transition-colors">
      <Sparkles className="w-3 h-3 text-primary-500" />
      {skill}
    </span>
  );
}

function StatCard({ label, value, icon: Icon, color = "primary" }) {
  const colors = {
    primary: "from-primary-500 to-indigo-600 text-primary-600 bg-primary-50/50 border-primary-100/50",
    green:   "from-green-500 to-emerald-600 text-green-600 bg-green-50/50 border-green-100/50",
    amber:   "from-amber-500 to-orange-600 text-amber-600 bg-amber-50/50 border-amber-100/50",
    blue:    "from-blue-500 to-cyan-600 text-blue-600 bg-blue-50/50 border-blue-100/50",
  };
  return (
    <div className={clsx(
      "bg-white/80 backdrop-blur-sm rounded-xl border p-4 flex items-center justify-between gap-3 shadow-sm hover:shadow-md transition-all duration-200"
    )}>
      <div>
        <span className="text-2xl font-black bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent block">
          {value}
        </span>
        <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider block mt-0.5">{label}</span>
      </div>
      <div className={clsx("w-9 h-9 rounded-lg flex items-center justify-center", colors[color])}>
        <Icon className="w-5 h-5" />
      </div>
    </div>
  );
}

function EmptyState({ icon: Icon, message }) {
  return (
    <div className="flex flex-col items-center gap-2.5 py-10 text-center bg-gray-50/60 rounded-2xl border border-dashed border-gray-200">
      <div className="w-12 h-12 rounded-full bg-gray-100/80 flex items-center justify-center">
        <Icon className="w-5 h-5 text-gray-400" />
      </div>
      <p className="text-sm text-gray-500 font-medium max-w-xs">{message}</p>
    </div>
  );
}

const cleanTitle = (title) => {
  if (!title) return "";
  return title.replace(/^[\s*_#]+|[\s*_#]+$/g, "");
};

export default function CareerRecommendation() {
  const { user } = useAuthStore();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  // Mode Selection: "resume" (AI Resume Analyzer), "profile" (Saved Profile), "manual" (Manual Sandbox)
  const tabParam = searchParams.get("tab");
  const [mode, setMode] = useState(
    tabParam === "resume" || tabParam === "profile" || tabParam === "manual" ? tabParam : "resume"
  );

  // Sync state if query parameter changes
  useEffect(() => {
    if (tabParam && ["resume", "profile", "manual"].includes(tabParam)) {
      setMode(tabParam);
    }
  }, [tabParam]);

  const handleModeChange = (newMode) => {
    setMode(newMode);
    setSearchParams({ tab: newMode });
    // Reset active matching recommendations unless loaded from storage
    if (newMode !== "resume") {
      setRecommendationResult(null);
    } else if (localSavedResume) {
      // Auto-restore previous resume if they click back to resume tab
      setResumeResult(localSavedResume);
      setRecommendationResult(localSavedRecommendation);
    }
  };

  // State holding fetched DB profile
  const [profile, setProfile] = useState(null);
  const [loadingProfile, setLoadingProfile] = useState(true);

  // Resume Upload & Analysis state
  const [file, setFile] = useState(null);
  const [loadingResume, setLoadingResume] = useState(false);
  const [resumeResult, setResumeResult] = useState(null);
  const [resumeActiveSubTab, setResumeActiveSubTab] = useState("analysis");
  const [dbResumeActiveSubTab, setDbResumeActiveSubTab] = useState("analysis");

  // Sandbox Form state
  const [form, setForm] = useState({ interests: "", skills: "", academicBackground: "" });

  // Unified Recommendation Results State
  const [recommendationResult, setRecommendationResult] = useState(null);
  const [loadingRecommendation, setLoadingRecommendation] = useState(false);

  // LocalStorage Caching States for Persistence
  const [localSavedResume, setLocalSavedResume] = useState(null);
  const [localSavedRecommendation, setLocalSavedRecommendation] = useState(null);

  // Load previous resume and recommendations from localStorage
  useEffect(() => {
    if (!user?.id) return;
    try {
      const savedResume = localStorage.getItem(`talentforge_resume_result_${user.id}`);
      const savedRecs = localStorage.getItem(`talentforge_recommendation_result_${user.id}`);
      if (savedResume) {
        const parsedResume = JSON.parse(savedResume);
        setLocalSavedResume(parsedResume);
        if (mode === "resume") {
          setResumeResult(parsedResume);
        }
      } else {
        setLocalSavedResume(null);
        setResumeResult(null);
      }
      if (savedRecs) {
        const parsedRecs = JSON.parse(savedRecs);
        setLocalSavedRecommendation(parsedRecs);
        if (mode === "resume") {
          setRecommendationResult(parsedRecs);
        }
      } else {
        setLocalSavedRecommendation(null);
        setRecommendationResult(null);
      }
    } catch (e) {
      console.error("Failed to parse cached resume from localStorage:", e);
    }
  }, [mode, user?.id]);

  // Background Auto-generation if resume exists but no career path generated in DB yet
  const handleAutoGenerateRecommendation = async (resumeObj) => {
    setLoadingRecommendation(true);
    try {
      const parsedSkills = resumeObj.parsed?.skills?.join(", ") || "";
      const parsedEdu = resumeObj.parsed?.education?.[0]?.degree || resumeObj.parsed?.education?.[0]?.institution || "";
      const parsedInterests = resumeObj.parsed?.summary || "";

      const recPayload = {
        skills: parsedSkills,
        interests: parsedInterests,
        academicBackground: parsedEdu,
      };

      const recRes = await getCareerRecommendation(recPayload);
      const recData = recRes.data.data;
      setRecommendationResult(recData);
      setLocalSavedRecommendation(recData);
      if (user?.id) {
        localStorage.setItem(`talentforge_recommendation_result_${user.id}`, JSON.stringify(recData));
      }
      toast.success("Auto-generated career recommendations from saved resume!");
    } catch (err) {
      console.error("Background auto-recommendation failed:", err);
    } finally {
      setLoadingRecommendation(false);
    }
  };

  // Fetch student profile on load
  useEffect(() => {
    if (!user?.id) return;
    const fetchProfileData = async () => {
      setLoadingProfile(true);
      try {
        const res = await getProfile();
        const data = res.data.data;
        setProfile(data);
        if (data) {
          setForm({
            interests: data.interests?.join(", ") || "",
            skills: data.skills?.join(", ") || "",
            academicBackground: data.education || ""
          });

          // Sync database-stored resume_data into local cache if available
          let resumeObj = null;
          if (data.resumeData) {
            resumeObj = data.resumeData;
            setLocalSavedResume(resumeObj);
            if (user?.id) {
              localStorage.setItem(`talentforge_resume_result_${user.id}`, JSON.stringify(resumeObj));
            }
            if (mode === "resume") {
              setResumeResult(resumeObj);
            }
          }

          // Fetch database career recommendations
          try {
            const recsRes = await listRecommendations();
            const recs = recsRes.data.data;
            if (recs && recs.length > 0) {
              setRecommendationResult(recs);
              setLocalSavedRecommendation(recs);
              if (user?.id) {
                localStorage.setItem(`talentforge_recommendation_result_${user.id}`, JSON.stringify(recs));
              }
            } else if (resumeObj) {
              console.log("No recommendation found in database but resume exists. Auto-generating...");
              handleAutoGenerateRecommendation(resumeObj);
            }
          } catch (recErr) {
            console.error("Failed to load recommendations from database:", recErr);
          }
        }
      } catch (err) {
        console.error("Failed to load user profile:", err);
      } finally {
        setLoadingProfile(false);
      }
    };
    fetchProfileData();
  }, [user?.id, mode]);

  // Dropzone Setup
  const onDrop = useCallback((accepted) => {
    if (accepted[0]) {
      setFile(accepted[0]);
      setResumeResult(null);
      setRecommendationResult(null);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { "application/pdf": [".pdf"] },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024,
    onDropRejected: () => toast.error("Only PDF files up to 10 MB are accepted"),
  });

  // Pipeline Execution: Parse Resume PDF AND Auto-Recommend Matching Careers
  const handleAnalyzeAndRecommend = async () => {
    if (!file) return;
    setLoadingResume(true);
    setLoadingRecommendation(true);
    setResumeResult(null);
    setRecommendationResult(null);

    const formData = new FormData();
    formData.append("resume", file);

    try {
      // 1. Analyze resume (calls PDF parser + Groq structure extractor)
      const res = await analyzeResume(formData);
      const parsedData = res.data.data;
      setResumeResult(parsedData);
      setResumeActiveSubTab("analysis");
      
      // Store in localStorage
      if (user?.id) {
        localStorage.setItem(`talentforge_resume_result_${user.id}`, JSON.stringify(parsedData));
      }
      setLocalSavedResume(parsedData);

      toast.success("Resume parsed successfully!");

      // Refresh stored profile in background
      try {
        const profRes = await getProfile();
        setProfile(profRes.data.data);
      } catch (err) {
        console.error("Failed to sync profile:", err);
      }

      // 2. Immediately execute Career Recommendation
      const parsedSkills = parsedData.parsed?.skills?.join(", ") || "";
      const parsedEdu = parsedData.parsed?.education?.[0]?.degree || parsedData.parsed?.education?.[0]?.institution || "";
      const parsedInterests = parsedData.parsed?.summary || "";

      const recPayload = {
        skills: parsedSkills,
        interests: parsedInterests,
        academicBackground: parsedEdu,
      };

      const recRes = await getCareerRecommendation(recPayload);
      setRecommendationResult(recRes.data.data);
      
      // Store recommendation in localStorage
      if (user?.id) {
        localStorage.setItem(`talentforge_recommendation_result_${user.id}`, JSON.stringify(recRes.data.data));
      }
      setLocalSavedRecommendation(recRes.data.data);

      toast.success("Hybrid ML Career recommendations loaded!");
    } catch (err) {
      console.error(err);
      toast.error(err.response?.data?.message || "Parsing or recommendation failed");
    } finally {
      setLoadingResume(false);
      setLoadingRecommendation(false);
    }
  };

  // Restore the cached report into view
  const handleRestoreCachedReport = () => {
    if (localSavedResume) {
      setResumeResult(localSavedResume);
      setRecommendationResult(localSavedRecommendation);
      setResumeActiveSubTab("analysis");
      setMode("resume");
      setSearchParams({ tab: "resume" });
      toast.success("Loaded previous analysis report!");
    }
  };

  // Clear Cached Resume Data
  const handleClearCachedReport = (e) => {
    e.stopPropagation();
    if (user?.id) {
      localStorage.removeItem(`talentforge_resume_result_${user.id}`);
      localStorage.removeItem(`talentforge_recommendation_result_${user.id}`);
    }
    setLocalSavedResume(null);
    setLocalSavedRecommendation(null);
    setResumeResult(null);
    setRecommendationResult(null);
    toast.success("Cleared cached report successfully");
  };

  const handleRateCareer = async (careerSlug, ratingValue, careerTitle) => {
    try {
      await submitCareerFeedback({ careerSlug, careerTitle, rating: ratingValue });
      toast.success("Rating saved! SVD models retrained in real-time.");
      
      const res = await listRecommendations();
      const recs = res.data.data;
      if (recs && recs.length > 0) {
        setRecommendationResult(recs);
        setLocalSavedRecommendation(recs);
        if (user?.id) {
          localStorage.setItem(`talentforge_recommendation_result_${user.id}`, JSON.stringify(recs));
        }
      }
    } catch (err) {
      console.error("Failed to rate career:", err);
      toast.error(err.response?.data?.message || "Failed to submit rating feedback");
    }
  };


  // Saved Profile Pathway
  const handleGenerateFromProfile = async () => {
    if (!profile) return;
    setLoadingRecommendation(true);
    setRecommendationResult(null);

    const recPayload = {
      skills: profile.skills?.join(", ") || "",
      interests: profile.interests?.join(", ") || "",
      academicBackground: profile.education || "",
    };

    try {
      const recRes = await getCareerRecommendation(recPayload);
      setRecommendationResult(recRes.data.data);
      toast.success("Recommendations retrieved successfully!");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to generate recommendations");
    } finally {
      setLoadingRecommendation(false);
    }
  };

  // Sandbox Sandbox submission
  const handleSandboxSubmit = async (e) => {
    e.preventDefault();
    setLoadingRecommendation(true);
    setRecommendationResult(null);

    if (!form.skills && !form.interests) {
      toast.error("Please provide at least interests or skills to generate recommendations");
      setLoadingRecommendation(false);
      return;
    }

    try {
      const recRes = await getCareerRecommendation(form);
      setRecommendationResult(recRes.data.data);
      toast.success("Sandbox recommendation complete!");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to get sandbox recommendation");
    } finally {
      setLoadingRecommendation(false);
    }
  };

  const hasProfileData = profile && (profile.skills?.length > 0 || profile.education || profile.interests?.length > 0);

  // Resume metadata stats
  const skillCount   = resumeResult?.parsed?.skills?.length || 0;
  const expCount     = resumeResult?.parsed?.experience?.length || 0;
  const eduCount     = resumeResult?.parsed?.education?.length || 0;
  const certCount    = resumeResult?.parsed?.certifications?.length || 0;

  // DB/Cache resume stats
  const dbResume = profile?.resumeData || localSavedResume;
  const dbSkillCount = dbResume?.parsed?.skills?.length || 0;
  const dbExpCount = dbResume?.parsed?.experience?.length || 0;
  const dbEduCount = dbResume?.parsed?.education?.length || 0;
  const dbCertCount = dbResume?.parsed?.certifications?.length || 0;

  const RESUME_TABS = [
    { id: "analysis",   label: "AI Audit Report",  icon: Brain },
    { id: "skills",     label: `Skills (${skillCount})`, icon: Sparkles },
    { id: "experience", label: `Experience (${expCount})`, icon: Briefcase },
    { id: "education",  label: "Education", icon: GraduationCap },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      
      {/* Top Header Card */}
      <div className="relative overflow-hidden rounded-2xl border border-white/20 bg-gradient-to-r from-primary-600 via-indigo-600 to-violet-700 p-6 sm:p-8 shadow-xl">
        <div className="absolute -top-24 -right-24 w-72 h-72 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-black/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center shadow-inner">
                <Briefcase className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                Career Recommender &amp; Resume Analyzer
              </h1>
            </div>
            <p className="text-indigo-100 text-sm font-medium pl-1">
              Analyze your resume PDF with spaCy/Groq AI &amp; map instant trajectories with our Hybrid ML matching engine
            </p>
          </div>
          {resumeResult && (
            <div className="flex items-center gap-1.5 self-start md:self-auto px-4 py-2 bg-emerald-500/20 backdrop-blur-md border border-emerald-400/40 rounded-full text-white">
              <CheckCircle className="w-4 h-4 text-emerald-300 animate-pulse" />
              <span className="text-xs font-bold tracking-wide uppercase">Interactive Analysis Ready</span>
            </div>
          )}
        </div>
      </div>

      {/* Tabs Controller */}
      <div className="flex bg-white/60 backdrop-blur-md p-1.5 rounded-2xl border border-gray-200/80 shadow-inner gap-1">
        <button
          onClick={() => handleModeChange("resume")}
          className={clsx(
            "flex-1 flex items-center justify-center gap-2 py-3 px-4 text-xs sm:text-sm font-bold rounded-xl transition-all duration-200",
            mode === "resume"
              ? "bg-white text-primary-700 shadow-sm border border-gray-100"
              : "text-gray-500 hover:text-gray-900 hover:bg-white/40"
          )}
        >
          <Upload className="w-4 h-4" />
          AI Resume Analyzer
        </button>
        <button
          onClick={() => handleModeChange("profile")}
          className={clsx(
            "flex-1 flex items-center justify-center gap-2 py-3 px-4 text-xs sm:text-sm font-bold rounded-xl transition-all duration-200",
            mode === "profile"
              ? "bg-white text-primary-700 shadow-sm border border-gray-100"
              : "text-gray-500 hover:text-gray-900 hover:bg-white/40"
          )}
        >
          <User className="w-4 h-4" />
          Saved Profile Data
        </button>
        <button
          onClick={() => handleModeChange("manual")}
          className={clsx(
            "flex-1 flex items-center justify-center gap-2 py-3 px-4 text-xs sm:text-sm font-bold rounded-xl transition-all duration-200",
            mode === "manual"
              ? "bg-white text-primary-700 shadow-sm border border-gray-100"
              : "text-gray-500 hover:text-gray-900 hover:bg-white/40"
          )}
        >
          <Keyboard className="w-4 h-4" />
           Manual Sandbox
        </button>
      </div>

      {/* Primary Input Container */}
      <div className="w-full">
        {mode === "resume" && (
          <div className="space-y-6">
            {!resumeResult && (
              <div className="space-y-4">
                <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
                  <div
                    {...getRootProps()}
                    className={clsx(
                      "relative border-2 border-dashed rounded-2xl transition-all duration-200 cursor-pointer overflow-hidden py-14 px-8 text-center",
                      isDragActive
                        ? "border-primary-400 bg-primary-50/50 scale-[1.01]"
                        : file
                        ? "border-green-300 bg-green-50/30"
                        : "border-gray-200 hover:border-primary-300 hover:bg-gray-50/50"
                    )}
                  >
                    <input {...getInputProps()} />
                    <div className="absolute -top-10 -right-10 w-40 h-40 bg-gradient-to-br from-primary-100 to-indigo-100 rounded-full opacity-30 pointer-events-none blur-xl" />

                    {file ? (
                      <div className="flex flex-col items-center gap-4">
                        <div className="w-16 h-16 rounded-2xl bg-green-100/80 flex items-center justify-center shadow-sm">
                          <FileText className="w-8 h-8 text-green-600" />
                        </div>
                        <div>
                          <p className="font-bold text-gray-800 text-lg">{file.name}</p>
                          <p className="text-xs text-gray-400 mt-1 font-semibold uppercase tracking-wider">
                            {(file.size / 1024 / 1024).toFixed(2)} MB · Adobe PDF
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setFile(null); setResumeResult(null); setRecommendationResult(null); }}
                          className="flex items-center gap-1.5 text-xs text-red-500 hover:text-red-700 hover:bg-red-50 font-bold px-4 py-2 rounded-full border border-red-200 transition-colors"
                        >
                          <X className="w-3.5 h-3.5" /> Remove file
                        </button>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-4">
                        <div className={clsx(
                          "w-16 h-16 rounded-2xl flex items-center justify-center transition-colors shadow-sm",
                          isDragActive ? "bg-primary-100" : "bg-gray-100/80"
                        )}>
                          <Upload className={clsx("w-8 h-8", isDragActive ? "text-primary-600" : "text-gray-400")} />
                        </div>
                        <div>
                          <p className="font-bold text-gray-700 text-lg">
                            {isDragActive ? "Drop your resume here!" : "Drag & drop your PDF resume here"}
                          </p>
                          <p className="text-sm text-gray-400 mt-1">or click to browse your desktop computer — Max 10MB</p>
                        </div>
                        <div className="flex items-center justify-center gap-6 mt-2 flex-wrap">
                          {["Single PDF Only", "Max 10 MB limit", "spaCy & NLP Optimized", "Auto Hybrid Recommendation"].map((tag) => (
                            <span key={tag} className="flex items-center gap-1 text-[11px] font-bold text-gray-400 uppercase tracking-wide">
                              <ChevronRight className="w-3.5 h-3.5 text-primary-400" />{tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {file && (
                    <div className="mt-5 flex gap-3">
                      <button
                        onClick={handleAnalyzeAndRecommend}
                        disabled={loadingResume}
                        className="btn-primary flex-1 py-3 text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-primary-500/10"
                      >
                        {loadingResume ? (
                          <><Loader2 className="w-4 h-4 animate-spin" /> Deep Extracting &amp; Scoring ML Models…</>
                        ) : (
                          <><Sparkles className="w-4 h-4" /> Analyze Resume &amp; Get Match Recommendations</>
                        )}
                      </button>
                      {resumeResult?.fileName && (
                        <a
                          href={`/api/resume/preview/${resumeResult.fileName}`}
                          target="_blank"
                          rel="noreferrer"
                          className="btn-secondary flex items-center gap-2 border-gray-200"
                        >
                          <Eye className="w-4 h-4 text-gray-500" /> Preview PDF
                        </a>
                      )}
                    </div>
                  )}
                </div>

                {/* Offer restore of previously analyzed resume */}
                {localSavedResume && (
                  <div className="bg-indigo-50/40 border border-indigo-100 rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
                    <div className="flex items-start gap-3.5">
                      <div className="w-11 h-11 bg-indigo-100/70 border border-indigo-200 rounded-xl flex items-center justify-center text-indigo-600 flex-shrink-0 mt-0.5">
                        <FileText className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-indigo-950 flex items-center gap-1.5">
                          Previously Analyzed Resume Detected
                        </h4>
                        <p className="text-xs text-indigo-850 font-medium mt-0.5">
                          File: <span className="font-semibold text-indigo-950">{localSavedResume.fileName?.split("_").slice(1).join("_") || "Stored Resume PDF"}</span>
                        </p>
                        <div className="flex gap-3 mt-1.5 text-[10px] font-bold text-indigo-700 uppercase tracking-wide">
                          <span>Skills: {localSavedResume.parsed?.skills?.length || 0}</span>
                          <span>•</span>
                          <span>Jobs: {localSavedResume.parsed?.experience?.length || 0}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2 w-full sm:w-auto">
                      <button 
                        onClick={handleRestoreCachedReport}
                        className="flex-1 sm:flex-none text-xs font-bold bg-white text-indigo-700 border border-indigo-200 hover:bg-indigo-50 px-4 py-2.5 rounded-xl transition-all shadow-sm"
                      >
                        Restore Full Audit Report
                      </button>
                      <button 
                        onClick={handleClearCachedReport}
                        className="text-xs font-bold bg-white text-red-600 border border-red-100 hover:bg-red-50 p-2.5 rounded-xl transition-all"
                        title="Delete Cached Analysis"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {mode === "profile" && (
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm space-y-6">
            
            {/* Show previously parsed resume widget in priority */}
            {localSavedResume && (
              <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
                <div className="flex items-start gap-3.5">
                  <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600 border border-emerald-200/50 flex-shrink-0 mt-0.5">
                    <FileText className="w-6 h-6 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-emerald-950 flex items-center gap-1.5">
                      <Zap className="w-4 h-4 text-emerald-500 animate-bounce" /> Previously Uploaded Resume Detected
                    </h3>
                    <p className="text-xs text-emerald-800 font-medium mt-0.5">
                      We have a fully analyzed PDF resume stored in your browser session.
                    </p>
                    <div className="flex items-center gap-3 mt-2 text-[10px] font-bold text-emerald-700 uppercase tracking-wider">
                      <span className="bg-white/80 px-2 py-0.5 rounded border border-emerald-200">Skills: {localSavedResume.parsed?.skills?.length || 0}</span>
                      <span className="bg-white/80 px-2 py-0.5 rounded border border-emerald-200">Experiences: {localSavedResume.parsed?.experience?.length || 0}</span>
                      <span className="bg-white/80 px-2 py-0.5 rounded border border-emerald-200">Educations: {localSavedResume.parsed?.education?.length || 0}</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 w-full sm:w-auto">
                  <button 
                    onClick={handleRestoreCachedReport}
                    className="flex-1 sm:flex-none text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-600/10 px-4 py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5"
                  >
                    View Full AI Audit &amp; Recommendations
                  </button>
                  <button 
                    onClick={handleClearCachedReport}
                    className="text-xs font-bold bg-white text-red-500 border border-red-200 hover:bg-red-50 p-2.5 rounded-xl transition-all"
                    title="Clear Resume Cache"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {loadingProfile ? (
              <div className="text-center py-12">
                <Loader2 className="w-10 h-10 animate-spin text-primary-500 mx-auto mb-3" />
                <p className="text-gray-500 text-sm font-semibold">Retrieving your database profile attributes...</p>
              </div>
            ) : hasProfileData ? (
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-primary-50/50 to-violet-50/50 border border-primary-100 rounded-xl p-5 space-y-4">
                  <div className="flex justify-between items-start flex-wrap gap-2">
                    <div>
                      <h3 className="text-base font-bold text-primary-900 flex items-center gap-1.5">
                        <Zap className="w-4 h-4 text-primary-500" /> Stored Database Profile Attributes
                      </h3>
                      <p className="text-xs text-primary-700">Auto-filled from your persistent parsed profile data.</p>
                    </div>
                    <button 
                      onClick={() => handleModeChange("resume")} 
                      className="text-xs font-bold text-primary-700 hover:text-primary-900 border border-primary-200 bg-white/80 hover:bg-white px-3 py-1.5 rounded-lg transition-colors"
                    >
                      Update Profile via Resume
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                    {profile.education && (
                      <div className="bg-white/80 backdrop-blur-sm p-3.5 rounded-xl border border-primary-100/50">
                        <span className="text-[10px] font-black text-primary-800 uppercase block tracking-wider mb-1.5">Extracted Degree/Education</span>
                        <div className="inline-flex items-center gap-1 text-xs text-primary-950 font-bold">
                          <GraduationCap className="w-4 h-4 text-primary-600" />
                          {profile.education}
                        </div>
                      </div>
                    )}

                    {profile.interests && profile.interests.length > 0 && (
                      <div className="bg-white/80 backdrop-blur-sm p-3.5 rounded-xl border border-primary-100/50">
                        <span className="text-[10px] font-black text-primary-800 uppercase block tracking-wider mb-1.5">Interests / Focus</span>
                        <div className="flex flex-wrap gap-1">
                          {profile.interests.map((interest, idx) => (
                            <span key={idx} className="bg-primary-50 text-primary-800 text-[10px] font-bold px-2 py-0.5 rounded-md border border-primary-100">
                              {interest}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {profile.skills && profile.skills.length > 0 && (
                      <div className="col-span-1 md:col-span-2 bg-white/80 backdrop-blur-sm p-3.5 rounded-xl border border-primary-100/50">
                        <span className="text-[10px] font-black text-primary-800 uppercase block tracking-wider mb-1.5">Extracted Skills ({profile.skills.length})</span>
                        <div className="flex flex-wrap gap-1.5">
                          {profile.skills.map((skill, idx) => (
                            <span key={idx} className="bg-primary-100/60 text-primary-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-primary-100">
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <button 
                  onClick={handleGenerateFromProfile} 
                  disabled={loadingRecommendation} 
                  className="btn-primary w-full py-3.5 flex items-center justify-center gap-2 text-base font-bold shadow-lg shadow-primary-500/10"
                >
                  {loadingRecommendation ? (
                    <><Loader2 className="w-5 h-5 animate-spin" /> Training Collaborative Tower &amp; Scoring...</>
                  ) : (
                    <><Sparkles className="w-5 h-5" /> Generate Career Recommendation from Profile</>
                  )}
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {!dbResume && (
                  <div className="text-center py-10 space-y-4 bg-gray-50/50 rounded-2xl border border-gray-100 p-6">
                    <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center mx-auto shadow-inner border border-amber-100">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-lg font-bold text-gray-900">No Extracted Profile Data Found</h3>
                      <p className="text-sm text-gray-500 max-w-md mx-auto">
                        You haven't uploaded a resume PDF yet, or we haven't extracted skills. Upload a resume to populate your profile automatically!
                      </p>
                    </div>
                    <div className="flex justify-center gap-3 pt-2">
                      <button onClick={() => handleModeChange("resume")} className="btn-primary flex items-center gap-2 text-xs font-bold py-2.5 px-4 shadow-md shadow-primary-500/10">
                        Upload PDF Resume <ArrowRight className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleModeChange("manual")} className="btn-secondary text-xs font-bold py-2.5 px-4">
                        Try Sandbox Simulator
                      </button>
                    </div>
                  </div>
                )}

                {dbResume && (
                  <div className="border border-indigo-100 rounded-2xl p-6 bg-gradient-to-b from-indigo-50/20 to-white shadow-sm space-y-6">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-indigo-100 pb-4">
                      <div className="flex items-start gap-3.5">
                        <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-600 shadow-sm border border-indigo-200/50 mt-0.5 flex-shrink-0">
                          <FileText className="w-5 h-5 animate-pulse" />
                        </div>
                        <div>
                          <h3 className="text-sm font-extrabold text-indigo-950 flex items-center gap-1.5">
                            Previously Uploaded Resume Audit Data
                          </h3>
                          <p className="text-xs text-indigo-800 font-semibold mt-0.5">
                            Located a fully parsed resume structure in your database / cache profile.
                          </p>
                        </div>
                      </div>
                      <button 
                        onClick={handleRestoreCachedReport}
                        className="w-full sm:w-auto text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-600/10 px-4 py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5"
                      >
                        View Full AI Audit &amp; Recommendations
                      </button>
                    </div>

                    {/* Stats counts cards */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <StatCard label="Skills detected" value={dbSkillCount} icon={Sparkles} color="primary" />
                      <StatCard label="Experiences" value={dbExpCount} icon={Briefcase} color="blue" />
                      <StatCard label="Educations" value={dbEduCount} icon={GraduationCap} color="green" />
                      <StatCard label="Certificates" value={dbCertCount} icon={Award} color="amber" />
                    </div>

                    {/* Sub-tabs menu */}
                    <div className="bg-white rounded-2xl border border-gray-150/80 overflow-hidden shadow-sm">
                      <div className="flex border-b border-gray-100 bg-gray-50/60 p-1.5 gap-1">
                        {[
                          { id: "analysis",   label: "AI Audit Report",  icon: Brain },
                          { id: "skills",     label: `Skills (${dbSkillCount})`, icon: Sparkles },
                          { id: "experience", label: `Experience (${dbExpCount})`, icon: Briefcase },
                          { id: "education",  label: "Education", icon: GraduationCap },
                        ].map(({ id, label, icon: Icon }) => (
                          <button
                            key={id}
                            type="button"
                            onClick={() => setDbResumeActiveSubTab(id)}
                            className={clsx(
                              "flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold rounded-lg border transition-all",
                              dbResumeActiveSubTab === id
                                ? "border-gray-200 bg-white text-primary-600 shadow-sm"
                                : "border-transparent text-gray-500 hover:text-gray-700 hover:bg-white/40"
                            )}
                          >
                            <Icon className="w-3.5 h-3.5" />
                            {label}
                          </button>
                        ))}
                      </div>

                      {/* Tab Content */}
                      <div className="p-6 max-h-96 overflow-y-auto">
                        {dbResumeActiveSubTab === "analysis" && (
                          <div className="prose prose-sm max-w-none text-gray-700 prose-headings:text-gray-900 prose-strong:text-gray-800 prose-li:text-gray-600 leading-relaxed">
                            <ReactMarkdown>{dbResume.analysis}</ReactMarkdown>
                          </div>
                        )}

                        {dbResumeActiveSubTab === "skills" && (
                          <div className="space-y-5">
                            {dbResume.parsed?.summary && (
                              <div className="flex gap-3.5 p-4 bg-gradient-to-r from-primary-50/30 to-violet-50/30 rounded-xl border border-primary-100/50">
                                <div className="w-9 h-9 rounded-lg bg-primary-100/80 flex items-center justify-center flex-shrink-0 mt-0.5 shadow-sm">
                                  <FileText className="w-5 h-5 text-primary-600" />
                                </div>
                                <div>
                                  <p className="text-[10px] font-black text-primary-700 uppercase tracking-wide mb-1">Professional Summary</p>
                                  <p className="text-xs text-gray-700 leading-relaxed font-medium">{dbResume.parsed.summary}</p>
                                </div>
                              </div>
                            )}

                            {dbSkillCount > 0 ? (
                              <div>
                                <p className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3 flex items-center gap-1.5">
                                  <Sparkles className="w-4 h-4 text-primary-500" />
                                  Parsed Resume Skills
                                </p>
                                <div className="flex flex-wrap gap-1.5">
                                  {dbResume.parsed.skills.map((s) => <SkillBadge key={s} skill={s} />)}
                                </div>
                              </div>
                            ) : (
                              <EmptyState icon={AlertCircle} message="No skills extracted from this PDF resume" />
                            )}

                            {dbResume.parsed?.certifications?.length > 0 && (
                              <div className="pt-2">
                                <p className="text-xs font-bold uppercase tracking-wider text-amber-600 mb-3 flex items-center gap-1.5">
                                  <Award className="w-4 h-4 text-amber-500" /> Extracted Certifications
                                </p>
                                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                  {dbResume.parsed.certifications.map((c, i) => (
                                    <li key={i} className="flex items-center gap-2 text-xs font-semibold text-gray-700 bg-amber-50/40 border border-amber-100/50 rounded-xl px-3 py-2.5">
                                      <Award className="w-4 h-4 text-amber-500 flex-shrink-0" />
                                      {c}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        )}

                        {dbResumeActiveSubTab === "experience" && (
                          <div className="space-y-4">
                            {dbExpCount === 0 ? (
                              <EmptyState icon={Briefcase} message="No employment experience entries extracted" />
                            ) : (
                              dbResume.parsed.experience.map((exp, i) => (
                                <div key={i} className="group flex gap-4 p-4 rounded-xl border border-gray-100 hover:border-primary-200 hover:bg-primary-50/10 transition-all duration-200 bg-white shadow-sm">
                                  <div className="w-10 h-10 rounded-xl bg-indigo-50/70 border border-indigo-100 flex items-center justify-center flex-shrink-0">
                                    <Briefcase className="w-5 h-5 text-indigo-600" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-2 flex-wrap">
                                      <div>
                                        <p className="font-bold text-gray-900 text-sm sm:text-base">{exp.role}</p>
                                        <p className="text-xs text-primary-600 font-bold mt-0.5">{exp.company}</p>
                                      </div>
                                      {exp.duration && (
                                        <span className="badge-gray text-[10px] font-bold uppercase tracking-wide flex-shrink-0">{exp.duration}</span>
                                      )}
                                    </div>
                                    {exp.description && (
                                      <p className="text-xs text-gray-500 mt-2.5 leading-relaxed font-medium">{exp.description}</p>
                                    )}
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                        )}

                        {dbResumeActiveSubTab === "education" && (
                          <div className="space-y-4">
                            {dbEduCount === 0 ? (
                              <EmptyState icon={GraduationCap} message="No academic education entries extracted" />
                            ) : (
                              dbResume.parsed.education.map((edu, i) => (
                                <div key={i} className="flex gap-4 p-4 rounded-xl border border-gray-100 hover:border-green-200 hover:bg-green-50/10 transition-all duration-200 bg-white shadow-sm">
                                  <div className="w-10 h-10 rounded-xl bg-green-50/70 border border-green-100 flex items-center justify-center flex-shrink-0">
                                    <GraduationCap className="w-5 h-5 text-green-600" />
                                  </div>
                                  <div className="flex-1">
                                    <p className="font-bold text-gray-900 text-sm sm:text-base">{edu.degree}</p>
                                    <p className="text-xs text-primary-600 font-bold mt-0.5">{edu.institution}</p>
                                    <div className="flex gap-2.5 mt-2">
                                      {edu.year  && <span className="badge-gray text-[10px] font-bold">{edu.year}</span>}
                                      {edu.score && <span className="badge-green text-[10px] font-bold">Grade: {edu.score}</span>}
                                    </div>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {mode === "manual" && (
          <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
            <form onSubmit={handleSandboxSubmit} className="space-y-5">
              <div className="bg-indigo-50/30 border border-indigo-100 rounded-xl p-4 flex items-start gap-3 mb-1">
                <Info className="w-5 h-5 text-indigo-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-indigo-950 uppercase tracking-wider">Hypothetical Sandbox Environment</h4>
                  <p className="text-xs text-indigo-800 mt-0.5">
                    Tweak your current parameters manually. Test different skills combinations, academic degrees, and interest pathways to see how the NCF and Content similarity scores shift dynamically.
                  </p>
                </div>
              </div>

              <div>
                <label className="label uppercase text-[10px] font-extrabold tracking-wider text-gray-500">Your Interests Sandbox</label>
                <textarea
                  required rows={2} className="input resize-none"
                  placeholder="e.g. machine learning, web development, data analysis, cloud computing"
                  value={form.interests}
                  onChange={(e) => setForm({ ...form, interests: e.target.value })}
                />
              </div>
              <div>
                <label className="label uppercase text-[10px] font-extrabold tracking-wider text-gray-500">Your Current Skills <span className="text-gray-400 font-semibold">(comma-separated)</span></label>
                <textarea
                  required rows={2} className="input resize-none"
                  placeholder="e.g. Python, React, SQL, Docker, Machine Learning, TensorFlow"
                  value={form.skills}
                  onChange={(e) => setForm({ ...form, skills: e.target.value })}
                />
              </div>
              <div>
                <label className="label uppercase text-[10px] font-extrabold tracking-wider text-gray-500">Academic Background / Degree</label>
                <input
                  type="text" className="input"
                  placeholder="e.g. B.Tech Computer Science, MBA, Self-taught Engineer"
                  value={form.academicBackground}
                  onChange={(e) => setForm({ ...form, academicBackground: e.target.value })}
                />
              </div>
              <button type="submit" disabled={loadingRecommendation} className="btn-primary w-full py-3.5 text-sm font-bold flex items-center justify-center gap-2">
                {loadingRecommendation ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Training NCF Layers &amp; Evaluating Sandbox...</>
                ) : (
                  <><Sparkles className="w-4 h-4" /> Run Sandbox Career Recommendations</>
                )}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Loading State overlays */}
      {(loadingResume || loadingRecommendation) && !resumeResult && !recommendationResult && (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 shadow-sm text-center space-y-5">
          <div className="relative inline-block">
            <div className="w-20 h-20 rounded-2xl bg-primary-50 flex items-center justify-center shadow-inner">
              <Brain className="w-10 h-10 text-primary-500 animate-pulse" />
            </div>
            <Loader2 className="w-8 h-8 animate-spin text-primary-600 absolute -bottom-2 -right-2" />
          </div>
          <div className="max-w-md mx-auto">
            <p className="font-bold text-gray-800 text-lg">Activating ML Pipeline...</p>
            <p className="text-sm text-gray-400 mt-1.5">
              spaCy is extracting skill clusters and Groq is analyzing resumes in real-time, followed by NCF Collaborative Filtering scoring.
            </p>
          </div>
          <div className="flex gap-2.5 justify-center mt-3 flex-wrap">
            {["PDF Parsing", "NLP Entity Matching", "Groq AI Structuring", "Embedding Careers", "Collaborative scoring"].map((step, i) => (
              <span key={i} className="text-[10px] font-bold uppercase tracking-wider px-3.5 py-1.5 bg-primary-50/70 text-primary-700 rounded-lg border border-primary-100/50 animate-pulse" style={{ animationDelay: `${i * 150}ms` }}>
                {step}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Combined Output Grid (When Resume Uploaded & Recommendations are Ready) */}
      {mode === "resume" && resumeResult && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT PANEL: Resume Extraction Report */}
          <div className="lg:col-span-7 space-y-4">
            
            {/* Quick Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <StatCard label="Skills detected" value={skillCount} icon={Sparkles} color="primary" />
              <StatCard label="Experiences" value={expCount} icon={Briefcase} color="blue" />
              <StatCard label="Educations" value={eduCount} icon={GraduationCap} color="green" />
              <StatCard label="Certificates" value={certCount} icon={Award} color="amber" />
            </div>

            {/* Resume Details Viewer */}
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
              
              {/* Internal Tab selectors */}
              <div className="flex border-b border-gray-100 bg-gray-50/60 p-1.5 gap-1">
                {RESUME_TABS.map(({ id, label, icon: Icon }) => (
                  <button
                    key={id}
                    onClick={() => setResumeActiveSubTab(id)}
                    className={clsx(
                      "flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold rounded-lg border transition-all",
                      resumeActiveSubTab === id
                        ? "border-gray-200/80 bg-white text-primary-600 shadow-sm"
                        : "border-transparent text-gray-500 hover:text-gray-700 hover:bg-white/40"
                    )}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {label}
                  </button>
                ))}
              </div>

              {/* Subtab content */}
              <div className="p-6">
                
                {/* AI Audit Report */}
                {resumeActiveSubTab === "analysis" && (
                  <div className="prose prose-sm max-w-none text-gray-700 prose-headings:text-gray-900 prose-strong:text-gray-800 prose-li:text-gray-600 leading-relaxed">
                    <ReactMarkdown>{resumeResult.analysis}</ReactMarkdown>
                  </div>
                )}

                {/* Extracted Skills */}
                {resumeActiveSubTab === "skills" && (
                  <div className="space-y-5">
                    {resumeResult.parsed?.summary && (
                      <div className="flex gap-3.5 p-4 bg-gradient-to-r from-primary-50/30 to-violet-50/30 rounded-xl border border-primary-100/50">
                        <div className="w-9 h-9 rounded-lg bg-primary-100/80 flex items-center justify-center flex-shrink-0 mt-0.5 shadow-sm">
                          <FileText className="w-5 h-5 text-primary-600" />
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-primary-700 uppercase tracking-wide mb-1">Professional Summary</p>
                          <p className="text-xs text-gray-700 leading-relaxed font-medium">{resumeResult.parsed.summary}</p>
                        </div>
                      </div>
                    )}

                    {skillCount > 0 ? (
                      <div>
                        <p className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-3 flex items-center gap-1.5">
                          <Sparkles className="w-4 h-4 text-primary-500" />
                          Parsed Resume Skills
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {resumeResult.parsed.skills.map((s) => <SkillBadge key={s} skill={s} />)}
                        </div>
                      </div>
                    ) : (
                      <EmptyState icon={AlertCircle} message="No skills extracted from this PDF resume" />
                    )}

                    {resumeResult.parsed?.certifications?.length > 0 && (
                      <div className="pt-2">
                        <p className="text-xs font-bold uppercase tracking-wider text-amber-600 mb-3 flex items-center gap-1.5">
                          <Award className="w-4 h-4 text-amber-500" /> Extracted Certifications
                        </p>
                        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {resumeResult.parsed.certifications.map((c, i) => (
                            <li key={i} className="flex items-center gap-2 text-xs font-semibold text-gray-700 bg-amber-50/40 border border-amber-100/50 rounded-xl px-3 py-2.5">
                              <Award className="w-4 h-4 text-amber-500 flex-shrink-0" />
                              {c}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}

                {/* Professional Experience */}
                {resumeActiveSubTab === "experience" && (
                  <div className="space-y-4">
                    {expCount === 0 ? (
                      <EmptyState icon={Briefcase} message="No employment experience entries extracted" />
                    ) : (
                      resumeResult.parsed.experience.map((exp, i) => (
                        <div key={i} className="group flex gap-4 p-4 rounded-xl border border-gray-100 hover:border-primary-200 hover:bg-primary-50/10 transition-all duration-200 bg-white shadow-sm">
                          <div className="w-10 h-10 rounded-xl bg-indigo-50/70 border border-indigo-100 flex items-center justify-center flex-shrink-0">
                            <Briefcase className="w-5 h-5 text-indigo-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2 flex-wrap">
                              <div>
                                <p className="font-bold text-gray-900 text-sm sm:text-base">{exp.role}</p>
                                <p className="text-xs text-primary-600 font-bold mt-0.5">{exp.company}</p>
                              </div>
                              {exp.duration && (
                                <span className="badge-gray text-[10px] font-bold uppercase tracking-wide flex-shrink-0">{exp.duration}</span>
                              )}
                            </div>
                            {exp.description && (
                              <p className="text-xs text-gray-500 mt-2.5 leading-relaxed font-medium">{exp.description}</p>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* Education History */}
                {resumeActiveSubTab === "education" && (
                  <div className="space-y-4">
                    {eduCount === 0 ? (
                      <EmptyState icon={GraduationCap} message="No academic education entries extracted" />
                    ) : (
                      resumeResult.parsed.education.map((edu, i) => (
                        <div key={i} className="flex gap-4 p-4 rounded-xl border border-gray-100 hover:border-green-200 hover:bg-green-50/10 transition-all duration-200 bg-white shadow-sm">
                          <div className="w-10 h-10 rounded-xl bg-green-50/70 border border-green-100 flex items-center justify-center flex-shrink-0">
                            <GraduationCap className="w-5 h-5 text-green-600" />
                          </div>
                          <div className="flex-1">
                            <p className="font-bold text-gray-900 text-sm sm:text-base">{edu.degree}</p>
                            <p className="text-xs text-primary-600 font-bold mt-0.5">{edu.institution}</p>
                            <div className="flex gap-2.5 mt-2">
                              {edu.year  && <span className="badge-gray text-[10px] font-bold">{edu.year}</span>}
                              {edu.score && <span className="badge-green text-[10px] font-bold">Grade: {edu.score}</span>}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}

              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => { setFile(null); setResumeResult(null); setRecommendationResult(null); }}
                className="btn-secondary flex-1 py-2.5 border-dashed text-xs text-gray-400 font-bold hover:text-red-600 hover:border-red-200 transition-colors"
              >
                Upload Different Resume File
              </button>
              <button 
                onClick={handleClearCachedReport}
                className="btn-secondary py-2.5 text-xs text-red-500 border-red-100 hover:bg-red-50 px-4 font-bold"
                title="Delete Cached Analysis"
              >
                <Trash2 className="w-4 h-4 mr-1 inline" /> Clear Cache
              </button>
            </div>
          </div>

          {/* RIGHT PANEL: Career Recommendations Dashboard */}
          <div className="lg:col-span-5 space-y-4">
            {loadingRecommendation ? (
              <div className="bg-white rounded-2xl border border-gray-100 p-8 shadow-sm text-center">
                <Loader2 className="w-8 h-8 animate-spin text-primary-500 mx-auto mb-2" />
                <p className="text-gray-700 text-sm font-semibold">Generating recommendations...</p>
                <p className="text-xs text-gray-400 mt-0.5">Scoring skills with Hybrid models</p>
              </div>
            ) : recommendationResult ? (
              <CareerRecommendationsList recommendations={recommendationResult} onRateCareer={handleRateCareer} navigate={navigate} />
            ) : (
              <div className="bg-white rounded-2xl border border-gray-100 p-8 shadow-sm text-center">
                <AlertCircle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                <p className="text-sm font-bold text-gray-800">Recommendation Processing</p>
                <p className="text-xs text-gray-500 mt-1">We couldn't generate career paths. Please re-submit the resume above.</p>
              </div>
            )}
          </div>
          
        </div>
      )}

      {/* Standalone Career Output Card (For Saved Profile & Sandbox Mode) */}
      {mode !== "resume" && (
        <div className="w-full">
          {loadingRecommendation && (
            <div className="bg-white rounded-2xl border border-gray-100 p-12 shadow-sm text-center space-y-4">
              <Loader2 className="w-10 h-10 animate-spin text-primary-500 mx-auto mb-2" />
              <div>
                <p className="font-bold text-gray-800 text-base">Generating Recommendations...</p>
                <p className="text-xs text-gray-400 mt-1">Mapping skills, interests &amp; academic paths to industry demands.</p>
              </div>
            </div>
          )}

          {recommendationResult && !loadingRecommendation && (
            <div className="max-w-4xl mx-auto">
              <CareerRecommendationsList recommendations={recommendationResult} onRateCareer={handleRateCareer} navigate={navigate} />
            </div>
          )}
        </div>
      )}

    </div>
  );
}

// Extracted Sub-component representing the interactive Career Recommendations dashboard list and ratings
function CareerRecommendationsList({ recommendations, onRateCareer, navigate }) {
  const normalizedList = Array.isArray(recommendations) ? recommendations : [recommendations];
  const [activeIdx, setActiveIdx] = useState(0);

  if (normalizedList.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-gray-150 p-8 shadow-sm text-center">
        <AlertCircle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
        <p className="text-sm font-bold text-gray-800">Recommendation Processing</p>
        <p className="text-xs text-gray-500 mt-1">We couldn't generate career paths. Please re-submit the resume above.</p>
      </div>
    );
  }

  const activeItem = normalizedList[activeIdx] || normalizedList[0];

  return (
    <div className="space-y-6">
      {/* List Header */}
      <div className="bg-white rounded-2xl border border-gray-150 p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <div>
            <h2 className="text-base sm:text-lg font-black text-gray-900 flex items-center gap-1.5">
              <Sparkles className="w-5 h-5 text-primary-500 animate-pulse" />
              Top Recommended Career Paths
            </h2>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
              Powered by 3-Engine SVD Collaborative Filter & NCF Matching
            </p>
          </div>
          <span className="text-[9px] font-bold text-primary-600 bg-primary-50 border border-primary-100 px-2 py-0.5 rounded-full uppercase tracking-wider">
            Live AI Feedback Loop Active
          </span>
        </div>

        {/* List of Careers */}
        <div className="space-y-3">
          {normalizedList.map((item, idx) => {
            const isSelected = idx === activeIdx;
            const matchPercentage = item.matchPercentage || (item.finalScore ? (item.finalScore * 100).toFixed(1) : 0);
            
            return (
              <div
                key={item.id || item.careerRoleId || idx}
                onClick={() => setActiveIdx(idx)}
                className={clsx(
                  "p-4 rounded-xl border transition-all duration-200 cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm",
                  isSelected
                    ? "border-primary-300 bg-primary-50/20 ring-1 ring-primary-200"
                    : "border-gray-100 hover:border-gray-200 hover:bg-gray-50 bg-white"
                )}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className={clsx(
                    "w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 border",
                    isSelected 
                      ? "bg-primary-100/70 border-primary-200 text-primary-600" 
                      : "bg-gray-50 border-gray-100 text-gray-400"
                  )}>
                    <Briefcase className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-extrabold text-sm sm:text-base text-gray-900 truncate">
                      {cleanTitle(item.careerTitle || item.jobTitle || "Custom Path")}
                    </h3>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wide truncate">
                      {item.industry || "General Industry"}
                    </p>
                  </div>
                </div>

                {/* Rating & Score alignment */}
                <div className="flex items-center justify-between sm:justify-end gap-5 flex-shrink-0">
                  {/* Premium Golden Star Rating component */}
                  <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center">
                      {[1, 2, 3, 4, 5].map((star) => {
                        const currentRating = item.userRating || 0;
                        const isStarred = star <= currentRating;
                        return (
                          <button
                            key={star}
                            onClick={() => onRateCareer(item.careerRoleId, star, item.careerTitle || item.jobTitle)}
                            className="p-0.5 hover:scale-125 transition-transform text-amber-400 focus:outline-none"
                            title={`Rate ${star} stars`}
                          >
                            <Star
                              className={clsx(
                                "w-4 h-4",
                                isStarred ? "fill-amber-400 text-amber-500" : "text-gray-300 hover:text-amber-300"
                              )}
                            />
                          </button>
                        );
                      })}
                    </div>
                    {item.userRating && (
                      <span className="text-[10px] text-amber-600 font-extrabold bg-amber-50 border border-amber-100/50 px-1.5 py-0.5 rounded">
                        {item.userRating}★
                      </span>
                    )}
                  </div>

                  <span className={clsx(
                    "badge-green text-xs font-black px-2.5 py-1 flex-shrink-0 shadow-sm border",
                    isSelected ? "border-green-200" : "border-transparent"
                  )}>
                    {matchPercentage}% Match
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Detail panel of the Active Career */}
      <div className="bg-white rounded-2xl border border-gray-150 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-gray-100 gap-3">
          <div>
            <span className="text-[10px] font-black text-primary-600 uppercase tracking-widest block">Selected Path Analysis</span>
            <h2 className="text-lg sm:text-xl font-black text-gray-900 mt-1 flex items-center gap-2">
              {cleanTitle(activeItem.careerTitle || activeItem.jobTitle)}
            </h2>
          </div>
          <div className="flex gap-2">
            {activeItem.avg_salary && (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-gray-500 bg-gray-50 border border-gray-100 rounded-lg px-2.5 py-1">
                <DollarSign className="w-3.5 h-3.5 text-gray-400" />
                Avg: {activeItem.avg_salary} LPA
              </span>
            )}
            {activeItem.growth_rate && (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-100 rounded-lg px-2.5 py-1">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                +{activeItem.growth_rate}% Growth
              </span>
            )}
          </div>
        </div>

        {/* Narrative Description block */}
        <div className="bg-gradient-to-br from-indigo-50/10 to-primary-50/10 border border-primary-100/50 rounded-xl p-4">
          <h3 className="text-xs font-extrabold text-primary-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Brain className="w-4 h-4 text-primary-500" /> Direct Recommendation Path
          </h3>
          <div className="prose prose-sm max-w-none text-gray-700 leading-relaxed font-medium text-xs sm:text-sm">
            <ReactMarkdown>{activeItem.description || "Generating..."}</ReactMarkdown>
          </div>
        </div>

        {/* Dynamic Interactive Progress Breakdown */}
        {activeItem.scoreBreakdown && (
          <div className="bg-gray-50/60 border border-gray-100 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-wide flex items-center gap-1">
                <BarChart2 className="w-3.5 h-3.5 text-primary-500" />
                Explainable AI Matching Weights
              </h4>
              <span className="text-[9px] text-primary-600 bg-primary-50 border border-primary-100 font-bold px-1.5 py-0.5 rounded">Explainable AI</span>
            </div>

            <div className="grid grid-cols-3 gap-2.5 text-center">
              <div className="bg-white p-2.5 rounded-lg border border-gray-100 shadow-sm">
                <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wide block">Content similarity</span>
                <span className="text-sm font-black text-gray-800 block mt-1">{(parseFloat(activeItem.scoreBreakdown.content) * 100).toFixed(0)}%</span>
                <div className="w-full bg-gray-100 h-1 rounded-full mt-1.5 overflow-hidden">
                  <div className="bg-blue-500 h-full rounded-full" style={{ width: `${parseFloat(activeItem.scoreBreakdown.content) * 100}%` }} />
                </div>
              </div>

              <div className="bg-white p-2.5 rounded-lg border border-gray-100 shadow-sm">
                <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wide block">NCF Collaborative</span>
                <span className="text-sm font-black text-gray-800 block mt-1">{(parseFloat(activeItem.scoreBreakdown.collaborative) * 100).toFixed(0)}%</span>
                <div className="w-full bg-gray-100 h-1 rounded-full mt-1.5 overflow-hidden">
                  <div className="bg-violet-500 h-full rounded-full" style={{ width: `${parseFloat(activeItem.scoreBreakdown.collaborative) * 100}%` }} />
                </div>
              </div>

              <div className="bg-white p-2.5 rounded-lg border border-gray-100 shadow-sm">
                <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wide block">Market Demand</span>
                <span className="text-sm font-black text-gray-800 block mt-1">{(parseFloat(activeItem.scoreBreakdown.market) * 100).toFixed(0)}%</span>
                <div className="w-full bg-gray-100 h-1 rounded-full mt-1.5 overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${parseFloat(activeItem.scoreBreakdown.market) * 100}%` }} />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Skill Gap Analysis inside card with study resources */}
        <div className="space-y-4">
          <h3 className="text-xs font-extrabold text-gray-500 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-primary-500" /> Skill Competencies Audit
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Matched skills */}
            <div className="bg-green-50/20 border border-green-100/50 rounded-xl p-4">
              <span className="text-[10px] font-bold text-green-700 uppercase tracking-wider flex items-center gap-1 mb-2">
                <CheckCircle className="w-3.5 h-3.5 text-green-500" />
                Skills You Have ({activeItem.matchedSkills?.length || 0})
              </span>
              {activeItem.matchedSkills && activeItem.matchedSkills.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {activeItem.matchedSkills.map((s) => (
                    <span key={s} className="bg-green-50 text-green-700 border border-green-100 px-2 py-0.5 rounded text-[10px] font-bold">
                      {s}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-[11px] text-gray-400 font-medium">Acquire core skills to start matching.</p>
              )}
            </div>

            {/* Missing Skills with Direct Learning Resources */}
            <div className="bg-amber-50/20 border border-amber-100/50 rounded-xl p-4">
              <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider flex items-center gap-1 mb-2">
                <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
                Deficit Skills to Learn ({activeItem.missingSkills?.length || 0})
              </span>
              {activeItem.learning_resources && activeItem.learning_resources.length > 0 ? (
                <div className="space-y-2">
                  {activeItem.learning_resources.map((item, idx) => {
                    const isGoogle = item.url?.includes("google.com");
                    const resourceName = isGoogle
                      ? "Quick Search"
                      : item.url?.includes("coursera.org")
                      ? "Coursera Syllabus"
                      : item.url?.includes("freecodecamp.org")
                      ? "freeCodeCamp Path"
                      : item.url?.includes("youtube.com")
                      ? "YouTube Bootcamp"
                      : "Official Course";
                    
                    return (
                      <div key={idx} className="flex items-center justify-between gap-3 bg-white border border-gray-100 p-2 rounded-lg shadow-sm">
                        <span className="text-[11px] font-bold text-gray-800 truncate">{item.skill}</span>
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 text-[10px] font-extrabold text-primary-700 bg-primary-50 hover:bg-primary-100 border border-primary-200 px-2.5 py-1 rounded transition-colors flex-shrink-0"
                        >
                          <BookOpen className="w-3 h-3 text-primary-500" />
                          {resourceName}
                        </a>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-[11px] text-gray-400 font-medium">Congratulations! You meet all required skills for this role.</p>
              )}
            </div>
          </div>
        </div>

        {/* Roadmap steps timeline */}
        {activeItem.roadmapSteps && (
          <div className="bg-gray-50/50 border border-gray-100 rounded-xl p-4 space-y-2">
            <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-wider flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-primary-500" />
              Syllabus Study Pathway Timeline
            </h4>
            <ul className="space-y-2 pt-1">
              {activeItem.roadmapSteps.map((step, sIdx) => (
                <li key={sIdx} className="flex items-start gap-2.5 text-xs text-gray-700 font-semibold">
                  <span className="w-5 h-5 rounded-full bg-primary-100 text-primary-700 border border-primary-200 flex items-center justify-center text-[10px] font-black flex-shrink-0 mt-0.5">
                    {sIdx + 1}
                  </span>
                  <div className="pt-0.5">{step}</div>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Direct Action buttons */}
        <div className="pt-4 border-t border-gray-100 flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => navigate("/career-trajectory")}
            className="btn-primary flex-1 py-3 text-xs font-bold flex items-center justify-center gap-2"
          >
            <TrendingUp className="w-4 h-4" /> Simulate Career Path Tree
          </button>
          <button
            onClick={() => navigate(`/skill-gap?target=${encodeURIComponent(cleanTitle(activeItem.careerTitle || activeItem.jobTitle))}`)}
            className="btn-secondary flex-1 py-3 text-xs font-bold border-gray-200 flex items-center justify-center gap-2"
          >
            <BarChart2 className="w-4 h-4 text-gray-500" /> Run Skill Gap Audit
          </button>
        </div>
      </div>
    </div>
  );
}
