import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import { getSkillGap, analyzeSkillGap, listSkillGapCareers, generateLearningPath, getProfile } from "../api/index";
import { useAuthStore } from "../store/authStore";
import { 
  Target, CheckCircle, XCircle, Loader2, BookOpen, Award, 
  Calendar, Briefcase, ExternalLink, Sparkles, AlertCircle, ChevronRight, 
  GraduationCap, Clock, Check, ListChecks, Star, Bookmark, PlayCircle, Trophy
} from "lucide-react";
import toast from "react-hot-toast";

function GaugeBar({ pct }) {
  const colorClass = pct >= 70 
    ? "from-emerald-400 to-teal-500 shadow-emerald-500/20" 
    : pct >= 40 
      ? "from-amber-400 to-orange-500 shadow-amber-500/20" 
      : "from-rose-500 to-red-500 shadow-rose-500/20";
  return (
    <div className="w-full bg-slate-100/80 rounded-full h-4 overflow-hidden shadow-inner relative border border-slate-200/50">
      {/* Glossy overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent pointer-events-none z-10" />
      <div
        className={`h-full rounded-full bg-gradient-to-r transition-all duration-1000 ease-out shadow-lg relative ${colorClass}`}
        style={{ width: `${pct}%` }}
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_right,_var(--tw-gradient-stops))] from-white/30 to-transparent animate-pulse pointer-events-none" />
      </div>
    </div>
  );
}

export default function SkillGap() {
  const { user, updateUser } = useAuthStore();
  const [searchParams, setSearchParams] = useSearchParams();
  const targetCareerParam = searchParams.get("target") || "";

  const [selectedCareer, setSelectedCareer] = useState("");
  const [report, setReport] = useState(null);
  const [learningPath, setLearningPath] = useState(null);
  const [certifications, setCertifications] = useState(null);
  const [contentBased, setContentBased] = useState(null);
  
  // Custom duration configuration
  const [duration, setDuration] = useState(6); // 3, 6, or 12 months
  const [activeMonthIdx, setActiveMonthIdx] = useState(0);
  const [activeSubTab, setActiveSubTab] = useState("path"); // "path", "certs", "content"
  
  // Persistent checklists loaded from localStorage
  const [completedTasks, setCompletedTasks] = useState({});
  const [trackedCerts, setTrackedCerts] = useState([]);

  // Load user-specific checklists when user is ready
  useEffect(() => {
    if (!user?.id) return;
    try {
      const savedTasks = localStorage.getItem(`talentforge_skill_gap_tasks_${user.id}`);
      setCompletedTasks(savedTasks ? JSON.parse(savedTasks) : {});
      const savedCerts = localStorage.getItem(`talentforge_tracked_certs_${user.id}`);
      setTrackedCerts(savedCerts ? JSON.parse(savedCerts) : []);
    } catch {
      setCompletedTasks({});
      setTrackedCerts([]);
    }
  }, [user?.id]);

  // Sync profile data on component mount
  useQuery({
    queryKey: ["userProfile", user?.id],
    queryFn: () => getProfile().then((r) => {
      const latestUser = r.data.data;
      if (latestUser) {
        updateUser(latestUser);
      }
      return latestUser;
    }),
    enabled: !!user?.id,
  });

  // Fetch initial Skill Gap default
  const { data: defaultData, isLoading: defaultLoading } = useQuery({
    queryKey: ["skillGapDefault", user?.id],
    queryFn: () => getSkillGap().then((r) => r.data.data),
    onSuccess: (d) => { 
      if (!report) setReport(d.report); 
    },
    enabled: !!user?.id,
  });

  // Fetch available career targets
  const { data: careersData } = useQuery({
    queryKey: ["skillGapCareers"],
    queryFn: () => listSkillGapCareers().then((r) => r.data.data.careers),
  });

  const careers = careersData || [];

  // Deep Link Trigger: Auto-analyze if parameter is present in URL
  useEffect(() => {
    if (targetCareerParam && careers.length > 0) {
      const matched = careers.find(c => c.toLowerCase() === targetCareerParam.toLowerCase()) || 
                      careers.find(c => c.toLowerCase().includes(targetCareerParam.toLowerCase())) ||
                      targetCareerParam;
      
      if (matched && matched !== selectedCareer) {
        setSelectedCareer(matched);
        gapMutation.mutate(matched);
        pathMutation.mutate({ career: matched, durationMonths: duration });
      }
    }
  }, [targetCareerParam, careers]);

  // Skill Gap analysis mutation
  const gapMutation = useMutation({
    mutationFn: (career) => analyzeSkillGap({ targetCareer: career }).then((r) => r.data.data.report),
    onSuccess: (data) => { 
      setReport(data); 
      toast.success(`Skill gap evaluated for ${data.targetCareer}!`); 
    },
    onError: () => toast.error("Skill gap analysis failed"),
  });

  // Learning Path AI Generation mutation
  const pathMutation = useMutation({
    mutationFn: ({ career, durationMonths }) => 
      generateLearningPath({ targetCareer: career, durationMonths }).then((r) => r.data.data),
    onSuccess: (data) => {
      setLearningPath(data.learningPath);
      setCertifications(data.certifications);
      setContentBased(data.contentBased);
      setActiveMonthIdx(0); // Reset to Month 1 on new load
      toast.success("AI Growth syllabus compiled successfully!");
    },
    onError: () => {
      toast.error("Could not compile AI learning path");
    }
  });

  const activeReport = report || defaultData?.report;

  // Trigger background AI roadmap when target career changes
  useEffect(() => {
    const targetCareer = activeReport?.targetCareer;
    if (targetCareer && !learningPath && !pathMutation.isPending) {
      pathMutation.mutate({ career: targetCareer, durationMonths: duration });
    }
  }, [activeReport, learningPath]);

  // Trigger compilation if duration changes
  const handleDurationChange = (newDuration) => {
    setDuration(newDuration);
    const targetCareer = activeReport?.targetCareer || selectedCareer;
    if (targetCareer) {
      pathMutation.mutate({ career: targetCareer, durationMonths: newDuration });
    }
  };

  const handleAnalyze = () => {
    if (!selectedCareer) return;
    setLearningPath(null);
    setCertifications(null);
    setContentBased(null);
    gapMutation.mutate(selectedCareer);
    pathMutation.mutate({ career: selectedCareer, durationMonths: duration });
  };

  // Toggle Task Completion
  const toggleTask = (key) => {
    const updated = { ...completedTasks, [key]: !completedTasks[key] };
    setCompletedTasks(updated);
    if (user?.id) {
      localStorage.setItem(`talentforge_skill_gap_tasks_${user.id}`, JSON.stringify(updated));
    }
    toast.success(updated[key] ? "Concept checked off! Keep it up." : "Task marked incomplete.");
  };

  // Toggle Cert Tracked Status
  const toggleTrackCert = (certName) => {
    let updated;
    if (trackedCerts.includes(certName)) {
      updated = trackedCerts.filter(c => c !== certName);
      toast.success("Removed certification from target board");
    } else {
      updated = [...trackedCerts, certName];
      toast.success("Certification added to target board!");
    }
    setTrackedCerts(updated);
    if (user?.id) {
      localStorage.setItem(`talentforge_tracked_certs_${user.id}`, JSON.stringify(updated));
    }
  };

  // Parser: Splits learningPath output into monthly study plan blocks
  const parseDetailedLearningPath = (text, expectedMonths = 6) => {
    if (!text) return [];
    
    const regex = /(?:MONTH|Month)_?\s*(\d+)[\s*:-]*/gi;
    const parts = text.split(regex);
    const months = [];
    
    if (parts.length > 2) {
      for (let i = 1; i < parts.length; i += 2) {
        const num = parseInt(parts[i], 10);
        const rawContent = parts[i + 1]?.trim() || "";
        
        const lines = rawContent.split("\n").map(l => l.trim()).filter(Boolean);
        const topics = [];
        const resources = [];
        let project = "";
        
        let currentSection = "topics";
        
        lines.forEach((line) => {
          const lower = line.toLowerCase();
          
          if (lower.includes("key topics to master") || lower.includes("topics to master") || lower.includes("topics:") || lower.startsWith("1.") || lower.startsWith("### 1")) {
            currentSection = "topics";
            return;
          }
          if (lower.includes("recommended study resources") || lower.includes("study resources") || lower.includes("resources:") || lower.startsWith("2.") || lower.startsWith("### 2")) {
            currentSection = "resources";
            return;
          }
          if (lower.includes("hands-on milestone project") || lower.includes("milestone project") || lower.includes("project:") || lower.startsWith("3.") || lower.startsWith("### 3")) {
            currentSection = "project";
            return;
          }
          
          const cleanLine = line.replace(/^[-*•\d+.]\s*/, "").trim();
          if (!cleanLine) return;
          
          if (currentSection === "topics") {
            topics.push(cleanLine);
          } else if (currentSection === "resources") {
            resources.push(cleanLine);
          } else if (currentSection === "project") {
            project += (project ? " " : "") + cleanLine;
          }
        });
        
        // Fallback if no specific tags matches
        if (topics.length === 0 && resources.length === 0) {
          lines.forEach(line => {
            const cleanLine = line.replace(/^[-*•\d+.]\s*/, "").trim();
            if (cleanLine) topics.push(cleanLine);
          });
        }
        
        months.push({
          num,
          title: `Month ${num}`,
          topics: topics,
          resources: resources,
          project: project || "Build a portfolio-grade project showcasing the skills acquired this month."
        });
      }
    } else {
      // Fallback chunking
      const lines = text.split("\n").map(l => l.trim()).filter(Boolean);
      const chunkSize = Math.max(1, Math.ceil(lines.length / expectedMonths));
      for (let m = 1; m <= expectedMonths; m++) {
        const monthLines = lines.slice((m - 1) * chunkSize, m * chunkSize);
        months.push({
          num: m,
          title: `Month ${m}`,
          topics: monthLines,
          resources: [
            `Search Coursera courses on ${selectedCareer || "Specialized Technology"}`,
            `Search YouTube tutorials on ${selectedCareer || "Specialized Tech"}`
          ],
          project: `Develop a real-world milestone project applying ${selectedCareer || "relevant"} methodologies.`
        });
      }
    }
    
    return months.sort((a, b) => a.num - b.num);
  };

  // Parser: Splits certifications output into stylized cards
  const parseCertifications = (text) => {
    if (!text) return [];
    const lines = text.split("\n");
    const certs = [];
    let currentCert = null;
    
    lines.forEach((line) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      
      const isNewCertStart = trimmed.match(/^[-*•\d+.]\s+(.+)$/);
      const hasCertKeywords = trimmed.toLowerCase().includes("cert") || 
                              trimmed.toLowerCase().includes("associate") || 
                              trimmed.toLowerCase().includes("professional") ||
                              trimmed.toLowerCase().includes("practitioner") ||
                              trimmed.match(/^[1-5]\.\s+\w+/);
                              
      if (isNewCertStart && hasCertKeywords && 
          !trimmed.toLowerCase().includes("provider:") && 
          !trimmed.toLowerCase().includes("difficulty:") && 
          !trimmed.toLowerCase().includes("cost:") && 
          !trimmed.toLowerCase().includes("why:")) {
        if (currentCert) {
          certs.push(currentCert);
        }
        let certName = isNewCertStart[1].replace(/^\*\*|\*\*$/g, "").trim();
        certName = certName.replace(/[:-\s]+$/, "").trim();
        currentCert = {
          name: certName,
          provider: "Industry Provider",
          difficulty: "Intermediate",
          cost: "Standard Fee",
          why: "",
          link: `https://www.google.com/search?q=${encodeURIComponent(certName + " certification")}`
        };
      } else if (currentCert) {
        const lowerLine = trimmed.toLowerCase();
        const colonIndex = trimmed.indexOf(":");
        if (colonIndex !== -1) {
          const key = lowerLine.substring(0, colonIndex);
          const value = trimmed.substring(colonIndex + 1).replace(/^[\s*`"]+|[\s*`"]+$/g, "").trim();
          
          if (key.includes("provider")) {
            currentCert.provider = value;
            if (value.toLowerCase().includes("aws")) currentCert.link = "https://aws.amazon.com/certification/";
            else if (value.toLowerCase().includes("google")) currentCert.link = "https://grow.google/certificates/";
            else if (value.toLowerCase().includes("microsoft")) currentCert.link = "https://learn.microsoft.com/credentials/";
          } else if (key.includes("difficulty")) {
            currentCert.difficulty = value;
          } else if (key.includes("cost") || key.includes("price")) {
            currentCert.cost = value;
          } else if (key.includes("valuable") || key.includes("why")) {
            currentCert.why = value;
          } else {
            currentCert.why += (currentCert.why ? " " : "") + trimmed;
          }
        } else {
          const cleanVal = trimmed.replace(/^[-*•\s]+/g, "");
          if (cleanVal && !lowerLine.includes("estimated_cost") && !lowerLine.includes("cert_name")) {
            currentCert.why += (currentCert.why ? " " : "") + cleanVal;
          }
        }
      }
    });
    
    if (currentCert) {
      certs.push(currentCert);
    }
    
    // High-quality defaults if parsing yields no result
    return certs.length > 0 ? certs : [
      {
        name: `Professional Certificate in ${activeReport?.targetCareer || "Data Science"}`,
        provider: "Coursera / IBM / Google",
        difficulty: "Intermediate",
        cost: "Subscription ($39/mo)",
        why: "Provides deep hands-on conceptual foundations and validation portfolio projects.",
        link: "https://www.coursera.org"
      },
      {
        name: `AWS Certified Specialist - ${activeReport?.targetCareer || "Solutions"}`,
        provider: "Amazon Web Services (AWS)",
        difficulty: "Advanced",
        cost: "$300 USD",
        why: "Benchmark industry validation for implementing complex enterprise architecture pipelines.",
        link: "https://aws.amazon.com/certification/"
      },
      {
        name: `Microsoft Certified Associate Credential`,
        provider: "Microsoft Learn",
        difficulty: "Beginner",
        cost: "$165 USD",
        why: "Premier structured syllabus validating engineering execution on Azure frameworks.",
        link: "https://learn.microsoft.com"
      }
    ];
  };

  const parsedMonths = parseDetailedLearningPath(learningPath, duration);
  const activeMonth = parsedMonths[activeMonthIdx] || parsedMonths[0];

  // Progress calculator for active month's checkboxes
  const activeMonthProgress = () => {
    if (!activeMonth?.topics || activeMonth.topics.length === 0) return 0;
    const completed = activeMonth.topics.filter(t => completedTasks[`${activeReport?.targetCareer}_m${activeMonth.num}_${t}`]);
    return Math.round((completed.length / activeMonth.topics.length) * 100);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fadeIn text-slate-800 pb-12">
      {/* Premium Glassmorphic Indigo Header */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-indigo-50/90 via-white to-purple-50/60 text-slate-800 p-8 md:p-10 shadow-lg border border-indigo-100/80 shadow-indigo-100/10">
        {/* Ambient Glows */}
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-indigo-400/5 rounded-full blur-[100px] pointer-events-none animate-pulse" />
        <div className="absolute -bottom-20 -left-20 w-[300px] h-[300px] bg-purple-400/5 rounded-full blur-[80px] pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-4 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-100/80 hover:bg-indigo-200/80 text-indigo-700 text-xs font-black tracking-wider border border-indigo-200/60 transition-all shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-spin animate-infinite" style={{ animationDuration: '4s' }} /> 
              <span>AI SYLLABUS &amp; SKILL DISCOVERY</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-black tracking-tight leading-tight bg-gradient-to-r from-slate-900 via-indigo-950 to-indigo-900 bg-clip-text text-transparent">
              Personalized AI Growth Pathways
            </h1>
            <p className="text-slate-600 text-sm md:text-base font-medium leading-relaxed max-w-2xl">
              Synthesize custom learning strategies to target specialized career roles. Enter your target, 
              configure your time horizon, and unlock interactive study roadmaps, recommended search links, 
              and target industry credentials to bridge your skill gaps.
            </p>
          </div>
          <div className="flex-shrink-0 flex items-center">
            <div className="p-5 bg-gradient-to-tr from-indigo-100 to-purple-100 rounded-2xl border border-indigo-200/50 shadow-md shadow-indigo-100/5 backdrop-blur-md relative group hover:scale-105 transition-all duration-300">
              <Target className="w-12 h-12 text-indigo-600 relative z-10 animate-pulse" />
            </div>
          </div>
        </div>
      </div>

      {/* Configuration & Selection Card */}
      <div className="bg-white border border-slate-200/80 shadow-md p-6 md:p-8 rounded-3xl grid md:grid-cols-12 gap-6 items-center hover:shadow-lg hover:border-slate-350 transition-all duration-300">
        {/* Career Selector */}
        <div className="md:col-span-6 space-y-2">
          <label className="text-xs font-black text-slate-400 uppercase tracking-widest block flex items-center gap-1.5">
            <Briefcase className="w-3.5 h-3.5 text-indigo-500" /> Select Your Target Profession
          </label>
          <div className="relative">
            <select
              className="w-full rounded-xl border border-slate-200 px-4 py-3 bg-slate-50/50 text-slate-800 font-bold focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all text-sm shadow-inner appearance-none cursor-pointer pr-10"
              value={selectedCareer}
              onChange={(e) => setSelectedCareer(e.target.value)}
            >
              <option value="" className="text-slate-400">-- Specify Career Direction --</option>
              {careers.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-slate-400">
              <ChevronRight className="w-4 h-4 transform rotate-90" />
            </div>
          </div>
        </div>

        {/* Time Horizon Selector */}
        <div className="md:col-span-4 space-y-2">
          <label className="text-xs font-black text-slate-400 uppercase tracking-widest block flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-indigo-500" /> How much time do you have?
          </label>
          <div className="relative flex bg-slate-100/80 p-1.5 rounded-xl border border-slate-200/50 shadow-inner">
            {[3, 6, 12].map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => handleDurationChange(m)}
                className={`flex-1 py-2 px-1 text-xs font-black rounded-lg transition-all duration-300 relative z-10 ${
                  duration === m 
                    ? "bg-white text-indigo-600 shadow-md border border-slate-200/40 scale-105" 
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                {m} Months
              </button>
            ))}
          </div>
        </div>

        {/* Trigger Button */}
        <div className="md:col-span-2 pt-5">
          <button
            onClick={handleAnalyze}
            disabled={!selectedCareer || gapMutation.isPending || pathMutation.isPending}
            className="w-full py-3 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/35 hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-50 disabled:pointer-events-none"
          >
            {gapMutation.isPending || pathMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin animate-infinite" /> Analyzing...
              </>
            ) : (
              <>
                <Target className="w-4 h-4" /> Run Audit
              </>
            )}
          </button>
        </div>
      </div>
       {/* Main E2E Dashboard */}
      {(defaultLoading && !activeReport) ? (
        <div className="bg-white border border-slate-200/80 p-20 rounded-3xl text-center shadow-lg">
          <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
          <p className="text-sm font-bold text-slate-600">Retrieving system baseline profile matrices...</p>
          <p className="text-xs text-slate-400 mt-1">This will only take a few moments.</p>
        </div>
      ) : activeReport ? (
        <div className="space-y-8 animate-fadeIn">
          {/* Top Level Gap Competency Score Card */}
          <div className="bg-white border border-indigo-100/60 p-6 md:p-8 rounded-3xl shadow-lg relative overflow-hidden group">
            {/* Decorative subtle rotating mesh blur */}
            <div className="absolute -top-12 -right-12 w-64 h-64 bg-indigo-500/5 rounded-full blur-[60px] pointer-events-none group-hover:scale-110 transition-transform duration-700" />
            <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-emerald-500/5 rounded-full blur-[60px] pointer-events-none group-hover:scale-110 transition-transform duration-700" />
            
            <div className="grid md:grid-cols-12 gap-6 items-center relative z-10">
              <div className="md:col-span-4 space-y-2">
                <span className="inline-flex items-center gap-1 text-[10px] font-black bg-indigo-100 text-indigo-700 px-2.5 py-1 rounded-full uppercase tracking-wider border border-indigo-200/50">
                  <Target className="w-3 h-3" /> ACTIVE ANALYSIS TARGET
                </span>
                <h3 className="text-3xl font-black text-slate-800 tracking-tight">{activeReport.targetCareer}</h3>
                <p className="text-xs text-slate-450">Match score computed via dense TF-IDF comparison</p>
              </div>

              <div className="md:col-span-5 space-y-3">
                <div className="flex justify-between items-center text-xs font-black text-slate-500 uppercase tracking-wider">
                  <span>Syllabus Deficit Gap</span>
                  <span className="text-indigo-600 font-extrabold">{activeReport.matchPercentage}% Match</span>
                </div>
                <GaugeBar pct={activeReport.matchPercentage} />
              </div>

              <div className="md:col-span-3 text-center md:text-right">
                <div className="inline-block bg-gradient-to-br from-indigo-50/60 to-indigo-100/40 border border-indigo-100/80 p-4 rounded-2xl text-center shadow-sm">
                  <div className="text-3xl font-black text-indigo-700">
                    {activeReport.matchedSkills?.length || 0} <span className="text-slate-400 font-light text-xl">/</span> {activeReport.requiredSkills?.length || 0}
                  </div>
                  <div className="text-[10px] font-black text-slate-450 uppercase tracking-widest mt-1">Skills Acquired</div>
                </div>
              </div>
            </div>
          </div>

          {/* Sub-Tabs Selector */}
          <div className="flex bg-slate-100 p-1.5 rounded-2xl border border-slate-200 shadow-inner gap-2 max-w-xl">
            <button
              onClick={() => setActiveSubTab("path")}
              className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 text-xs font-extrabold rounded-xl transition-all duration-300 hover:scale-102 ${
                activeSubTab === "path"
                  ? "bg-white text-indigo-600 shadow-md border border-slate-200/40 scale-102"
                  : "text-slate-500 hover:text-slate-850"
              }`}
            >
              <Calendar className="w-4 h-4 text-indigo-500 animate-infinite" /> {duration}-Month Path
            </button>
            <button
              onClick={() => setActiveSubTab("certs")}
              className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 text-xs font-extrabold rounded-xl transition-all duration-300 hover:scale-102 ${
                activeSubTab === "certs"
                  ? "bg-white text-indigo-600 shadow-md border border-slate-200/40 scale-102"
                  : "text-slate-500 hover:text-slate-850"
              }`}
            >
              <Award className="w-4 h-4 text-amber-500 animate-infinite" /> Certifications
            </button>
            <button
              onClick={() => setActiveSubTab("content")}
              className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 text-xs font-extrabold rounded-xl transition-all duration-300 hover:scale-102 ${
                activeSubTab === "content"
                  ? "bg-white text-indigo-600 shadow-md border border-slate-200/40 scale-102"
                  : "text-slate-500 hover:text-slate-850"
              }`}
            >
              <BookOpen className="w-4 h-4 text-emerald-500 animate-infinite" /> Content-Based
            </button>
          </div>

          {/* Main Workspace Dashboard Content */}
          <div className="grid lg:grid-cols-12 gap-8 items-start">
            
            {/* Left 8-Columns: Detailed Tab View */}
            <div className="lg:col-span-8 space-y-8">
              
              {/* Tab 1: Guided Learning Timeline Path */}
              {activeSubTab === "path" && (
                <div className="bg-white border border-slate-200/80 p-6 md:p-8 rounded-3xl shadow-lg space-y-6">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-5 border-b border-slate-100 gap-4">
                    <div className="space-y-1">
                      <h3 className="font-extrabold text-slate-800 text-xl flex items-center gap-2">
                        <GraduationCap className="w-6 h-6 text-indigo-500 animate-bounce" style={{ animationDuration: '3s' }} /> 
                        Interactive AI Growth Timeline
                      </h3>
                      <p className="text-xs text-slate-455 mt-0.5">Time-scoped curriculum to acquire your deficit competencies</p>
                    </div>
                    <span className="px-4 py-2 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-100 text-xs font-black flex items-center gap-1.5 shadow-sm">
                      <Clock className="w-3.5 h-3.5 text-indigo-600 animate-spin" style={{ animationDuration: '8s' }} /> Pace: {duration} Months
                    </span>
                  </div>

                  {pathMutation.isPending ? (
                    <div className="flex flex-col items-center justify-center py-24 space-y-4">
                      <div className="relative">
                        <div className="absolute inset-0 rounded-full bg-indigo-500/10 blur-xl w-16 h-16 animate-pulse" />
                        <Loader2 className="w-12 h-12 animate-spin text-indigo-600 animate-infinite" />
                      </div>
                      <p className="text-base text-slate-600 font-bold animate-pulse">Compiling time-optimized {duration}-month syllabus...</p>
                      <p className="text-xs text-slate-400">Querying semantic engines & course catalogs</p>
                    </div>
                  ) : learningPath ? (
                    <div className="space-y-8">
                      {/* Months Horizontal Connected Stepper */}
                      <div className="relative pb-2 border-b border-slate-100">
                        {/* Connected line connector */}
                        <div className="absolute top-[21px] left-8 right-8 h-0.5 bg-slate-100 z-0" />
                        <div 
                          className="absolute top-[21px] left-8 h-0.5 bg-gradient-to-r from-indigo-500 to-purple-500 z-0 transition-all duration-500" 
                          style={{ width: `${(activeMonthIdx / (parsedMonths.length - 1)) * 90}%` }}
                        />

                        <div className="relative z-10 flex items-center justify-between gap-4 overflow-x-auto pb-1 scrollbar-none">
                          {parsedMonths.map((m, idx) => {
                            const isCompleted = m.topics.every(t => completedTasks[`${activeReport.targetCareer}_m${m.num}_${t}`]);
                            const isActive = activeMonthIdx === idx;
                            return (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => setActiveMonthIdx(idx)}
                                className={`flex-shrink-0 flex flex-col items-center gap-1 transition-all duration-300 ${
                                  isActive ? "scale-105" : "hover:scale-102"
                                }`}
                              >
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                                  isActive
                                    ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/20"
                                    : isCompleted
                                      ? "bg-emerald-500 border-emerald-500 text-white shadow-lg"
                                      : "bg-white border-slate-200 text-slate-650 hover:border-slate-400"
                                }`}>
                                  {isCompleted ? (
                                    <Check className="w-5 h-5 font-black animate-scaleIn" />
                                  ) : (
                                    <span className="text-xs font-black">{m.num}</span>
                                  )}
                                </div>
                                  <span className={`text-[10px] font-black uppercase tracking-wider mt-1 ${
                                    isActive 
                                      ? "text-indigo-600 font-extrabold" 
                                      : "text-slate-400"
                                  }`}>
                                  Month {m.num}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Active Month Detail Panel */}
                      {activeMonth && (
                        <div className="grid md:grid-cols-12 gap-8 items-start animate-fadeIn">
                          
                          {/* Left Column: Topics Checklist */}
                          <div className="md:col-span-7 space-y-4">
                            <div className="flex justify-between items-center bg-slate-50/80 p-3 rounded-2xl border border-slate-100">
                              <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
                                <ListChecks className="w-4 h-4 text-indigo-500 animate-pulse animate-infinite" /> Core Concepts Checklist
                              </h4>
                              <span className="text-[10px] font-black text-indigo-755 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100">
                                {activeMonthProgress()}% Month Progress
                              </span>
                            </div>

                            {/* Monthly Progress Bar */}
                            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden shadow-inner border border-slate-200/20">
                              <div 
                                className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full rounded-full transition-all duration-700 ease-out shadow" 
                                style={{ width: `${activeMonthProgress()}%` }} 
                              />
                            </div>

                            <ul className="space-y-3 bg-gradient-to-b from-slate-50/80 to-slate-50/40 border border-slate-200/80 rounded-2xl p-5">
                              {activeMonth.topics?.map((topic, tIdx) => {
                                const key = `${activeReport.targetCareer}_m${activeMonth.num}_${topic}`;
                                const isDone = !!completedTasks[key];
                                return (
                                  <li 
                                    key={tIdx} 
                                    onClick={() => toggleTask(key)}
                                    className={`flex items-start gap-3.5 p-3.5 rounded-xl border transition-all duration-300 cursor-pointer shadow-sm ${
                                      isDone 
                                        ? "bg-emerald-50/30 border-emerald-200/30 text-slate-400" 
                                        : "bg-white border-slate-200/80 text-slate-800 hover:border-indigo-400/80 hover:translate-x-0.5 hover:shadow-md"
                                    }`}
                                  >
                                    <div className={`w-5 h-5 rounded-md flex items-center justify-center border-2 transition-all duration-200 mt-0.5 flex-shrink-0 ${
                                      isDone 
                                        ? "bg-emerald-500 border-emerald-500 text-white" 
                                        : "border-slate-350 bg-white"
                                    }`}>
                                      {isDone && <Check className="w-3.5 h-3.5 font-black" />}
                                    </div>
                                    <span className={`text-xs md:text-sm font-semibold leading-relaxed ${isDone ? "line-through opacity-85" : ""}`}>
                                      {topic}
                                    </span>
                                  </li>
                                );
                              })}
                              {(!activeMonth.topics || activeMonth.topics.length === 0) && (
                                <li className="text-xs text-slate-400 italic text-center py-6">No specific concept checklist compiled.</li>
                              )}
                            </ul>
                          </div>

                          {/* Right Column: Resources & Projects */}
                          <div className="md:col-span-5 space-y-6">
                            {/* suggested study resources with links */}
                            <div className="space-y-4">
                              <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
                                <PlayCircle className="w-4 h-4 text-indigo-500 animate-pulse animate-infinite" /> Brand Resource Links
                              </h4>
                              
                              <div className="space-y-3">
                                {activeMonth.resources?.map((res, rIdx) => {
                                  // Auto-generate deep links or parse explicit markdown links
                                  const markdownLinkMatch = res.match(/\[([^\]]+)\]\(([^)]+)\)/);
                                  let label = res;
                                  let url = `https://www.coursera.org/search?query=${encodeURIComponent(res.replace(/^[-*•\s]+/g, ""))}`;
                                  let platform = "Coursera Search";
                                  
                                  if (markdownLinkMatch) {
                                    label = markdownLinkMatch[1];
                                    url = markdownLinkMatch[2];
                                    platform = "Direct Resource";
                                  }

                                  const lowerRes = res.toLowerCase();
                                  if (lowerRes.includes("udemy")) platform = "Udemy Course";
                                  else if (lowerRes.includes("youtube")) platform = "YouTube Playlist";
                                  else if (lowerRes.includes("edx")) platform = "edX Course";
                                  else if (lowerRes.includes("mit")) platform = "MIT OpenCourseWare";
                                  
                                  let badgeStyle = "bg-blue-500/10 text-blue-600 border-blue-500/20";
                                  let cardStyle = "border-slate-200/80 bg-white hover:border-blue-400 hover:bg-blue-50/20";
                                  let platformIconColor = "text-blue-500";
                                  
                                  if (platform === "Udemy Course") {
                                    badgeStyle = "bg-purple-500/10 text-purple-600 border-purple-500/20";
                                    cardStyle = "border-slate-200/80 bg-white hover:border-purple-400 hover:bg-purple-50/20";
                                    platformIconColor = "text-purple-500";
                                  } else if (platform === "YouTube Playlist") {
                                    badgeStyle = "bg-red-500/10 text-red-600 border-red-500/20";
                                    cardStyle = "border-slate-200/80 bg-white hover:border-red-400 hover:bg-red-50/20";
                                    platformIconColor = "text-red-500";
                                  } else if (platform === "edX Course") {
                                    badgeStyle = "bg-amber-500/10 text-amber-600 border-amber-500/20";
                                    cardStyle = "border-slate-200/80 bg-white hover:border-amber-400 hover:bg-amber-50/20";
                                    platformIconColor = "text-amber-500";
                                  } else if (platform === "MIT OpenCourseWare") {
                                    badgeStyle = "bg-slate-500/10 text-slate-600 border-slate-500/20";
                                    cardStyle = "border-slate-200/80 bg-white hover:border-slate-400 hover:bg-slate-50/20";
                                    platformIconColor = "text-slate-500";
                                  }

                                  return (
                                    <a
                                      key={rIdx}
                                      href={url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className={`group block p-4 border rounded-2xl transition-all duration-300 shadow-sm flex justify-between items-center gap-3 hover:-translate-y-1 hover:shadow-md ${cardStyle}`}
                                    >
                                      <div className="space-y-1.5 min-w-0">
                                        <span className={`text-[9px] font-black px-2 py-0.5 rounded-full border uppercase tracking-wider inline-block ${badgeStyle}`}>
                                          {platform}
                                        </span>
                                        <p className="text-xs font-black text-slate-700 truncate leading-snug group-hover:text-indigo-600 transition-colors">
                                          {label}
                                        </p>
                                      </div>
                                      <div className={`p-1.5 rounded-lg bg-slate-50 border border-slate-150 group-hover:scale-115 transition-transform duration-300 ${platformIconColor}`}>
                                        <ExternalLink className="w-3.5 h-3.5" />
                                      </div>
                                    </a>
                                  );
                                })}
                                {(!activeMonth.resources || activeMonth.resources.length === 0) && (
                                  <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl text-center text-xs text-slate-400 italic">
                                    No external resource links compiled.
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Monthly Project Milestone */}
                            <div className="space-y-3">
                              <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
                                <Trophy className="w-4 h-4 text-indigo-500 animate-pulse animate-infinite" /> Milestone Project
                              </h4>
                              <div className="p-5 bg-gradient-to-br from-indigo-500/5 to-purple-500/5 border border-indigo-500/10 rounded-2xl relative overflow-hidden group hover:shadow-inner transition-all duration-300">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none group-hover:scale-125 transition-transform" />
                                <p className="text-xs md:text-sm text-slate-700 leading-relaxed font-bold italic relative z-10">
                                  "{activeMonth.project}"
                                </p>
                              </div>
                            </div>

                          </div>

                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-16 text-slate-400">
                      <BookOpen className="w-12 h-12 mx-auto mb-3 text-slate-300 animate-pulse" />
                      <p className="text-sm font-bold">AI Syllabus compiler online. Run an audit above to begin.</p>
                    </div>
                  )}
                </div>
              )}
                 {/* Tab 2: Recommended Industry Certifications */}
              {activeSubTab === "certs" && (
                <div className="bg-white border border-slate-200/80 p-6 md:p-8 rounded-3xl shadow-lg space-y-6">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-5 border-b border-slate-100 gap-4">
                    <div className="space-y-1">
                      <h3 className="font-extrabold text-slate-800 text-xl flex items-center gap-2">
                        <Award className="w-6 h-6 text-indigo-500 animate-bounce" /> Recommended Industry Credentials
                      </h3>
                      <p className="text-xs text-slate-455 mt-0.5">Top-tier global certifications to validate your skills to technical recruiters</p>
                    </div>
                  </div>

                  {pathMutation.isPending ? (
                    <div className="flex flex-col items-center justify-center py-20 space-y-4">
                      <Loader2 className="w-10 h-10 animate-spin text-indigo-600 animate-infinite" />
                      <p className="text-sm text-slate-500 font-bold animate-pulse">Analyzing standard credential bodies...</p>
                    </div>
                  ) : certifications ? (
                    <div className="grid sm:grid-cols-2 gap-6">
                      {parseCertifications(certifications).map((cert, idx) => {
                        const isTracked = trackedCerts.includes(cert.name);
                        const difficulty = cert.difficulty.toLowerCase();
                        
                        let cardBg = "from-slate-50 to-slate-100/50";
                        let borderStyle = "border-slate-200/80 hover:border-slate-400";
                        let badgeDiffStyle = "bg-amber-500/10 text-amber-600 border-amber-500/20";
                        
                        if (difficulty.includes("advanced") || difficulty.includes("expert")) {
                          cardBg = "from-rose-500/5 via-slate-50 to-slate-100/30";
                          borderStyle = isTracked 
                            ? "border-rose-400 shadow-rose-500/5 shadow-lg" 
                            : "border-slate-200/80 hover:border-rose-400/50";
                          badgeDiffStyle = "bg-rose-500/10 text-rose-600 border-rose-500/20";
                        } else if (difficulty.includes("beginner") || difficulty.includes("foundational")) {
                          cardBg = "from-emerald-500/5 via-slate-50 to-slate-100/30";
                          borderStyle = isTracked 
                            ? "border-emerald-400 shadow-emerald-500/5 shadow-lg" 
                            : "border-slate-200/80 hover:border-emerald-400/50";
                          badgeDiffStyle = "bg-emerald-500/10 text-emerald-600 border-emerald-500/20";
                        } else {
                          cardBg = "from-indigo-500/5 via-slate-50 to-slate-100/30";
                          borderStyle = isTracked 
                            ? "border-indigo-400 shadow-indigo-500/5 shadow-lg" 
                            : "border-slate-200/80 hover:border-indigo-400/50";
                          badgeDiffStyle = "bg-indigo-500/10 text-indigo-600 border-indigo-500/20";
                        }

                        return (
                          <div 
                            key={idx} 
                            className={`p-6 rounded-3xl border bg-gradient-to-br transition-all duration-300 relative overflow-hidden flex flex-col justify-between h-[280px] hover:-translate-y-1 hover:shadow-xl ${cardBg} ${borderStyle}`}
                          >
                            <div className="absolute top-0 left-0 right-0 h-[50%] bg-gradient-to-b from-white/10 to-transparent pointer-events-none transform skew-y-12 scale-150 origin-top-left" />
                            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-50/5 rounded-full blur-xl pointer-events-none" />
                            
                            <div className="space-y-4 relative z-10">
                              <div className="flex justify-between items-center">
                                <span className="text-[9px] font-black bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full border border-slate-250/50 uppercase tracking-widest">
                                  {cert.provider}
                                </span>
                                <span className={`text-[9px] font-black px-2.5 py-1 rounded-full border uppercase tracking-widest ${badgeDiffStyle}`}>
                                  {cert.difficulty}
                                </span>
                              </div>

                              <h4 className="font-black text-slate-800 text-sm md:text-base leading-snug line-clamp-2">{cert.name}</h4>
                              <p className="text-[11px] text-slate-500 leading-relaxed italic line-clamp-3">"{cert.why}"</p>
                            </div>

                            <div className="pt-4 border-t border-slate-200/40 flex justify-between items-center gap-2 relative z-10">
                              <span className="text-[10px] text-slate-400 uppercase tracking-widest">Cost: <strong className="text-slate-700 font-black">{cert.cost}</strong></span>
                              
                              <div className="flex items-center gap-3">
                                <a 
                                  href={cert.link} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-[10px] bg-slate-100 hover:bg-indigo-500 text-slate-700 hover:text-white px-3 py-1.5 rounded-xl border border-slate-200/60 font-black flex items-center gap-1 transition-all duration-300"
                                >
                                  Register <ExternalLink className="w-2.5 h-2.5" />
                                </a>
                                <button
                                  type="button"
                                  onClick={() => toggleTrackCert(cert.name)}
                                  className={`p-2 rounded-xl border transition-all duration-300 hover:scale-105 active:scale-95 ${
                                    isTracked 
                                      ? "bg-amber-500 border-amber-500 text-white shadow-lg shadow-amber-500/20" 
                                      : "bg-white border-slate-200 text-slate-400 hover:text-amber-500"
                                  }`}
                                  title="Add to target board"
                                >
                                  <Bookmark className="w-3.5 h-3.5 fill-current" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-16 text-slate-400">
                      <Award className="w-12 h-12 mx-auto mb-3 text-slate-300 animate-pulse" />
                      <p className="text-sm font-bold">Credentials catalog inactive. Run an audit to compile recommendations.</p>
                    </div>
                  )}
                </div>
              )}

              {/* Tab 3: Content-Based Recommendations */}
              {activeSubTab === "content" && (
                <div className="bg-white border border-slate-200/80 p-6 md:p-8 rounded-3xl shadow-lg space-y-6">
                  <div>
                    <h3 className="font-extrabold text-slate-800 text-xl flex items-center gap-2">
                      <BookOpen className="w-6 h-6 text-indigo-500 animate-bounce" /> Custom Course &amp; Content Recommender
                    </h3>
                    <p className="text-xs text-slate-455 mt-0.5">Content-based semantic recommendations comparing your current academic profile &amp; skill deficits</p>
                  </div>

                  {pathMutation.isPending ? (
                    <div className="flex flex-col items-center justify-center py-20 space-y-3">
                      <Loader2 className="w-10 h-10 animate-spin text-indigo-600 animate-infinite" />
                      <p className="text-sm text-slate-500 font-bold animate-pulse">Running collaborative scoring models...</p>
                    </div>
                  ) : contentBased ? (
                    <div className="bg-slate-50/50 border border-slate-200/40 rounded-3xl p-6 md:p-8 prose prose-indigo max-w-none text-slate-650 text-xs sm:text-sm leading-relaxed prose-headings:text-slate-850 prose-strong:text-indigo-600">
                      <ReactMarkdown>{contentBased}</ReactMarkdown>
                    </div>
                  ) : (
                    <div className="text-center py-16 text-slate-400">
                      <BookOpen className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                      <p className="text-sm font-bold">Content-Based recommender is offline. Run an audit above to generate matches.</p>
                    </div>
                  )}
                </div>
              )}

            </div>

            {/* Right 4-Columns: Side-by-Side Competencies Grid */}
            <div className="lg:col-span-4 space-y-8 lg:sticky lg:top-6">
              {/* Target Tracked Certifications Mini-Board */}
              {trackedCerts.length > 0 && (
                <div className="bg-gradient-to-br from-white to-slate-50/50 border border-slate-200/80 p-5 rounded-3xl shadow-md space-y-4 hover:shadow-lg transition-all duration-300">
                  <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5 uppercase tracking-widest border-b border-slate-100 pb-2">
                    <Trophy className="w-4 h-4 text-amber-500 animate-bounce" /> Target Board ({trackedCerts.length})
                  </h4>
                  <ul className="space-y-2">
                    {trackedCerts.map((cert, idx) => (
                      <li key={idx} className="flex justify-between items-center p-3 bg-white border border-slate-200/60 rounded-2xl text-xs font-bold text-slate-700 shadow-sm hover:border-amber-400/50 transition-all duration-300">
                        <span className="truncate pr-3 leading-snug">{cert}</span>
                        <button 
                          onClick={() => toggleTrackCert(cert)} 
                          className="w-5 h-5 rounded-lg bg-rose-50 hover:bg-rose-500 text-rose-500 hover:text-white flex items-center justify-center font-bold transition-all duration-200"
                          title="Remove"
                        >
                          ✕
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Match Competency Map */}
              <div className="bg-gradient-to-br from-white to-slate-50/50 border border-slate-200/80 p-6 rounded-3xl shadow-md space-y-6 hover:shadow-lg transition-all duration-300">
                
                {/* You Have Skills */}
                <div className="space-y-3">
                  <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-2 border-b border-slate-100 pb-2.5 uppercase tracking-widest">
                    <CheckCircle className="w-4 h-4 text-emerald-500 animate-pulse animate-infinite" /> Matched Skills ({activeReport.matchedSkills?.length || 0})
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {activeReport.matchedSkills?.map((s) => (
                      <span key={s} className="text-[10px] px-3 py-1.5 bg-emerald-500/10 text-emerald-600 rounded-xl font-bold border border-emerald-500/15 flex items-center gap-1 hover:scale-105 transition-transform duration-200">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                        {s}
                      </span>
                    ))}
                    {(!activeReport.matchedSkills || activeReport.matchedSkills.length === 0) && (
                      <p className="text-xs text-slate-400 italic">No matched skills recorded yet.</p>
                    )}
                  </div>
                </div>

                {/* Deficit Skills */}
                <div className="space-y-3 pt-2">
                  <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-2 border-b border-slate-100 pb-2.5 uppercase tracking-widest">
                    <XCircle className="w-4 h-4 text-rose-500 animate-pulse animate-infinite" /> Deficit Skills ({activeReport.missingSkills?.length || 0})
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {activeReport.missingSkills?.map((s) => (
                      <span key={s} className="text-[10px] px-3 py-1.5 bg-rose-500/10 text-rose-600 rounded-xl font-bold border border-rose-500/15 flex items-center gap-1 hover:scale-105 transition-transform duration-200">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500 inline-block" />
                        {s}
                      </span>
                    ))}
                    {(!activeReport.missingSkills || activeReport.missingSkills.length === 0) && (
                      <p className="text-xs text-slate-400 italic">You satisfy all core requirements!</p>
                    )}
                  </div>
                </div>

              </div>

            </div>

          </div>

        </div>
      ) : null}
    </div>
  );
}
